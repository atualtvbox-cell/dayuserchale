import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, AlertCircle, Check, Clock } from 'lucide-react';
import { Reservation } from '../types';

interface AvailabilityCalendarProps {
  chaletId: string;
  reservations: Reservation[];
  checkIn: string;
  checkOut: string;
  onSelectDates: (checkIn: string, checkOut: string) => void;
}

export const AvailabilityCalendar: React.FC<AvailabilityCalendarProps> = ({
  chaletId,
  reservations,
  checkIn,
  checkOut,
  onSelectDates,
}) => {
  // Current view month (0-indexed: 9 = October 2026)
  const [viewDate, setViewDate] = useState(() => new Date(2026, 9, 1));
  const [selectionStep, setSelectionStep] = useState<'checkIn' | 'checkOut'>('checkIn');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Today is 2026-10-02
  const todayStr = '2026-10-02';
  const now = Date.now();

  // Get all booked dates for this chalet (confirmed or pending within 60 min)
  const bookedRanges = reservations
    .filter((r) => {
      if (r.chaletId !== chaletId) return false;
      if (r.status === 'confirmada') return true;
      if (r.status === 'pendente') {
        return !r.expiresAt || r.expiresAt > now;
      }
      return false;
    })
    .map((r) => ({
      start: r.checkIn,
      end: r.checkOut,
      guest: r.guestName,
      code: r.id,
      status: r.status,
      expiresAt: r.expiresAt,
    }));

  // O bloqueio é feito de forma inclusiva: do dia de entrada ao dia de saída da reserva do ocupante
  const getBookingForDate = (dateStr: string) => {
    return bookedRanges.find((range) => {
      return dateStr >= range.start && dateStr <= range.end;
    });
  };

  const isRangeOverlapping = (startStr: string, endStr: string) => {
    return bookedRanges.some((range) => {
      // Bloqueia qualquer intersecção com o período da reserva, incluindo dia de entrada e saída
      return !(endStr < range.start || startStr > range.end);
    });
  };

  const currentYear = viewDate.getFullYear();
  const currentMonth = viewDate.getMonth();

  // Days in month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(currentYear, currentMonth, 1).getDay(); // 0 is Sun

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const handlePrevMonth = () => {
    setViewDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const handleNextMonth = () => {
    setViewDate(new Date(currentYear, currentMonth + 1, 1));
  };

  const handleDayClick = (day: number) => {
    setErrorMessage(null);
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

    // Cannot select past dates
    if (dateStr < todayStr) return;

    // Cannot select an already booked or pending day as checkIn
    const booking = getBookingForDate(dateStr);
    if (booking) {
      if (booking.status === 'confirmada') {
        setErrorMessage(`O dia ${day}/${currentMonth + 1} já está reservado e confirmado.`);
      } else {
        const minsLeft = Math.max(1, Math.ceil(((booking.expiresAt || (now + 3600000)) - now) / 60000));
        setErrorMessage(`O dia ${day}/${currentMonth + 1} está com reserva pendente aguardando pagamento (${minsLeft} min restantes).`);
      }
      return;
    }

    if (selectionStep === 'checkIn' || (Boolean(checkIn) && Boolean(checkOut))) {
      // Pick Check-In
      onSelectDates(dateStr, '');
      setSelectionStep('checkOut');
    } else {
      // Pick Check-Out
      if (dateStr <= checkIn) {
        // If clicked date is before or equal to checkIn, reset and set as checkIn
        onSelectDates(dateStr, '');
        setSelectionStep('checkOut');
        return;
      }

      // Check if there is any booked day between checkIn and selected checkOut
      if (isRangeOverlapping(checkIn, dateStr)) {
        setErrorMessage('O intervalo selecionado contém datas já ocupadas ou bloqueadas por 60 min para pagamento. Escolha um período livre contínuo.');
        return;
      }

      onSelectDates(checkIn, dateStr);
      setSelectionStep('checkIn');
    }
  };

  return (
    <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs space-y-4">
      
      {/* Calendar Header with Navigation */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-4 h-4 text-[#2d3a29]" />
          <h4 className="font-serif-luxury text-lg font-bold text-[#1c1917]">
            Grade de Disponibilidade do Chalé
          </h4>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-medium text-xs text-[#1c1917]">
            {monthNames[currentMonth]} {currentYear}
          </span>
          <div className="flex items-center">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1 rounded hover:bg-[#ede6d8] text-[#57534e] transition-colors"
              title="Mês anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1 rounded hover:bg-[#ede6d8] text-[#57534e] transition-colors"
              title="Próximo mês"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Instructions & Step Helper */}
      <div className="flex items-center justify-between text-xs py-1 border-y border-[#f2ede4]">
        <div className="flex items-center gap-2 text-[#57534e]">
          <span>Selecione:</span>
          <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
            selectionStep === 'checkIn' ? 'bg-[#222c1f] text-white' : 'bg-[#f4efe4] text-[#222c1f]'
          }`}>
            1. Check-in {checkIn ? `(${checkIn.split('-').reverse().slice(0, 2).join('/')})` : ''}
          </span>
          <span>→</span>
          <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
            selectionStep === 'checkOut' ? 'bg-[#222c1f] text-white' : 'bg-[#f4efe4] text-[#222c1f]'
          }`}>
            2. Check-out {checkOut ? `(${checkOut.split('-').reverse().slice(0, 2).join('/')})` : ''}
          </span>
        </div>

        {checkIn && checkOut && (
          <span className="text-emerald-700 font-semibold flex items-center gap-1 text-[11px]">
            <Check className="w-3.5 h-3.5" />
            Datas livres selecionadas!
          </span>
        )}
      </div>

      {/* Error alert if overlapped or booked */}
      {errorMessage && (
        <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Weekday Labels */}
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-[#78716c] uppercase">
        <span>Dom</span>
        <span>Seg</span>
        <span>Ter</span>
        <span>Qua</span>
        <span>Qui</span>
        <span>Sex</span>
        <span>Sáb</span>
      </div>

      {/* Calendar Days Grid */}
      <div className="grid grid-cols-7 gap-1">
        {/* Leading empty spaces */}
        {[...Array(firstDayOfWeek)].map((_, i) => (
          <div key={`empty-${i}`} className="h-10 sm:h-11" />
        ))}

        {/* Days of month */}
        {[...Array(daysInMonth)].map((_, i) => {
          const day = i + 1;
          const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const isPast = dateStr < todayStr;
          const booking = getBookingForDate(dateStr);
          const isCheckInDay = checkIn === dateStr;
          const isCheckOutDay = checkOut === dateStr;
          const isInRange = checkIn && checkOut && dateStr > checkIn && dateStr < checkOut;

          let dayClasses = 'relative h-10 sm:h-11 rounded-lg text-xs flex flex-col items-center justify-center transition-all cursor-pointer select-none';

          if (isPast) {
            dayClasses += ' text-[#c7baa4] bg-transparent cursor-not-allowed opacity-40';
          } else if (booking) {
            if (booking.status === 'confirmada') {
              dayClasses += ' bg-red-50 text-red-700 cursor-not-allowed border border-red-200 line-through';
            } else {
              dayClasses += ' bg-amber-50 text-amber-900 cursor-not-allowed border border-amber-300 line-through';
            }
          } else if (isCheckInDay || isCheckOutDay) {
            dayClasses += ' bg-[#222c1f] text-white font-bold shadow-xs scale-95';
          } else if (isInRange) {
            dayClasses += ' bg-[#ede6d8] text-[#1c1917] font-semibold rounded-none';
          } else {
            dayClasses += ' bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#292524] border border-transparent hover:border-[#cfc6b4]';
          }

          let tooltip = `Dia ${day} (Livre para Reserva)`;
          if (booking) {
            tooltip = booking.status === 'confirmada' 
              ? `Dia ${day} · Reservado (Confirmado)`
              : `Dia ${day} · Reservado (Aguardando Pagamento · Bloqueado por 60 min)`;
          }

          return (
            <button
              key={dateStr}
              type="button"
              disabled={isPast || Boolean(booking)}
              onClick={() => handleDayClick(day)}
              className={dayClasses}
              title={tooltip}
            >
              <span className="font-mono text-xs">{day}</span>
              {booking && (
                <span className={`text-[7px] font-bold uppercase tracking-tighter leading-none mt-0.5 no-underline ${
                  booking.status === 'confirmada' ? 'text-red-700' : 'text-amber-800'
                }`}>
                  {booking.status === 'confirmada' ? 'Reservado' : 'Bloq. 60m'}
                </span>
              )}
              {isCheckInDay && (
                <span className="text-[8px] uppercase tracking-tighter leading-none text-[#d6cdbd]">
                  Entrada
                </span>
              )}
              {isCheckOutDay && (
                <span className="text-[8px] uppercase tracking-tighter leading-none text-[#d6cdbd]">
                  Saída
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Legend */}
      <div className="pt-3 border-t border-[#f2ede4] flex flex-wrap items-center justify-between text-[11px] text-[#78716c] gap-2">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-[#FAF9F5] border border-[#d6cdbd]" />
            <span>Livre</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-red-100 border border-red-300" />
            <span className="text-red-700 font-medium">Reservado (Confirmado)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-amber-100 border border-amber-300" />
            <span className="text-amber-800 font-medium">Reservado (Aguardando Pagto · 60 min)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-[#222c1f]" />
            <span>Sua Seleção</span>
          </div>
        </div>

        <span className="text-[10px] text-[#a8a29e]">
          * Clique na data de entrada e depois na de saída
        </span>
      </div>

    </div>
  );
};
