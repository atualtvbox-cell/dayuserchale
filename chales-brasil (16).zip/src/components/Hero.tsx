import React from 'react';
import { SearchFilters, HeroSettings, DEFAULT_HERO_SETTINGS } from '../types';

interface HeroProps {
  filters?: SearchFilters;
  onFilterChange?: (filters: SearchFilters) => void;
  onSearchSubmit?: () => void;
  totalChaletsCount?: number;
  heroSettings?: HeroSettings;
}

export const Hero: React.FC<HeroProps> = ({
  onSearchSubmit,
  totalChaletsCount,
  heroSettings = DEFAULT_HERO_SETTINGS,
}) => {
  const { kicker, title, description, badges } = heroSettings;
  const hasBadges = Array.isArray(badges) && badges.length > 0;

  return (
    <section className="relative w-full overflow-hidden bg-[#181d16] text-[#FAF9F5]">
      {/* Background Image with luxury photo & measured gradient scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_brazilian_luxury_chalet_1790997520247.jpg"
          alt="Chalé A-frame de luxo em meio às araucárias na serra brasileira ao crepúsculo"
          className="w-full h-full object-cover object-center transform scale-105 transition-transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />
        {/* Measured Scrim for contrast: dark gradient at bottom and subtle overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#141813] via-[#141813]/50 to-[#141813]/30" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-20 sm:pt-36 sm:pb-28">
        
        {/* Editorial Subtitle / Kicker (only if present) */}
        {kicker && kicker.trim().length > 0 && (
          <div className="flex items-center gap-3 text-xs sm:text-sm tracking-widest uppercase text-[#e1d9ca] mb-4">
            <span className="w-8 h-[1px] bg-[#c7baa4]" />
            <span>{kicker}</span>
            <span className="w-8 h-[1px] bg-[#c7baa4]" />
          </div>
        )}

        {/* Main Headline (only if present) */}
        {title && title.trim().length > 0 && (
          <h1 className="font-serif-luxury text-4xl sm:text-6xl lg:text-7xl font-light tracking-tight max-w-4xl text-white leading-[1.08] mb-6 text-balance">
            {title}
          </h1>
        )}

        {/* Description Paragraph (only if present) */}
        {description && description.trim().length > 0 && (
          <p className="max-w-2xl text-base sm:text-lg text-[#e6ded1] font-light leading-relaxed mb-12">
            {description}
          </p>
        )}

        {/* Trust Badges - Dynamic list with insert/edit/delete support from Admin */}
        {hasBadges && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-8 border-t border-white/15 text-white/90">
            {badges.map((badge) => (
              <div key={badge.id}>
                <div className="font-serif-luxury text-2xl text-[#f3ece0]">{badge.title}</div>
                {badge.subtitle && (
                  <div className="text-xs text-[#d6cdbd] mt-0.5">{badge.subtitle}</div>
                )}
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
