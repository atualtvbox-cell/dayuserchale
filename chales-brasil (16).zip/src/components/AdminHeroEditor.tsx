import React, { useState } from 'react';
import { 
  Sparkles, Save, RotateCcw, Trash2, Plus, Edit2, 
  Check, Eye, Type, AlertCircle, X, HelpCircle
} from 'lucide-react';
import { HeroSettings, HeroBadge, DEFAULT_HERO_SETTINGS } from '../types';

interface AdminHeroEditorProps {
  heroSettings: HeroSettings;
  onUpdateHeroSettings: (newSettings: HeroSettings) => void;
  onAddToast?: (toast: { type: 'success' | 'info' | 'warning' | 'error'; title: string; message: string }) => void;
}

export const AdminHeroEditor: React.FC<AdminHeroEditorProps> = ({
  heroSettings,
  onUpdateHeroSettings,
  onAddToast,
}) => {
  const [formData, setFormData] = useState<HeroSettings>(heroSettings);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // New badge state
  const [isAddingBadge, setIsAddingBadge] = useState(false);
  const [newBadgeTitle, setNewBadgeTitle] = useState('');
  const [newBadgeSubtitle, setNewBadgeSubtitle] = useState('');

  // Editing existing badge state
  const [editingBadgeId, setEditingBadgeId] = useState<string | null>(null);
  const [editingBadgeTitle, setEditingBadgeTitle] = useState('');
  const [editingBadgeSubtitle, setEditingBadgeSubtitle] = useState('');

  const handleSave = () => {
    onUpdateHeroSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
    onAddToast?.({
      type: 'success',
      title: 'Textos do Hero Atualizados',
      message: 'As alterações nos textos da imagem hero foram salvas com sucesso.',
    });
  };

  const handleResetToDefault = () => {
    if (window.confirm('Tem certeza de que deseja restaurar os textos padrão originais da imagem hero?')) {
      setFormData(DEFAULT_HERO_SETTINGS);
      onUpdateHeroSettings(DEFAULT_HERO_SETTINGS);
      onAddToast?.({
        type: 'info',
        title: 'Textos Restaurados',
        message: 'Os textos originais da curadoria foram restaurados.',
      });
    }
  };

  const handleClearAllTexts = () => {
    if (window.confirm('Deseja apagar todos os textos da imagem hero? A imagem ficará 100% limpa.')) {
      const cleared: HeroSettings = {
        kicker: '',
        title: '',
        description: '',
        badges: [],
      };
      setFormData(cleared);
      onUpdateHeroSettings(cleared);
      onAddToast?.({
        type: 'warning',
        title: 'Textos Apagados',
        message: 'Todos os textos da imagem hero foram apagados.',
      });
    }
  };

  // Badge operations
  const handleAddNewBadge = () => {
    if (!newBadgeTitle.trim()) return;
    const newBadge: HeroBadge = {
      id: `badge-${Date.now()}`,
      title: newBadgeTitle.trim(),
      subtitle: newBadgeSubtitle.trim(),
    };
    const updatedBadges = [...formData.badges, newBadge];
    setFormData({ ...formData, badges: updatedBadges });
    setNewBadgeTitle('');
    setNewBadgeSubtitle('');
    setIsAddingBadge(false);
  };

  const handleStartEditBadge = (badge: HeroBadge) => {
    setEditingBadgeId(badge.id);
    setEditingBadgeTitle(badge.title);
    setEditingBadgeSubtitle(badge.subtitle);
  };

  const handleSaveEditBadge = () => {
    if (!editingBadgeId || !editingBadgeTitle.trim()) return;
    const updatedBadges = formData.badges.map((b) => 
      b.id === editingBadgeId 
        ? { ...b, title: editingBadgeTitle.trim(), subtitle: editingBadgeSubtitle.trim() } 
        : b
    );
    setFormData({ ...formData, badges: updatedBadges });
    setEditingBadgeId(null);
    setEditingBadgeTitle('');
    setEditingBadgeSubtitle('');
  };

  const handleDeleteBadge = (badgeId: string) => {
    const updatedBadges = formData.badges.filter((b) => b.id !== badgeId);
    setFormData({ ...formData, badges: updatedBadges });
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      
      {/* Top Banner / Explanation */}
      <div className="bg-white border border-[#e5decb] rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#2d3a29] mb-1">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>Gerenciador de Conteúdo Editorial</span>
          </div>
          <h3 className="font-serif-luxury text-2xl font-bold text-[#1c1917]">
            Textos da Imagem Hero (Capa Principal)
          </h3>
          <p className="text-xs text-[#78716c] mt-1 max-w-2xl leading-relaxed">
            Personalize, edite ou apague qualquer texto exibido sobre a fotografia da capa. 
            Você pode deixar a imagem limpa apagando os campos ou inserir frases autorais para sua pousada.
          </p>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#d6cdbd] text-[#57534e] hover:bg-[#FAF9F5] text-xs font-medium transition-colors cursor-pointer"
            title="Voltar aos textos padrão de curadoria"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restaurar Padrão</span>
          </button>

          <button
            type="button"
            onClick={handleClearAllTexts}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-red-200 text-red-700 hover:bg-red-50 text-xs font-medium transition-colors cursor-pointer"
            title="Limpar todos os textos de uma vez"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Apagar Tudo</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-white text-xs font-semibold shadow-xs transition-all cursor-pointer ${
              savedSuccess ? 'bg-emerald-700' : 'bg-[#222c1f] hover:bg-[#2d3a29]'
            }`}
          >
            {savedSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Salvo com Sucesso!</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" />
                <span>Salvar Alterações</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Grid: Form Inputs on Left, Live Preview on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: EDITING FIELDS */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Section 1: Main Texts */}
          <div className="bg-white border border-[#e5decb] rounded-2xl p-6 shadow-xs space-y-5">
            <h4 className="font-serif-luxury text-lg font-bold text-[#1c1917] border-b border-[#f0eadc] pb-3 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Type className="w-4 h-4 text-[#2d3a29]" />
                <span>Textos Principais</span>
              </span>
              <span className="text-xs font-sans font-normal text-[#78716c]">
                Deixe em branco para apagar
              </span>
            </h4>

            {/* Field 1: Kicker / Subtitle */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-[#1c1917] uppercase tracking-wider">
                  Subtítulo Superior (Kicker)
                </label>
                {formData.kicker && (
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, kicker: '' })}
                    className="text-[11px] text-red-600 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Apagar subtítulo</span>
                  </button>
                )}
              </div>
              <input
                type="text"
                value={formData.kicker}
                onChange={(e) => setFormData({ ...formData, kicker: e.target.value })}
                placeholder="Ex: Curadoria de Hospedagem Poética no Brasil"
                className="w-full bg-[#FAF9F5] border border-[#d6cdbd] rounded-xl px-3.5 py-2.5 text-xs text-[#1c1917] focus:outline-none focus:border-[#222c1f] transition-colors"
              />
              <p className="text-[11px] text-[#78716c]">
                Linha curta em letras maiúsculas que antecede o título com traços laterais.
              </p>
            </div>

            {/* Field 2: Headline / Main Title */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-[#1c1917] uppercase tracking-wider">
                  Título Principal (Headline)
                </label>
                {formData.title && (
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, title: '' })}
                    className="text-[11px] text-red-600 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Apagar título</span>
                  </button>
                )}
              </div>
              <textarea
                rows={2}
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Ex: Onde o silêncio da serra encontra a arquitetura do refúgio."
                className="w-full bg-[#FAF9F5] border border-[#d6cdbd] rounded-xl px-3.5 py-2.5 text-xs text-[#1c1917] focus:outline-none focus:border-[#222c1f] transition-colors font-serif-luxury text-sm leading-relaxed"
              />
              <p className="text-[11px] text-[#78716c]">
                Frase de maior destaque visual sobre a fotografia.
              </p>
            </div>

            {/* Field 3: Description */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-[#1c1917] uppercase tracking-wider">
                  Descrição Poética / Parágrafo
                </label>
                {formData.description && (
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, description: '' })}
                    className="text-[11px] text-red-600 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Apagar descrição</span>
                  </button>
                )}
              </div>
              <textarea
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Ex: Seleção rigorosa dos chalés A-frame, cabanas de vidro e retiros de montanha mais extraordinários..."
                className="w-full bg-[#FAF9F5] border border-[#d6cdbd] rounded-xl px-3.5 py-2.5 text-xs text-[#1c1917] focus:outline-none focus:border-[#222c1f] transition-colors leading-relaxed"
              />
              <p className="text-[11px] text-[#78716c]">
                Texto de apresentação complementar que situa o hóspede sobre as experiências.
              </p>
            </div>

          </div>

          {/* Section 2: Badges / Destaques da Base */}
          <div className="bg-white border border-[#e5decb] rounded-2xl p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-[#f0eadc] pb-3">
              <div>
                <h4 className="font-serif-luxury text-lg font-bold text-[#1c1917] flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>Destaques da Base ({formData.badges.length})</span>
                </h4>
                <p className="text-xs text-[#78716c] mt-0.5">
                  Itens exibidos com linhas finas na base da imagem Hero
                </p>
              </div>

              {!isAddingBadge && (
                <button
                  type="button"
                  onClick={() => setIsAddingBadge(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#222c1f] hover:bg-[#2d3a29] text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Inserir Destaque</span>
                </button>
              )}
            </div>

            {/* Inserir Novo Destaque Form */}
            {isAddingBadge && (
              <div className="bg-[#FAF9F5] border border-[#222c1f]/20 rounded-xl p-4 space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between text-xs font-bold text-[#1c1917]">
                  <span>Novo Destaque da Imagem Hero</span>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingBadge(false);
                      setNewBadgeTitle('');
                      setNewBadgeSubtitle('');
                    }}
                    className="text-[#78716c] hover:text-[#1c1917]"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-2">
                  <div>
                    <label className="text-[11px] font-semibold text-[#57534e]">Título do Destaque *</label>
                    <input
                      type="text"
                      value={newBadgeTitle}
                      onChange={(e) => setNewBadgeTitle(e.target.value)}
                      placeholder="Ex: 100% Privativos ou Café da Manhã Incluso"
                      className="w-full bg-white border border-[#d6cdbd] rounded-lg px-3 py-2 text-xs text-[#1c1917] focus:outline-none focus:border-[#222c1f]"
                      autoFocus
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-[#57534e]">Subtítulo Explicativo</label>
                    <input
                      type="text"
                      value={newBadgeSubtitle}
                      onChange={(e) => setNewBadgeSubtitle(e.target.value)}
                      placeholder="Ex: Sem áreas comuns ou vizinhos próximos"
                      className="w-full bg-white border border-[#d6cdbd] rounded-lg px-3 py-2 text-xs text-[#1c1917] focus:outline-none focus:border-[#222c1f]"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingBadge(false);
                      setNewBadgeTitle('');
                      setNewBadgeSubtitle('');
                    }}
                    className="px-3 py-1.5 text-xs text-[#57534e] hover:bg-stone-200 rounded-lg cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleAddNewBadge}
                    disabled={!newBadgeTitle.trim()}
                    className="px-3 py-1.5 bg-[#222c1f] hover:bg-[#2d3a29] disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Adicionar ao Hero</span>
                  </button>
                </div>
              </div>
            )}

            {/* Badges List */}
            {formData.badges.length === 0 ? (
              <div className="bg-[#FAF9F5] border border-dashed border-[#d6cdbd] rounded-xl p-8 text-center space-y-2">
                <AlertCircle className="w-6 h-6 text-[#a89f91] mx-auto" />
                <p className="text-xs text-[#78716c]">
                  Nenhum destaque configurado no momento. A base do Hero ficará sem textos.
                </p>
                <button
                  type="button"
                  onClick={() => setIsAddingBadge(true)}
                  className="text-xs text-[#222c1f] font-semibold hover:underline inline-block mt-1"
                >
                  Inserir o primeiro destaque
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {formData.badges.map((badge, index) => (
                  <div
                    key={badge.id}
                    className="bg-[#FAF9F5] border border-[#e5decb] rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-[#c7baa4] transition-colors"
                  >
                    {editingBadgeId === badge.id ? (
                      /* Inline Edit Mode */
                      <div className="flex-1 space-y-2">
                        <input
                          type="text"
                          value={editingBadgeTitle}
                          onChange={(e) => setEditingBadgeTitle(e.target.value)}
                          placeholder="Título do destaque"
                          className="w-full bg-white border border-[#222c1f] rounded-lg px-2.5 py-1.5 text-xs font-bold text-[#1c1917]"
                        />
                        <input
                          type="text"
                          value={editingBadgeSubtitle}
                          onChange={(e) => setEditingBadgeSubtitle(e.target.value)}
                          placeholder="Subtítulo descritivo"
                          className="w-full bg-white border border-[#d6cdbd] rounded-lg px-2.5 py-1.5 text-xs text-[#57534e]"
                        />
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            type="button"
                            onClick={handleSaveEditBadge}
                            className="px-2.5 py-1 bg-[#222c1f] text-white text-[11px] font-semibold rounded-md flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3 h-3" />
                            <span>Salvar</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingBadgeId(null)}
                            className="px-2.5 py-1 border border-[#d6cdbd] text-[#57534e] text-[11px] rounded-md hover:bg-stone-200 cursor-pointer"
                          >
                            Cancelar
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* Display Mode */
                      <>
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-[#e5decb] text-[#222c1f] text-[10px] font-mono font-bold flex items-center justify-center">
                              {index + 1}
                            </span>
                            <span className="font-serif-luxury font-bold text-sm text-[#1c1917]">
                              {badge.title}
                            </span>
                          </div>
                          {badge.subtitle && (
                            <p className="text-xs text-[#78716c] pl-7">
                              {badge.subtitle}
                            </p>
                          )}
                        </div>

                        {/* Action buttons per badge */}
                        <div className="flex items-center gap-1.5 self-end sm:self-center pl-7 sm:pl-0">
                          <button
                            type="button"
                            onClick={() => handleStartEditBadge(badge)}
                            className="p-1.5 text-[#57534e] hover:text-[#1c1917] hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
                            title="Editar texto deste destaque"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteBadge(badge.id)}
                            className="p-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                            title="Apagar este destaque"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* RIGHT COLUMN: LIVE REAL-TIME PREVIEW */}
        <div className="lg:col-span-5 sticky top-24 space-y-4">
          <div className="bg-white border border-[#e5decb] rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#f0eadc]">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#1c1917] uppercase tracking-wider">
                <Eye className="w-4 h-4 text-[#2d3a29]" />
                <span>Prévia em Tempo Real</span>
              </div>
              <span className="text-[11px] text-[#78716c]">
                Como o hóspede verá
              </span>
            </div>

            {/* Mocked Hero Frame */}
            <div className="relative rounded-xl overflow-hidden bg-[#181d16] text-[#FAF9F5] shadow-lg border border-[#3c4d38] aspect-[4/3] flex flex-col justify-end p-5">
              {/* Background with real Chalet photo */}
              <img
                src="/src/assets/images/hero_brazilian_luxury_chalet_1790997520247.jpg"
                alt="Preview Hero"
                className="absolute inset-0 w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#141813] via-[#141813]/60 to-[#141813]/40" />

              {/* Live Overlay Texts */}
              <div className="relative z-10 space-y-2">
                
                {/* Kicker */}
                {formData.kicker && formData.kicker.trim().length > 0 ? (
                  <div className="flex items-center gap-1.5 text-[9px] tracking-widest uppercase text-[#e1d9ca]">
                    <span className="w-3 h-[1px] bg-[#c7baa4]" />
                    <span className="truncate">{formData.kicker}</span>
                    <span className="w-3 h-[1px] bg-[#c7baa4]" />
                  </div>
                ) : (
                  <div className="text-[9px] text-white/30 italic">[Subtítulo apagado]</div>
                )}

                {/* Headline */}
                {formData.title && formData.title.trim().length > 0 ? (
                  <h5 className="font-serif-luxury text-base sm:text-lg font-light text-white leading-tight line-clamp-3">
                    {formData.title}
                  </h5>
                ) : (
                  <div className="text-xs text-white/30 italic">[Título apagado - imagem desobstruída]</div>
                )}

                {/* Description */}
                {formData.description && formData.description.trim().length > 0 ? (
                  <p className="text-[10px] text-[#e6ded1] font-light leading-relaxed line-clamp-3">
                    {formData.description}
                  </p>
                ) : (
                  <div className="text-[10px] text-white/30 italic">[Descrição apagada]</div>
                )}

                {/* Mini Badges Preview */}
                {formData.badges.length > 0 && (
                  <div className="pt-2 mt-2 border-t border-white/20 grid grid-cols-2 gap-2 text-[9px]">
                    {formData.badges.slice(0, 4).map((badge) => (
                      <div key={badge.id} className="truncate">
                        <span className="font-bold text-white block truncate">{badge.title}</span>
                        {badge.subtitle && (
                          <span className="text-stone-300 block text-[8px] truncate">{badge.subtitle}</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}

              </div>
            </div>

            <div className="mt-3 text-[11px] text-[#78716c] flex items-center justify-between">
              <span>Fotografia em alta resolução inclusa</span>
              <button
                type="button"
                onClick={handleSave}
                className="text-[#2d3a29] font-bold hover:underline cursor-pointer"
              >
                Salvar para o site
              </button>
            </div>
          </div>

          {/* Quick Guidance Box */}
          <div className="bg-[#FAF9F5] border border-[#e5decb] rounded-2xl p-4 text-xs text-[#57534e] space-y-2">
            <div className="font-bold text-[#1c1917] flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#2d3a29]" />
              <span>Dicas de Edição</span>
            </div>
            <ul className="list-disc pl-4 space-y-1 text-[11px] text-[#78716c]">
              <li>Para <strong>apagar</strong> qualquer texto, basta limpar o campo ou clicar em "Apagar".</li>
              <li>Para <strong>inserir</strong> novas vantagens, use o botão "Inserir Destaque".</li>
              <li>Todas as alterações são salvas e persistidas no seu navegador.</li>
            </ul>
          </div>
        </div>

      </div>

    </div>
  );
};
