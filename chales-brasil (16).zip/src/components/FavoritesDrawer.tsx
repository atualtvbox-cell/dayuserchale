import React from 'react';
import { X, Bookmark, ArrowRight, Trash2, Star } from 'lucide-react';
import { Chalet } from '../types';

interface FavoritesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  favoriteChalets: Chalet[];
  onRemoveFavorite: (chaletId: string) => void;
  onSelectChalet: (chalet: Chalet) => void;
  onOpenGallery?: (chalet: Chalet) => void;
}

export const FavoritesDrawer: React.FC<FavoritesDrawerProps> = ({
  isOpen,
  onClose,
  favoriteChalets,
  onRemoveFavorite,
  onSelectChalet,
  onOpenGallery,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-md bg-[#FAF9F5] text-[#1c1917] h-full shadow-2xl flex flex-col border-l border-[#e5decb] animate-slideInRight">
        
        {/* Header */}
        <div className="p-6 border-b border-[#e9e3d5] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-[#2d3a29] fill-[#2d3a29]" />
            <h2 className="font-serif-luxury text-2xl font-semibold text-[#1c1917]">
              Chalés Salvos
            </h2>
            <span className="text-xs font-mono tabular-nums bg-[#ede6d8] px-2 py-0.5 rounded-full text-[#44403c]">
              {favoriteChalets.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#ede6d8] text-[#78716c] hover:text-[#1c1917] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {favoriteChalets.length === 0 ? (
            <div className="text-center py-16 px-4 text-[#78716c] space-y-3">
              <Bookmark className="w-10 h-10 mx-auto text-[#c7baa4]" />
              <h3 className="font-serif-luxury text-xl text-[#1c1917]">
                Nenhum refúgio salvo ainda
              </h3>
              <p className="text-xs leading-relaxed max-w-xs mx-auto">
                Clique no ícone de marcador nos chalés que você mais amar para salvá-los e comparar depois.
              </p>
            </div>
          ) : (
            favoriteChalets.map((chalet) => (
              <div
                key={chalet.id}
                className="bg-white border border-[#e9e3d5] rounded-xl overflow-hidden shadow-sm hover:border-[#cfc6b4] transition-all flex flex-col"
              >
                <div className="flex gap-4 p-3.5">
                  <img
                    src={chalet.coverImage}
                    alt={chalet.name}
                    onClick={() => {
                      if (onOpenGallery) {
                        onOpenGallery(chalet);
                        onClose();
                      } else {
                        onSelectChalet(chalet);
                        onClose();
                      }
                    }}
                    className="w-24 h-24 rounded-lg object-cover bg-[#2d3a29] cursor-pointer hover:opacity-90 transition-opacity"
                    title="Clique para abrir a galeria de fotos"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-[#78716c] uppercase tracking-wider truncate">
                          {chalet.city} · {chalet.state}
                        </span>
                        <button
                          onClick={() => onRemoveFavorite(chalet.id)}
                          className="text-[#a8a29e] hover:text-red-600 transition-colors p-1"
                          title="Remover"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <h4
                        onClick={() => {
                          onSelectChalet(chalet);
                          onClose();
                        }}
                        className="font-serif-luxury text-base font-semibold text-[#1c1917] hover:text-[#2d3a29] cursor-pointer truncate"
                      >
                        {chalet.name}
                      </h4>
                      <div className="flex items-center text-xs text-[#2d3a29] font-medium mt-0.5">
                        <Star className="w-3 h-3 fill-[#2d3a29] mr-0.5" />
                        <span>{chalet.rating.toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-[#f2ede4] mt-2">
                      <div className="text-xs font-mono font-semibold text-[#1c1917]">
                        R$ {chalet.pricePerNight.toLocaleString('pt-BR')} <span className="text-[10px] font-normal text-[#78716c]">/ noite</span>
                      </div>
                      <button
                        onClick={() => {
                          onSelectChalet(chalet);
                          onClose();
                        }}
                        className="text-xs font-semibold text-[#222c1f] hover:underline flex items-center gap-0.5"
                      >
                        <span>Ver</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {favoriteChalets.length > 0 && (
          <div className="p-4 bg-white border-t border-[#e9e3d5]">
            <p className="text-[11px] text-[#78716c] text-center">
              Os preços podem variar conforme a data e temporada selecionada.
            </p>
          </div>
        )}

      </div>
    </div>
  );
};
