import React from 'react';
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from 'lucide-react';
import { ToastNotification } from '../types';

interface ToastContainerProps {
  toasts: ToastNotification[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-24 right-4 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        let borderClass = 'border-[#2d3a29]';
        let bgIconClass = 'text-emerald-700 bg-emerald-50';
        let IconComponent = CheckCircle2;

        if (toast.type === 'warning') {
          borderClass = 'border-amber-600';
          bgIconClass = 'text-amber-700 bg-amber-50';
          IconComponent = AlertTriangle;
        } else if (toast.type === 'error') {
          borderClass = 'border-red-600';
          bgIconClass = 'text-red-700 bg-red-50';
          IconComponent = XCircle;
        } else if (toast.type === 'info') {
          borderClass = 'border-[#222c1f]';
          bgIconClass = 'text-[#222c1f] bg-[#f4efe4]';
          IconComponent = Info;
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto bg-white/95 backdrop-blur-md border-l-4 ${borderClass} border-y border-r border-[#e5decb] rounded-xl p-4 shadow-xl flex items-start gap-3 transform transition-all duration-300 animate-slideInRight`}
          >
            <div className={`p-1.5 rounded-lg ${bgIconClass} shrink-0 mt-0.5`}>
              <IconComponent className="w-4 h-4" />
            </div>

            <div className="flex-1 min-w-0">
              <h5 className="font-serif-luxury font-bold text-sm text-[#1c1917] leading-snug">
                {toast.title}
              </h5>
              <p className="text-xs text-[#57534e] mt-0.5 leading-relaxed">
                {toast.message}
              </p>
            </div>

            <button
              onClick={() => onDismiss(toast.id)}
              className="text-[#a8a29e] hover:text-[#1c1917] transition-colors p-1"
              title="Fechar notificação"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
