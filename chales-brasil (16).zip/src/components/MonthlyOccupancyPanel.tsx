import React, { useState, useMemo } from 'react';
import { 
  BarChart3, TrendingUp, Calendar, DollarSign, Snowflake, 
  Sun, Flower2, Filter, ArrowUpRight, Info, CheckCircle2,
  Percent, Sparkles, Building2, Flame, BedDouble, AlertCircle
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  ReferenceLine
} from 'recharts';
import { Chalet, Reservation } from '../types';

interface MonthlyOccupancyPanelProps {
  chalets: Chalet[];
  reservations: Reservation[];
}

interface MonthOccupancyRecord {
  monthKey: string; // '01' - '12'
  monthName: string;
  shortName: string;
  season: 'Inverno' | 'Primavera' | 'Verão' | 'Outono';
  isHighSeason: boolean;
  highSeasonBadge: string;
  highSeasonReason: string;
  baseNights: number;
  baseRevenue: number;
  totalNights: number;
  maxCapacityNights: number;
  occupancyRate: number; // 0 to 100%
  totalRevenue: number;
  avgDailyRate: number;
}

export const MonthlyOccupancyPanel: React.FC<MonthlyOccupancyPanelProps> = ({
  chalets,
  reservations,
}) => {
  const [metricMode, setMetricMode] = useState<'occupancy' | 'nights' | 'revenue'>('occupancy');
  const [selectedChaletId, setSelectedChaletId] = useState<string>('all');
  const [seasonFilter, setSeasonFilter] = useState<'all' | 'high' | 'inverno' | 'verao' | 'outono' | 'primavera'>('all');

  // Baseline calibration for mountain luxury chalets (Serra da Mantiqueira, Serra Gaúcha, Serra Catarinense)
  const baselineMonths = [
    {
      monthKey: '01',
      monthName: 'Janeiro',
      shortName: 'Jan',
      season: 'Verão' as const,
      isHighSeason: false,
      highSeasonBadge: 'Média-Alta (Férias)',
      highSeasonReason: 'Férias de verão; turistas buscando o clima ameno da montanha e banhos de cachoeira.',
      baseNights: 120,
      baseRevenue: 106400,
    },
    {
      monthKey: '02',
      monthName: 'Fevereiro',
      shortName: 'Fev',
      season: 'Verão' as const,
      isHighSeason: false,
      highSeasonBadge: 'Carnaval na Serra',
      highSeasonReason: 'Pico de Carnaval de 4 noites com 100% de ocupação; restante do mês com demanda moderada.',
      baseNights: 110,
      baseRevenue: 98000,
    },
    {
      monthKey: '03',
      monthName: 'Março',
      shortName: 'Mar',
      season: 'Outono' as const,
      isHighSeason: false,
      highSeasonBadge: 'Média Temporada',
      highSeasonReason: 'Transição suave para o outono; queda nas temperaturas noturnas e céu limpo.',
      baseNights: 95,
      baseRevenue: 82000,
    },
    {
      monthKey: '04',
      monthName: 'Abril',
      shortName: 'Abr',
      season: 'Outono' as const,
      isHighSeason: false,
      highSeasonBadge: 'Páscoa & Tiradentes',
      highSeasonReason: 'Feriados prolongados com forte procura; início das lareiras acesas e fondue.',
      baseNights: 135,
      baseRevenue: 128000,
    },
    {
      monthKey: '05',
      monthName: 'Maio',
      shortName: 'Mai',
      season: 'Outono' as const,
      isHighSeason: false,
      highSeasonBadge: 'Pré-Alta Temporada',
      highSeasonReason: 'Frio pronunciado (temperaturas mínimas de 7°C); alta demanda para viagens a dois.',
      baseNights: 155,
      baseRevenue: 155800,
    },
    {
      monthKey: '06',
      monthName: 'Junho',
      shortName: 'Jun',
      season: 'Inverno' as const,
      isHighSeason: true,
      highSeasonBadge: '🔥 Alta Temporada (Pico de Inverno)',
      highSeasonReason: 'Abertura oficial da alta temporada de inverno; geadas matinais, vinhos, queijos artesanais e lareiras.',
      baseNights: 215,
      baseRevenue: 242000,
    },
    {
      monthKey: '07',
      monthName: 'Julho',
      shortName: 'Jul',
      season: 'Inverno' as const,
      isHighSeason: true,
      highSeasonBadge: '🔥 Pico Máximo Anual',
      highSeasonReason: 'Mês mais concorrido do ano no turismo de serra; férias escolares de inverno com lotação máxima antecipada.',
      baseNights: 232,
      baseRevenue: 295000,
    },
    {
      monthKey: '08',
      monthName: 'Agosto',
      shortName: 'Ago',
      season: 'Inverno' as const,
      isHighSeason: true,
      highSeasonBadge: '🔥 Alta Temporada (Inverno Estendido)',
      highSeasonReason: 'Continuação do frio seco serrano; céus perfeitamente limpos para observação de estrelas e degustações.',
      baseNights: 198,
      baseRevenue: 218000,
    },
    {
      monthKey: '09',
      monthName: 'Setembro',
      shortName: 'Set',
      season: 'Primavera' as const,
      isHighSeason: false,
      highSeasonBadge: 'Florada & Enoturismo',
      highSeasonReason: 'Florada das cerejeiras e hortênsias na serra; turismo enológico aquecido.',
      baseNights: 140,
      baseRevenue: 139400,
    },
    {
      monthKey: '10',
      monthName: 'Outubro',
      shortName: 'Out',
      season: 'Primavera' as const,
      isHighSeason: false,
      highSeasonBadge: 'Média Temporada',
      highSeasonReason: 'Clima ameno e agradável; procura estável para casais e retiros de descanso.',
      baseNights: 130,
      baseRevenue: 125000,
    },
    {
      monthKey: '11',
      monthName: 'Novembro',
      shortName: 'Nov',
      season: 'Primavera' as const,
      isHighSeason: false,
      highSeasonBadge: 'Feriados de Primavera',
      highSeasonReason: 'Feriados de Finados e República com excelente ocupação nos finais de semana.',
      baseNights: 138,
      baseRevenue: 132000,
    },
    {
      monthKey: '12',
      monthName: 'Dezembro',
      shortName: 'Dez',
      season: 'Verão' as const,
      isHighSeason: true,
      highSeasonBadge: '🔥 Alta Temporada (Festas & Réveillon)',
      highSeasonReason: 'Pacotes fechados de Natal Luz e Réveillon na montanha com queima de fogos ecológica e ceia colonial.',
      baseNights: 218,
      baseRevenue: 245000,
    },
  ];

  // Compute dynamic monthly data based on real reservations + baseline
  const monthlyData: MonthOccupancyRecord[] = useMemo(() => {
    const totalChaletsCount = selectedChaletId === 'all' ? (chalets.length || 8) : 1;
    const maxCapacityNights = totalChaletsCount * 30; // 30 dias médios
    const scaleFactor = selectedChaletId === 'all' ? 1 : 1 / (chalets.length || 8);

    // Filter live reservations
    const liveConfirmed = reservations.filter((r) => {
      if (selectedChaletId !== 'all' && r.chaletId !== selectedChaletId) return false;
      return r.status !== 'cancelada' && r.status !== 'expirada';
    });

    return baselineMonths.map((base) => {
      // Find reservations for this month
      const liveForMonth = liveConfirmed.filter((r) => {
        const checkInMonth = r.checkIn ? r.checkIn.substring(5, 7) : '';
        return checkInMonth === base.monthKey;
      });

      const liveNights = liveForMonth.reduce((acc, r) => acc + (r.nights || 2), 0);
      const liveRev = liveForMonth.reduce((acc, r) => acc + (r.totalPrice || 0), 0);

      const scaledBaseNights = Math.round(base.baseNights * scaleFactor);
      const scaledBaseRevenue = Math.round(base.baseRevenue * scaleFactor);

      const totalNights = Math.min(maxCapacityNights, scaledBaseNights + liveNights);
      const totalRevenue = scaledBaseRevenue + liveRev;
      
      const occupancyRate = Math.min(98, Math.max(30, Math.round((totalNights / maxCapacityNights) * 100)));
      const avgDailyRate = totalNights > 0 ? Math.round(totalRevenue / totalNights) : 850;

      return {
        ...base,
        baseNights: scaledBaseNights,
        baseRevenue: scaledBaseRevenue,
        totalNights,
        maxCapacityNights,
        occupancyRate,
        totalRevenue,
        avgDailyRate,
      };
    });
  }, [chalets, reservations, selectedChaletId]);

  // Filter by season or high-season flag
  const displayedData = useMemo(() => {
    if (seasonFilter === 'high') {
      return monthlyData.filter((m) => m.isHighSeason);
    }
    if (seasonFilter === 'inverno') {
      return monthlyData.filter((m) => m.season === 'Inverno');
    }
    if (seasonFilter === 'verao') {
      return monthlyData.filter((m) => m.season === 'Verão');
    }
    if (seasonFilter === 'outono') {
      return monthlyData.filter((m) => m.season === 'Outono');
    }
    if (seasonFilter === 'primavera') {
      return monthlyData.filter((m) => m.season === 'Primavera');
    }
    return monthlyData;
  }, [monthlyData, seasonFilter]);

  // Overall Statistics for KPIs
  const kpiStats = useMemo(() => {
    const avgYearOccupancy = Math.round(
      monthlyData.reduce((acc, m) => acc + m.occupancyRate, 0) / monthlyData.length
    );

    const highSeasonMonths = monthlyData.filter((m) => m.isHighSeason);
    const avgHighSeasonOccupancy = Math.round(
      highSeasonMonths.reduce((acc, m) => acc + m.occupancyRate, 0) / highSeasonMonths.length
    );

    const peakMonth = [...monthlyData].sort((a, b) => b.occupancyRate - a.occupancyRate)[0];

    const totalNightsYear = monthlyData.reduce((acc, m) => acc + m.totalNights, 0);
    const totalRevYear = monthlyData.reduce((acc, m) => acc + m.totalRevenue, 0);

    const winterRev = monthlyData
      .filter((m) => m.season === 'Inverno')
      .reduce((acc, m) => acc + m.totalRevenue, 0);
    const winterShare = totalRevYear > 0 ? Math.round((winterRev / totalRevYear) * 100) : 0;

    return {
      avgYearOccupancy,
      avgHighSeasonOccupancy,
      peakMonth,
      totalNightsYear,
      totalRevYear,
      winterRev,
      winterShare,
    };
  }, [monthlyData]);

  // Custom Recharts Tooltip
  const CustomBarTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const item = monthlyData.find((d) => d.shortName === label || d.monthName === label);
      if (!item) return null;

      return (
        <div className="bg-[#1c1917] text-white p-4 rounded-2xl shadow-2xl border border-white/20 text-xs max-w-xs space-y-2.5">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div>
              <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                item.isHighSeason ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-white/10 text-stone-300'
              }`}>
                {item.season} · {item.isHighSeason ? 'Alta Temporada' : 'Média Temporada'}
              </span>
              <h4 className="font-serif-luxury text-base font-bold text-white mt-1">
                {item.monthName}
              </h4>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-stone-400 block">Ocupação</span>
              <span className="text-lg font-bold font-mono text-emerald-400">
                {item.occupancyRate}%
              </span>
            </div>
          </div>

          <div className="space-y-1.5 text-[11px] text-stone-300">
            <div className="flex justify-between">
              <span className="text-stone-400">Diárias Reservadas:</span>
              <span className="font-mono font-bold text-white">
                {item.totalNights} de {item.maxCapacityNights} noites
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-400">Faturamento Projetado:</span>
              <span className="font-mono font-bold text-emerald-300">
                R$ {item.totalRevenue.toLocaleString('pt-BR')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-400">Diária Média (ADR):</span>
              <span className="font-mono text-white">
                R$ {item.avgDailyRate.toLocaleString('pt-BR')}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-amber-200/90 bg-amber-950/40 p-2 rounded-lg border border-amber-700/30 leading-relaxed italic">
            "{item.highSeasonReason}"
          </p>
        </div>
      );
    }
    return null;
  };

  // Color generator for bars
  const getBarColor = (item: MonthOccupancyRecord) => {
    if (metricMode === 'occupancy') {
      if (item.occupancyRate >= 85) return '#2563eb'; // Royal Blue for Ultra High Peak
      if (item.occupancyRate >= 75) return '#3b82f6'; // Bright Blue for High Season
      if (item.occupancyRate >= 60) return '#d97706'; // Amber for Autumn/Spring moderate
      return '#78716c'; // Neutral Stone for lower months
    }
    if (metricMode === 'revenue') {
      return item.isHighSeason ? '#059669' : '#10b981';
    }
    // nights
    return item.isHighSeason ? '#6366f1' : '#818cf8';
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#222c1f] via-[#2c3928] to-[#1c2419] text-white p-6 sm:p-8 rounded-3xl shadow-md border border-[#3e4d3a] flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest">
            <BarChart3 className="w-4 h-4" />
            <span>Inteligência de Mercado & Planejamento Tarifário</span>
          </div>
          <h2 className="font-serif-luxury text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
            Ocupação Mensal & Alta Temporada
          </h2>
          <p className="text-xs sm:text-sm text-stone-300 max-w-2xl leading-relaxed">
            Monitore a taxa de ocupação dos chalés mês a mês em gráfico de barras para identificar os picos de inverno e datas festivas, otimizando tarifas e exigência de estadias mínimas.
          </p>
        </div>

        {/* Quick Season Badge Summary */}
        <div className="flex flex-wrap lg:flex-col gap-2 shrink-0 bg-white/10 backdrop-blur-xs p-4 rounded-2xl border border-white/15 text-xs">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-white">Alta Temporada:</span>
            <span className="text-amber-300 font-mono font-bold">Jun, Jul, Ago e Dez</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-stone-300">
            <Snowflake className="w-3.5 h-3.5 text-blue-300" />
            <span>Inverno concentra <strong>{kpiStats.winterShare}%</strong> da receita anual</span>
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Média Alta Temporada */}
        <div className="bg-white border border-[#ded7c4] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
            <span>Ocupação em Alta Temporada</span>
            <Flame className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] mt-2 tabular-nums flex items-baseline gap-1">
            <span>{kpiStats.avgHighSeasonOccupancy}%</span>
            <span className="text-xs text-emerald-700 font-bold font-sans">Pico Máximo</span>
          </div>
          <p className="text-[11px] text-[#78716c] mt-1">Média dos meses de Jun, Jul, Ago e Dez</p>
        </div>

        {/* Card 2: Mês de Maior Ocupação */}
        <div className="bg-white border border-[#ded7c4] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
            <span>Mês Mais Concorrido</span>
            <Snowflake className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-blue-900 mt-2 tabular-nums">
            {kpiStats.peakMonth.monthName} ({kpiStats.peakMonth.occupancyRate}%)
          </div>
          <p className="text-[11px] text-blue-700 mt-1">
            {kpiStats.peakMonth.totalNights} diárias reservadas no período
          </p>
        </div>

        {/* Card 3: Média Anual de Ocupação */}
        <div className="bg-white border border-[#ded7c4] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
            <span>Média Anual de Ocupação</span>
            <Percent className="w-4 h-4 text-[#2d3a29]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] mt-2 tabular-nums">
            {kpiStats.avgYearOccupancy}%
          </div>
          <p className="text-[11px] text-emerald-700 font-medium mt-1">
            Supera o benchmark hoteleiro de 55%
          </p>
        </div>

        {/* Card 4: Faturamento Projetado */}
        <div className="bg-white border border-[#ded7c4] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
            <span>Faturamento Anual Previsto</span>
            <DollarSign className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-950 mt-2 tabular-nums">
            R$ {(kpiStats.totalRevYear / 1000).toFixed(0)}k
          </div>
          <p className="text-[11px] text-[#78716c] mt-1">
            Total de {kpiStats.totalNightsYear} noites nos chalés
          </p>
        </div>

      </div>

      {/* Main Chart Box */}
      <div className="bg-white border border-[#ded7c4] rounded-3xl p-6 shadow-sm space-y-6">
        
        {/* Chart Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#f0ece1] pb-4">
          
          <div>
            <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
              {metricMode === 'occupancy' && 'Taxa de Ocupação Mensal (%)'}
              {metricMode === 'nights' && 'Diárias Reservadas vs Capacidade (Noites)'}
              {metricMode === 'revenue' && 'Faturamento Mensal Estimado (R$)'}
            </h3>
            <p className="text-xs text-[#78716c] mt-0.5">
              Barras destacadas indicam os meses de <strong>Alta Temporada</strong> com maior pressão de demanda.
            </p>
          </div>

          {/* Metric View Switcher */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[#FAF9F5] border border-[#e5decb] rounded-xl text-xs">
            <button
              type="button"
              onClick={() => setMetricMode('occupancy')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                metricMode === 'occupancy'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'text-[#57534e] hover:text-[#1c1917]'
              }`}
            >
              Taxa de Ocupação (%)
            </button>
            <button
              type="button"
              onClick={() => setMetricMode('nights')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                metricMode === 'nights'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'text-[#57534e] hover:text-[#1c1917]'
              }`}
            >
              Diárias Reservadas
            </button>
            <button
              type="button"
              onClick={() => setMetricMode('revenue')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                metricMode === 'revenue'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'text-[#57534e] hover:text-[#1c1917]'
              }`}
            >
              Faturamento (R$)
            </button>
          </div>

        </div>

        {/* Filters Row: By Chalet and By Season */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-[#FAF9F5] p-3 rounded-2xl border border-[#ede6d8]">
          <div className="flex flex-wrap items-center gap-3">
            
            {/* Filter Chalet */}
            <div className="flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5 text-[#78716c]" />
              <label className="font-semibold text-[#44403c]">Propriedade:</label>
              <select
                value={selectedChaletId}
                onChange={(e) => setSelectedChaletId(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-[#d6cdbd] bg-white text-xs font-medium text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
              >
                <option value="all">Coleção Inteira ({chalets.length} chalés)</option>
                {chalets.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.city})
                  </option>
                ))}
              </select>
            </div>

            {/* Filter Season */}
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-[#78716c]" />
              <label className="font-semibold text-[#44403c]">Filtro de Época:</label>
              <select
                value={seasonFilter}
                onChange={(e) => setSeasonFilter(e.target.value as any)}
                className="px-3 py-1.5 rounded-lg border border-[#d6cdbd] bg-white text-xs font-medium text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
              >
                <option value="all">Ano Completo (12 Meses)</option>
                <option value="high">Apenas Alta Temporada (Jun, Jul, Ago, Dez)</option>
                <option value="inverno">Somente Inverno (Junho a Agosto)</option>
                <option value="outono">Somente Outono (Março a Maio)</option>
                <option value="primavera">Somente Primavera (Setembro a Novembro)</option>
                <option value="verao">Somente Verão (Dezembro a Fevereiro)</option>
              </select>
            </div>

          </div>

          {/* Reference Legend */}
          <div className="flex items-center gap-3 text-[11px] text-[#78716c]">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-[#2563eb]" />
              <span>Pico de Alta Temporada (≥80%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-[#d97706]" />
              <span>Média Temporada (60-79%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-[#78716c]" />
              <span>Normal (&lt;60%)</span>
            </div>
          </div>

        </div>

        {/* The Recharts Bar Chart */}
        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={displayedData}
              margin={{ top: 20, right: 20, left: -10, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0ece1" />
              <XAxis
                dataKey="shortName"
                tick={{ fill: '#44403c', fontSize: 12, fontWeight: 500 }}
                axisLine={{ stroke: '#ded7c4' }}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: '#78716c', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                domain={
                  metricMode === 'occupancy' 
                    ? [0, 100] 
                    : metricMode === 'nights'
                      ? [0, (dataMax: number) => Math.ceil(dataMax * 1.15)]
                      : [0, (dataMax: number) => Math.ceil(dataMax * 1.15)]
                }
                tickFormatter={(val) => {
                  if (metricMode === 'occupancy') return `${val}%`;
                  if (metricMode === 'revenue') return `R$ ${(val / 1000).toFixed(0)}k`;
                  return `${val}`;
                }}
              />
              <Tooltip content={<CustomBarTooltip />} />

              {/* Reference line for 80% High Season threshold in Occupancy mode */}
              {metricMode === 'occupancy' && (
                <ReferenceLine
                  y={80}
                  stroke="#ef4444"
                  strokeDasharray="4 4"
                  label={{
                    value: 'Limite de Alta Temporada (80%)',
                    fill: '#b91c1c',
                    fontSize: 10,
                    fontWeight: 600,
                    position: 'top',
                  }}
                />
              )}

              <Bar
                dataKey={
                  metricMode === 'occupancy'
                    ? 'occupancyRate'
                    : metricMode === 'nights'
                      ? 'totalNights'
                      : 'totalRevenue'
                }
                radius={[8, 8, 0, 0]}
                maxBarSize={48}
              >
                {displayedData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={getBarColor(entry)}
                    className="transition-all hover:opacity-85 cursor-pointer"
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Season Badges Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          
          <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200 text-left space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900">
              <Snowflake className="w-3.5 h-3.5 text-blue-600" />
              <span>Inverno (Junho a Agosto)</span>
            </div>
            <div className="text-lg font-bold font-mono text-blue-950">
              ~90% Ocupação
            </div>
            <p className="text-[11px] text-blue-800 leading-tight">
              Pico absoluto de demanda serrana. Recomendação: diárias premium com estadia mínima de 3 noites.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-left space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Festas de Fim de Ano (Dez)</span>
            </div>
            <div className="text-lg font-bold font-mono text-emerald-950">
              ~91% Ocupação
            </div>
            <p className="text-[11px] text-emerald-800 leading-tight">
              Natal Luz e Réveillon. 100% dos pacotes vendidos com 60 dias de antecedência.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 text-left space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
              <Flower2 className="w-3.5 h-3.5 text-amber-600" />
              <span>Outono & Páscoa (Abr a Mai)</span>
            </div>
            <div className="text-lg font-bold font-mono text-amber-950">
              ~65% Ocupação
            </div>
            <p className="text-[11px] text-amber-800 leading-tight">
              Transição para o frio. Forte busca em feriados de Páscoa e festivais gastronômicos.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 text-left space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#44403c]">
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Primavera & Verão (Set a Nov)</span>
            </div>
            <div className="text-lg font-bold font-mono text-[#1c1917]">
              ~55% Ocupação
            </div>
            <p className="text-[11px] text-[#78716c] leading-tight">
              Oportunidade ideal para campanhas de desconto promocional (-5% no PIX) e retiros de bem-estar.
            </p>
          </div>

        </div>

      </div>

      {/* Monthly Breakdown Data Table */}
      <div className="bg-white border border-[#ded7c4] rounded-3xl overflow-hidden shadow-xs">
        <div className="p-5 border-b border-[#f0ece1] flex items-center justify-between">
          <div>
            <h4 className="font-serif-luxury text-base font-bold text-[#1c1917]">
              Tabela Detalhada de Ocupação e Receita Mensal
            </h4>
            <p className="text-xs text-[#78716c]">
              Comparativo de diárias reservadas versus teto de capacidade dos chalés.
            </p>
          </div>
          <span className="text-xs font-mono bg-[#FAF9F5] px-3 py-1 rounded-lg border border-[#e5decb] text-[#57534e]">
            {monthlyData.length} Meses Mapeados
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAF9F5] text-[#57534e] uppercase text-[10px] tracking-wider border-b border-[#ded7c4]">
              <tr>
                <th className="py-3 px-4 font-semibold">Mês</th>
                <th className="py-3 px-4 font-semibold">Estação</th>
                <th className="py-3 px-4 font-semibold">Classificação</th>
                <th className="py-3 px-4 font-semibold">Taxa de Ocupação</th>
                <th className="py-3 px-4 font-semibold text-right">Noites Reservadas</th>
                <th className="py-3 px-4 font-semibold text-right">Diária Média</th>
                <th className="py-3 px-4 font-semibold text-right">Faturamento Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f0ece1]">
              {monthlyData.map((item) => (
                <tr
                  key={item.monthKey}
                  className={`hover:bg-[#FAF9F5] transition-colors ${
                    item.isHighSeason ? 'bg-blue-50/20' : ''
                  }`}
                >
                  <td className="py-3.5 px-4 font-bold text-[#1c1917]">
                    {item.monthName}
                  </td>
                  <td className="py-3.5 px-4 text-[#57534e]">
                    {item.season}
                  </td>
                  <td className="py-3.5 px-4">
                    {item.isHighSeason ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                        <Flame className="w-3 h-3 text-amber-700" />
                        <span>Alta Temporada</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-stone-100 text-stone-700">
                        Média/Normal
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-stone-200 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            item.occupancyRate >= 80 
                              ? 'bg-blue-600' 
                              : item.occupancyRate >= 65 
                                ? 'bg-amber-500' 
                                : 'bg-stone-500'
                          }`}
                          style={{ width: `${item.occupancyRate}%` }}
                        />
                      </div>
                      <span className="font-mono font-bold text-[#1c1917] tabular-nums">
                        {item.occupancyRate}%
                      </span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-[#44403c]">
                    {item.totalNights} <span className="text-[#a8a29e]">/ {item.maxCapacityNights}</span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-[#2d3a29]">
                    R$ {item.avgDailyRate.toLocaleString('pt-BR')}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-[#1c1917]">
                    R$ {item.totalRevenue.toLocaleString('pt-BR')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
