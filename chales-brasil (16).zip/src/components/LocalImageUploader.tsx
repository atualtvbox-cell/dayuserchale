import React, { useRef, useState } from 'react';
import { UploadCloud, Image as ImageIcon, X, Check, RefreshCw } from 'lucide-react';
import { fileToOptimizedDataUrl } from '../utils/imageUpload';

interface LocalImageUploaderProps {
  label: string;
  helperText?: string;
  currentValue?: string;
  onImageSelected: (dataUrl: string) => void;
  aspectRatio?: 'landscape' | 'square';
  maxWidth?: number;
  maxHeight?: number;
}

export const LocalImageUploader: React.FC<LocalImageUploaderProps> = ({
  label,
  helperText,
  currentValue,
  onImageSelected,
  aspectRatio = 'landscape',
  maxWidth = 1200,
  maxHeight = 900,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleProcessFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Por favor, selecione um arquivo de imagem (JPEG, PNG, WEBP).');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      const dataUrl = await fileToOptimizedDataUrl(file, maxWidth, maxHeight, 0.85);
      onImageSelected(dataUrl);
    } catch (err: any) {
      setError(err?.message || 'Falha ao processar a imagem do computador.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
    // reset input value so selecting the same file triggers change
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-semibold text-[#44403c]">{label}</label>
        {helperText && <span className="text-[11px] text-[#78716c]">{helperText}</span>}
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/png, image/jpeg, image/jpg, image/webp"
        onChange={handleFileChange}
        className="hidden"
      />

      {currentValue ? (
        <div className="relative group rounded-xl overflow-hidden border border-[#d6cdbd] bg-[#222c1f]/5">
          <img
            src={currentValue}
            alt="Preview selecionado"
            className={`w-full object-cover ${
              aspectRatio === 'square' ? 'aspect-square h-28' : 'aspect-[16/9] max-h-48'
            }`}
          />
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-lg bg-white text-[#1c1917] text-xs font-semibold hover:bg-[#ede6d8] transition-colors flex items-center gap-1 shadow-sm"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Trocar Foto</span>
            </button>
            <button
              type="button"
              onClick={() => onImageSelected('')}
              className="p-1.5 rounded-lg bg-red-600 text-white hover:bg-red-700 transition-colors shadow-sm"
              title="Remover foto"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
            <Check className="w-3 h-3 text-emerald-400" />
            <span>Imagem do Computador Ativa</span>
          </div>
        </div>
      ) : (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-colors ${
            isDragging
              ? 'border-[#222c1f] bg-[#f4efe4]'
              : 'border-[#d6cdbd] hover:border-[#222c1f] bg-[#FAF9F5]'
          }`}
        >
          {isLoading ? (
            <div className="py-4 space-y-2 text-[#78716c]">
              <RefreshCw className="w-6 h-6 mx-auto animate-spin text-[#222c1f]" />
              <p className="text-xs">Otimizando imagem do computador...</p>
            </div>
          ) : (
            <div className="py-2 space-y-1.5 text-[#57534e]">
              <div className="w-9 h-9 rounded-full bg-[#ede6d8] text-[#222c1f] flex items-center justify-center mx-auto">
                <UploadCloud className="w-5 h-5" />
              </div>
              <div className="text-xs font-semibold text-[#1c1917]">
                Clique para escolher do seu computador
              </div>
              <p className="text-[11px] text-[#78716c]">
                ou arraste e solte o arquivo aqui (JPEG, PNG ou WEBP)
              </p>
            </div>
          )}
        </div>
      )}

      {error && <p className="text-[11px] text-red-600 font-medium">{error}</p>}
    </div>
  );
};
