import React, { useRef, useState } from 'react';
import { Plus, X, UploadCloud, RefreshCw } from 'lucide-react';
import { fileToOptimizedDataUrl } from '../utils/imageUpload';

interface LocalGalleryUploaderProps {
  label: string;
  images: string[];
  onChange: (images: string[]) => void;
}

export const LocalGalleryUploader: React.FC<LocalGalleryUploaderProps> = ({
  label,
  images,
  onChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    setIsLoading(true);
    const newImages: string[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/')) {
        try {
          const dataUrl = await fileToOptimizedDataUrl(file, 1200, 900, 0.82);
          newImages.push(dataUrl);
        } catch (e) {
          console.error('Erro ao converter arquivo:', file.name, e);
        }
      }
    }

    onChange([...images, ...newImages]);
    setIsLoading(false);

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleRemoveImage = (indexToRemove: number) => {
    onChange(images.filter((_, idx) => idx !== indexToRemove));
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="block text-xs font-semibold text-[#44403c]">{label}</label>
        <span className="text-[11px] text-[#78716c]">{images.length} fotos na galeria</span>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={(e) => handleFiles(e.target.files)}
        className="hidden"
      />

      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
        {images.map((img, idx) => (
          <div
            key={idx}
            className="relative group aspect-[4/3] rounded-lg overflow-hidden border border-[#d6cdbd] bg-[#222c1f]/5"
          >
            <img src={img} alt={`Foto ${idx + 1}`} className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => handleRemoveImage(idx)}
              className="absolute top-1 right-1 p-1 rounded-md bg-black/70 hover:bg-red-600 text-white transition-colors opacity-90 group-hover:opacity-100"
              title="Excluir da galeria"
            >
              <X className="w-3.5 h-3.5" />
            </button>
            <span className="absolute bottom-1 left-1 text-[9px] bg-black/60 text-white px-1 rounded font-mono">
              #{idx + 1}
            </span>
          </div>
        ))}

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={isLoading}
          className="aspect-[4/3] border-2 border-dashed border-[#c7baa4] hover:border-[#222c1f] rounded-lg flex flex-col items-center justify-center p-2 text-center text-[#57534e] hover:bg-[#f4efe4] transition-colors"
        >
          {isLoading ? (
            <RefreshCw className="w-5 h-5 animate-spin text-[#222c1f]" />
          ) : (
            <>
              <Plus className="w-5 h-5 text-[#222c1f]" />
              <span className="text-[10px] font-semibold mt-1">Carregar Fotos</span>
              <span className="text-[9px] text-[#a8a29e]">do Computador</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
