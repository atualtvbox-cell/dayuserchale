import React, { useState } from 'react';
import { 
  X, Star, MapPin, Users, Flame, Coffee, Wifi, ShieldCheck, 
  Calendar, Check, Copy, Heart, Sparkles, MessageCircle, 
  CreditCard, QrCode, ArrowRight, Share2, Bed, Bath, Compass,
  AlertCircle, ChevronLeft, ChevronRight, Maximize2, Briefcase, Lightbulb, CheckCircle2
} from 'lucide-react';
import { Chalet, Experience, Reservation, CompanySettings } from '../types';
import { getDefaultWhatToBring, getDefaultRegionalTips } from '../data/chaletTipsDefaults';
import { AvailabilityCalendar } from './AvailabilityCalendar';
import { ChaletHostChat } from './ChaletHostChat';

interface ChaletDetailModalProps {
  chalet: Chalet;
  reservations: Reservation[];
  companySettings?: CompanySettings;
  onClose: () => void;
  onConfirmReservation: (reservation: Reservation) => void;
  isFavorite: boolean;
  onToggleFavorite: (chaletId: string) => void;
}

export const ChaletDetailModal: React.FC<ChaletDetailModalProps> = ({
  chalet,
  reservations,
  companySettings,
  onClose,
  onConfirmReservation,
  isFavorite,
  onToggleFavorite,
}) => {
  // Booking state
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [step, setStep] = useState<'details' | 'checkout' | 'success'>('details');
  const [sendWhatsAppOnSubmit, setSendWhatsAppOnSubmit] = useState(true);

  // Clean company WhatsApp phone number
  const companyPhone = companySettings?.phone || '(11) 98765-4321';
  const cleanCompanyDigits = companyPhone.replace(/\D/g, '');
  const companyWhatsAppNumber = cleanCompanyDigits.startsWith('55')
    ? cleanCompanyDigits
    : cleanCompanyDigits.length >= 10
      ? `55${cleanCompanyDigits}`
      : '5511987654321';

  // Check if chalet has upcoming booking to pick default free dates (confirmed or pending 60-min)
  const now = Date.now();
  const activeChaletBookings = reservations.filter((r) => {
    if (r.chaletId !== chalet.id) return false;
    if (r.status === 'confirmada') return true;
    if (r.status === 'pendente') {
      return !r.expiresAt || r.expiresAt > now;
    }
    return false;
  });

  // Find default free dates that do not overlap with any reservation (including entrada and saída)
  const defaultDates = React.useMemo(() => {
    let testDate = new Date(2026, 9, 6);
    for (let i = 0; i < 60; i++) {
      const d1 = new Date(testDate);
      const d2 = new Date(testDate);
      d2.setDate(d2.getDate() + 3);
      const s1 = d1.toISOString().split('T')[0];
      const s2 = d2.toISOString().split('T')[0];
      
      const collides = activeChaletBookings.some((b) => !(s2 < b.checkIn || s1 > b.checkOut));
      if (!collides) {
        return { checkIn: s1, checkOut: s2 };
      }
      testDate.setDate(testDate.getDate() + 1);
    }
    return { checkIn: '2026-10-06', checkOut: '2026-10-09' };
  }, [activeChaletBookings]);

  const [checkIn, setCheckIn] = useState(defaultDates.checkIn);
  const [checkOut, setCheckOut] = useState(defaultDates.checkOut);
  const [guestCount, setGuestCount] = useState(2);
  const [selectedExperienceIds, setSelectedExperienceIds] = useState<string[]>([]);

  // Checkout form
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'cartao'>('pix');
  const [isCopiedPix, setIsCopiedPix] = useState(false);
  const [confirmedReservationCode, setConfirmedReservationCode] = useState('');
  const [currentReservationStatus, setCurrentReservationStatus] = useState<'confirmada' | 'pendente'>('confirmada');
  const [expiresAtTimestamp, setExpiresAtTimestamp] = useState<number | null>(null);

  // What to bring and regional tips state
  const whatToBringList = chalet.whatToBring && chalet.whatToBring.length > 0
    ? chalet.whatToBring
    : getDefaultWhatToBring(chalet);

  const regionalTipsList = chalet.regionalTips && chalet.regionalTips.length > 0
    ? chalet.regionalTips
    : getDefaultRegionalTips(chalet);

  const [activeGuideTab, setActiveGuideTab] = useState<'whatToBring' | 'regionalTips'>('whatToBring');
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const handleToggleCheckItem = (itemText: string) => {
    setCheckedItems((prev) => ({
      ...prev,
      [itemText]: !prev[itemText],
    }));
  };
  const [remainingSeconds, setRemainingSeconds] = useState<number>(3600);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  // Live 1-hour countdown effect
  React.useEffect(() => {
    if (!expiresAtTimestamp || currentReservationStatus !== 'pendente') return;

    const interval = setInterval(() => {
      const diff = Math.max(0, Math.floor((expiresAtTimestamp - Date.now()) / 1000));
      setRemainingSeconds(diff);
      if (diff <= 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [expiresAtTimestamp, currentReservationStatus]);

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Calculate nights
  const date1 = new Date(checkIn);
  const date2 = new Date(checkOut);
  const diffTime = Math.max(1, Math.round((date2.getTime() - date1.getTime()) / (1000 * 60 * 60 * 24)));
  const nights = isNaN(diffTime) || diffTime <= 0 ? 2 : diffTime;

  // Calculate pricing
  const basePrice = chalet.pricePerNight * nights;
  const experiencesTotal = selectedExperienceIds.reduce((sum, expId) => {
    const found = chalet.experiences.find((e) => e.id === expId);
    return sum + (found ? found.price : 0);
  }, 0);
  const cleaningFee = chalet.cleaningFee;
  const rawTotal = basePrice + cleaningFee + experiencesTotal;
  const finalTotal = paymentMethod === 'pix' ? Math.round(rawTotal * 0.95) : rawTotal; // 5% off on Pix

  const handleToggleExperience = (expId: string) => {
    if (selectedExperienceIds.includes(expId)) {
      setSelectedExperienceIds(selectedExperienceIds.filter((id) => id !== expId));
    } else {
      setSelectedExperienceIds([...selectedExperienceIds, expId]);
    }
  };

  const buildWhatsAppMessage = (resCode: string) => {
    return [
      `*Mantiqueira & Co. - Nova Solicitação de Locação* 🏡✨`,
      ``,
      `Olá! Seguem os dados da minha locação realizada pelo site:`,
      ``,
      `📋 *Código da Reserva:* ${resCode || confirmedReservationCode}`,
      `🏡 *Chalé:* ${chalet.name} (${chalet.city}, ${chalet.state})`,
      `👤 *Hóspede Responsável:* ${guestName}`,
      `📱 *WhatsApp do Cliente:* ${guestPhone}`,
      `📧 *E-mail:* ${guestEmail}`,
      ``,
      `📅 *Data de Check-in:* ${checkIn} (a partir das 15h)`,
      `📅 *Data de Check-out:* ${checkOut} (até as 12h)`,
      `🌙 *Estadia:* ${nights} ${nights === 1 ? 'diária' : 'diárias'} · 👥 *Ocupantes:* ${guestCount} ${guestCount === 1 ? 'pessoa' : 'pessoas'}`,
      ``,
      `💳 *Forma de Pagamento:* ${paymentMethod === 'pix' ? 'PIX Instantâneo (-5% OFF)' : 'Cartão de Crédito'}`,
      `💰 *Valor Total:* R$ ${finalTotal.toLocaleString('pt-BR')}`,
      ...(specialRequests ? [``, `📝 *Observações / Pedidos:* ${specialRequests}`] : []),
      ``,
      `Por favor, confirmem o recebimento da minha solicitação de estadia. Obrigado!`,
    ].join('\n');
  };

  const handleFinalizeBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName || !guestEmail || !guestPhone) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    const code = `REF-${Math.floor(100000 + Math.random() * 900000)}`;
    setConfirmedReservationCode(code);

    const isPix = paymentMethod === 'pix';
    const status = isPix ? 'pendente' : 'confirmada';
    const expires = isPix ? Date.now() + 3600 * 1000 : undefined;

    setCurrentReservationStatus(status);
    setExpiresAtTimestamp(expires || null);

    const newReservation: Reservation = {
      id: code,
      chaletId: chalet.id,
      chaletName: chalet.name,
      chaletCity: chalet.city,
      chaletState: chalet.state,
      chaletImage: chalet.coverImage,
      checkIn,
      checkOut,
      nights,
      guests: guestCount,
      selectedExperiences: selectedExperienceIds,
      totalPrice: finalTotal,
      guestName,
      guestEmail,
      guestPhone,
      specialRequests,
      paymentMethod,
      status,
      expiresAt: expires,
      createdAt: new Date().toLocaleDateString('pt-BR'),
    };

    onConfirmReservation(newReservation);
    setStep('success');

    // Se o cliente selecionou a opção de enviar WhatsApp para a empresa na hora da locação
    if (sendWhatsAppOnSubmit) {
      const encodedMsg = encodeURIComponent(buildWhatsAppMessage(code));
      window.open(`https://wa.me/${companyWhatsAppNumber}?text=${encodedMsg}`, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex justify-center items-start p-2 sm:p-4 md:p-6 animate-fadeIn">
      <div className="bg-[#FAF9F5] text-[#1c1917] rounded-3xl max-w-5xl w-full my-auto overflow-hidden shadow-2xl border border-[#ded7c4] flex flex-col max-h-[94vh]">
        
        {/* Top Sticky Bar */}
        <div className="sticky top-0 z-30 bg-[#FAF9F5]/95 backdrop-blur-md px-6 py-4 border-b border-[#e9e3d5] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-xs uppercase tracking-widest text-[#78716c] font-medium">
              {chalet.region} · {chalet.city}, {chalet.state}
            </span>
            <span className="hidden sm:inline text-xs text-[#a8a29e]">·</span>
            <span className="hidden sm:inline text-xs text-[#2d3a29] font-medium flex items-center gap-1">
              <Star className="w-3 h-3 fill-[#2d3a29]" />
              {chalet.rating.toFixed(2)} ({chalet.reviewCount} avaliações)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleFavorite(chalet.id)}
              className="p-2 rounded-full hover:bg-[#ede6d8] text-[#44403c] transition-colors"
              title="Salvar refúgio"
            >
              <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#222c1f] text-[#222c1f]' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-[#ede6d8] text-[#44403c] transition-colors"
              title="Fechar janela"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-6 md:p-8 flex-1 space-y-8">
          
          {step === 'details' && (
            <>
              {/* Luxury Image Gallery: Foto Principal + Fotos Secundárias */}
              <div className="space-y-4">
                
                {/* 1. FOTO PRINCIPAL (Em Grande Destaque) */}
                <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-[#222c1f] shadow-lg group/main">
                  <img
                    src={chalet.images[activeImageIndex] || chalet.coverImage}
                    alt={`${chalet.name} - ${activeImageIndex === 0 ? 'Foto Principal' : `Foto ${activeImageIndex + 1}`}`}
                    className="w-full h-full object-cover transition-all duration-500 ease-out"
                    referrerPolicy="no-referrer"
                  />

                  {/* Gradient overlays for readability */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30 pointer-events-none" />

                  {/* Top Bar on Principal: Badge "Foto Principal" / Counter */}
                  <div className="absolute top-4 left-4 flex items-center gap-2 z-10">
                    <div className="bg-[#222c1f]/90 text-white backdrop-blur-md px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-md border border-white/20">
                      <Star className={`w-3.5 h-3.5 ${activeImageIndex === 0 ? 'fill-amber-300 text-amber-300' : 'text-stone-300'}`} />
                      <span>{activeImageIndex === 0 ? 'Foto Principal' : `Foto ${activeImageIndex + 1}`}</span>
                    </div>
                  </div>

                  {/* Expand Lightbox Button */}
                  <div className="absolute top-4 right-4 z-10">
                    <button
                      type="button"
                      onClick={() => setIsLightboxOpen(true)}
                      className="bg-black/50 hover:bg-black/80 text-white backdrop-blur-md p-2 rounded-full transition-all shadow-md border border-white/20 cursor-pointer"
                      title="Ver foto em tela cheia"
                    >
                      <Maximize2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Previous / Next Arrow Controls */}
                  {chalet.images.length > 1 && (
                    <>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveImageIndex((prev) => (prev === 0 ? chalet.images.length - 1 : prev - 1));
                        }}
                        className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/40 text-white hover:bg-black/80 backdrop-blur-md transition-all z-10 shadow-md cursor-pointer opacity-80 hover:opacity-100"
                        title="Foto anterior"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveImageIndex((prev) => (prev === chalet.images.length - 1 ? 0 : prev + 1));
                        }}
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/40 text-white hover:bg-black/80 backdrop-blur-md transition-all z-10 shadow-md cursor-pointer opacity-80 hover:opacity-100"
                        title="Próxima foto"
                      >
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </>
                  )}

                  {/* Bottom Bar: Image Count & Chalet Name */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between z-10 text-white text-xs">
                    <span className="font-serif-luxury text-base sm:text-lg drop-shadow-md">
                      {chalet.name} · {chalet.city}
                    </span>
                    <div className="bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-mono border border-white/10">
                      Foto {activeImageIndex + 1} de {chalet.images.length}
                    </div>
                  </div>
                </div>

                {/* 2. FOTOS SECUNDÁRIAS (Grade e Mosaico de Miniaturas) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#78716c] px-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold uppercase tracking-wider text-[#44403c]">
                        Fotos Secundárias ({chalet.images.length - 1} ambientes)
                      </span>
                      <span className="text-[11px] text-[#a8a29e] hidden sm:inline">
                        · Clique em qualquer foto secundária para visualizar em tamanho principal
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsLightboxOpen(true)}
                      className="text-[#2d3a29] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <span>Ver todas ({chalet.images.length})</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
                    {chalet.images.map((img, idx) => {
                      const isCurrent = activeImageIndex === idx;
                      const isPrimary = idx === 0;

                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setActiveImageIndex(idx)}
                          className={`group/thumb relative aspect-[4/3] rounded-xl overflow-hidden border-2 transition-all cursor-pointer text-left ${
                            isCurrent
                              ? 'border-[#222c1f] ring-2 ring-[#222c1f]/40 scale-[0.98] shadow-md'
                              : 'border-[#ded7c4] hover:border-[#222c1f]/60 opacity-80 hover:opacity-100'
                          }`}
                        >
                          <img
                            src={img}
                            alt={`${chalet.name} foto ${idx + 1}`}
                            className="w-full h-full object-cover transition-transform duration-300 group-hover/thumb:scale-105"
                            referrerPolicy="no-referrer"
                          />

                          {/* Badge Principal vs Secundária */}
                          <div className="absolute top-1.5 left-1.5">
                            <span className={`text-[8px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded backdrop-blur-md shadow-xs ${
                              isPrimary
                                ? 'bg-[#222c1f] text-white'
                                : 'bg-black/60 text-white'
                            }`}>
                              {isPrimary ? 'Principal' : `Secundária ${idx}`}
                            </span>
                          </div>

                          {/* Active state indicator */}
                          {isCurrent && (
                            <div className="absolute inset-0 bg-[#222c1f]/20 flex items-end justify-end p-1.5 pointer-events-none">
                              <span className="bg-emerald-700 text-white text-[8px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5 shadow-sm">
                                <Check className="w-2.5 h-2.5" />
                                <span>No visor</span>
                              </span>
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

              </div>

              {/* Title & Core Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-4">
                
                {/* Left Column (Content & Story) */}
                <div className="lg:col-span-7 space-y-8">
                  <div>
                    <h2 className="font-serif-luxury text-3xl sm:text-4xl font-semibold text-[#1c1917] leading-tight mb-2">
                      {chalet.name}
                    </h2>
                    <p className="text-base text-[#57534e] font-light leading-relaxed mb-6">
                      {chalet.tagline}
                    </p>

                    {/* Metric Row */}
                    <div className="flex flex-wrap items-center gap-6 py-4 border-y border-[#e9e3d5] text-sm text-[#44403c]">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-[#2d3a29]" />
                        <span>Até {chalet.maxGuests} hóspedes</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Bed className="w-4 h-4 text-[#2d3a29]" />
                        <span>{chalet.bedrooms} {chalet.bedrooms === 1 ? 'Suíte' : 'Suítes'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Bath className="w-4 h-4 text-[#2d3a29]" />
                        <span>{chalet.bathrooms} Banheiro privativo</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Compass className="w-4 h-4 text-[#2d3a29]" />
                        <span className="tabular-nums">{chalet.altitudeMeters}m altitude</span>
                      </div>
                    </div>
                  </div>

                  {/* Architectural Note */}
                  <div className="p-5 rounded-2xl bg-[#f2ecde] border border-[#e4dcce]">
                    <div className="text-xs uppercase tracking-wider font-semibold text-[#78716c] mb-1.5 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#2d3a29]" />
                      Conceito Arquitetônico & Integração Natural
                    </div>
                    <p className="text-sm text-[#292524] italic leading-relaxed">
                      "{chalet.architecturalNote}"
                    </p>
                  </div>

                  {/* Description */}
                  <div>
                    <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917] mb-3">
                      A Alma deste Refúgio
                    </h3>
                    <p className="text-sm sm:text-base text-[#44403c] leading-relaxed font-light">
                      {chalet.description}
                    </p>
                  </div>

                  {/* Amenities */}
                  <div>
                    <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917] mb-4">
                      O Que Este Chalé Oferece
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-[#44403c]">
                      {chalet.amenities.map((item, i) => (
                        <div key={i} className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#2d3a29] shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Availability Calendar Grid */}
                  <div>
                    <AvailabilityCalendar
                      chaletId={chalet.id}
                      reservations={reservations}
                      checkIn={checkIn}
                      checkOut={checkOut}
                      onSelectDates={(inD, outD) => {
                        setCheckIn(inD);
                        setCheckOut(outD);
                      }}
                    />
                  </div>

                  {/* Host Card */}
                  <div className="p-5 rounded-2xl bg-white border border-[#e9e3d5] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img
                        src={chalet.host.avatar}
                        alt={chalet.host.name}
                        className="w-14 h-14 rounded-full object-cover border border-[#c7baa4]"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-[#1c1917]">{chalet.host.name}</span>
                          {chalet.host.isSuperhost && (
                            <span className="text-[11px] font-medium tracking-wide uppercase px-2 py-0.5 bg-[#2d3a29] text-white rounded">
                              Superhost
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-[#78716c] mt-0.5">{chalet.host.role}</div>
                        <div className="text-xs text-[#57534e] mt-1 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-[#2d3a29]" />
                          <span>{chalet.host.responseTime}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsChatOpen(!isChatOpen)}
                      className="px-4 py-2 rounded-xl bg-[#222c1f] hover:bg-[#2d3a29] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs shrink-0"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{isChatOpen ? 'Fechar Chat' : 'Chat Pré-Reserva'}</span>
                    </button>
                  </div>

                  {/* Pre-booking Direct Chat Component */}
                  {isChatOpen && (
                    <div className="animate-fadeIn">
                      <ChaletHostChat
                        chaletName={chalet.name}
                        hostName={chalet.host.name}
                        hostAvatar={chalet.host.avatar}
                        hostRole={chalet.host.role}
                        chaletCity={chalet.city}
                        onClose={() => setIsChatOpen(false)}
                      />
                    </div>
                  )}

                  {/* Curated Experiences Addons */}
                  {chalet.experiences.length > 0 && (
                    <div>
                      <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917] mb-2">
                        Experiências & Rituais Sob Medida
                      </h3>
                      <p className="text-xs text-[#78716c] mb-4">
                        Adicione mimos privativos preparados pelos anfitriões para sua chegada:
                      </p>
                      <div className="space-y-3">
                        {chalet.experiences.map((exp) => {
                          const isSelected = selectedExperienceIds.includes(exp.id);
                          return (
                            <div
                              key={exp.id}
                              onClick={() => handleToggleExperience(exp.id)}
                              className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                                isSelected
                                  ? 'bg-[#f4efe4] border-[#222c1f] shadow-sm'
                                  : 'bg-white border-[#e9e3d5] hover:border-[#cfc6b4]'
                              }`}
                            >
                              <div className="flex items-start gap-3">
                                <div className={`w-5 h-5 rounded flex items-center justify-center mt-0.5 border ${isSelected ? 'bg-[#222c1f] border-[#222c1f] text-white' : 'border-[#a8a29e]'}`}>
                                  {isSelected && <Check className="w-3.5 h-3.5" />}
                                </div>
                                <div>
                                  <div className="text-sm font-semibold text-[#1c1917]">{exp.title}</div>
                                  <div className="text-xs text-[#57534e] mt-0.5">{exp.description}</div>
                                  <div className="text-[11px] text-[#78716c] mt-1 font-mono">{exp.duration}</div>
                                </div>
                              </div>
                              <div className="text-sm font-semibold font-mono text-[#1c1917] tabular-nums whitespace-nowrap ml-4">
                                + R$ {exp.price}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Seção: O Que Levar & Dicas da Região (Personalizadas por Chalé) */}
                  <div className="bg-[#FAF9F5] border border-[#ded7c4] rounded-3xl p-6 sm:p-7 space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e9e3d5] pb-4">
                      <div>
                        <div className="flex items-center gap-2 text-[#2d3a29] text-xs font-bold uppercase tracking-wider mb-1">
                          <Compass className="w-4 h-4 text-emerald-700" />
                          <span>Guia do Viajante & Preparação</span>
                        </div>
                        <h3 className="font-serif-luxury text-2xl font-bold text-[#1c1917]">
                          O Que Levar & Dicas da Região
                        </h3>
                        <p className="text-xs text-[#78716c] mt-0.5">
                          Orientações exclusivas preparadas pelos anfitriões para sua melhor estadia em {chalet.city}.
                        </p>
                      </div>

                      {/* Tab buttons */}
                      <div className="flex items-center gap-1.5 p-1 bg-white border border-[#ded7c4] rounded-xl self-start sm:self-auto text-xs font-medium">
                        <button
                          type="button"
                          onClick={() => setActiveGuideTab('whatToBring')}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                            activeGuideTab === 'whatToBring'
                              ? 'bg-[#222c1f] text-white shadow-xs font-semibold'
                              : 'text-[#57534e] hover:text-[#1c1917]'
                          }`}
                        >
                          <Briefcase className="w-3.5 h-3.5" />
                          <span>O Que Levar ({whatToBringList.length})</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setActiveGuideTab('regionalTips')}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                            activeGuideTab === 'regionalTips'
                              ? 'bg-[#222c1f] text-white shadow-xs font-semibold'
                              : 'text-[#57534e] hover:text-[#1c1917]'
                          }`}
                        >
                          <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                          <span>Dicas Locais ({regionalTipsList.length})</span>
                        </button>
                      </div>
                    </div>

                    {/* View: O Que Levar na Mala */}
                    {activeGuideTab === 'whatToBring' && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between text-xs text-[#78716c]">
                          <span>Checklist interativa: clique nos itens para riscar o que já colocou na mala:</span>
                          <span className="font-mono text-[11px] bg-white px-2 py-0.5 rounded border border-[#ded7c4] text-[#2d3a29] font-bold">
                            {Object.values(checkedItems).filter(Boolean).length} de {whatToBringList.length} prontos
                          </span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {whatToBringList.map((item, idx) => {
                            const isChecked = !!checkedItems[item];
                            return (
                              <div
                                key={idx}
                                onClick={() => handleToggleCheckItem(item)}
                                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 select-none ${
                                  isChecked
                                    ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950 shadow-xs'
                                    : 'bg-white border-[#e9e3d5] hover:border-[#cfc6b4] text-[#44403c]'
                                }`}
                              >
                                <div
                                  className={`w-5 h-5 rounded-lg border mt-0.5 shrink-0 flex items-center justify-center transition-colors ${
                                    isChecked
                                      ? 'bg-emerald-700 border-emerald-700 text-white'
                                      : 'border-[#a8a29e] bg-[#FAF9F5]'
                                  }`}
                                >
                                  {isChecked && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                                </div>
                                <span className={`text-xs leading-relaxed ${isChecked ? 'line-through opacity-70' : 'font-medium'}`}>
                                  {item}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* View: Dicas da Região */}
                    {activeGuideTab === 'regionalTips' && (
                      <div className="space-y-3">
                        <p className="text-xs text-[#78716c]">
                          Segredos gastronômicos, dicas de estrada e melhores horários de mirantes em {chalet.city} ({chalet.state}):
                        </p>
                        <div className="space-y-2.5">
                          {regionalTipsList.map((tip, idx) => (
                            <div
                              key={idx}
                              className="p-3.5 rounded-2xl bg-white border border-[#e9e3d5] flex items-start gap-3 shadow-xs"
                            >
                              <div className="w-7 h-7 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold font-mono">
                                0{idx + 1}
                              </div>
                              <p className="text-xs sm:text-sm text-[#44403c] leading-relaxed">
                                {tip}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Guest Reviews */}
                  <div>
                    <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917] mb-4">
                      Relatos de Quem Já Esteve Aqui
                    </h3>
                    <div className="space-y-4">
                      {(chalet.reviews || [])
                        .filter((rev) => rev.status === 'aprovada' || (rev.isApproved !== false && rev.status !== 'rejeitada'))
                        .map((rev) => (
                        <div key={rev.id} className="p-4 rounded-xl bg-white border border-[#e9e3d5] space-y-2">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="font-semibold text-sm text-[#1c1917]">{rev.author}</span>
                              <span className="text-xs text-[#78716c] ml-2">({rev.location})</span>
                            </div>
                            <div className="flex items-center text-[#2d3a29]">
                              {[...Array(rev.rating)].map((_, i) => (
                                <Star key={i} className="w-3.5 h-3.5 fill-[#2d3a29]" />
                              ))}
                            </div>
                          </div>
                          <p className="text-xs sm:text-sm text-[#44403c] italic leading-relaxed">
                            "{rev.comment}"
                          </p>
                          <div className="text-[11px] text-[#a8a29e]">{rev.stayType} · {rev.date}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* Right Column (Contiguous Purchase Module) */}
                <div className="lg:col-span-5">
                  <div className="sticky top-20 bg-white border border-[#ded7c4] rounded-2xl p-6 shadow-xl space-y-6">
                    
                    {/* Price Header */}
                    <div className="flex items-baseline justify-between border-b border-[#e9e3d5] pb-4">
                      <div>
                        <span className="font-serif-luxury text-3xl font-semibold text-[#1c1917] tabular-nums font-mono">
                          R$ {chalet.pricePerNight.toLocaleString('pt-BR')}
                        </span>
                        <span className="text-xs text-[#78716c] ml-1">/ noite</span>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center text-xs font-semibold text-[#2d3a29]">
                          <Star className="w-3.5 h-3.5 fill-[#2d3a29] mr-1" />
                          <span>{chalet.rating.toFixed(2)}</span>
                        </div>
                        <div className="text-[11px] text-[#a8a29e]">{chalet.reviewCount} estadias</div>
                      </div>
                    </div>

                    {/* Date and Guests selector */}
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2 border border-[#d6cdbd] rounded-xl overflow-hidden p-2.5 bg-[#FAF9F5]">
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-[#78716c]">
                            Check-in
                          </label>
                          <input
                            type="date"
                            value={checkIn}
                            min={new Date().toISOString().split('T')[0]}
                            onChange={(e) => setCheckIn(e.target.value)}
                            className="w-full text-xs font-medium text-[#1c1917] bg-transparent focus:outline-none cursor-pointer"
                          />
                        </div>
                        <div className="border-l border-[#d6cdbd] pl-2.5">
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-[#78716c]">
                            Check-out
                          </label>
                          <input
                            type="date"
                            value={checkOut}
                            min={checkIn}
                            onChange={(e) => setCheckOut(e.target.value)}
                            className="w-full text-xs font-medium text-[#1c1917] bg-transparent focus:outline-none cursor-pointer"
                          />
                        </div>
                      </div>

                      <div className="border border-[#d6cdbd] rounded-xl p-2.5 bg-[#FAF9F5]">
                        <label className="block text-[10px] font-bold uppercase tracking-wider text-[#78716c] mb-1">
                          Hóspedes (máximo {chalet.maxGuests})
                        </label>
                        <select
                          value={guestCount}
                          onChange={(e) => setGuestCount(Number(e.target.value))}
                          className="w-full text-xs font-medium text-[#1c1917] bg-transparent focus:outline-none cursor-pointer"
                        >
                          {[...Array(chalet.maxGuests)].map((_, i) => (
                            <option key={i + 1} value={i + 1}>
                              {i + 1} {i === 0 ? 'hóspede' : 'hóspedes'}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Itemized Calculation */}
                    <div className="space-y-2 text-xs text-[#57534e] pt-2">
                      <div className="flex justify-between">
                        <span>R$ {chalet.pricePerNight} × {nights} {nights === 1 ? 'noite' : 'noites'}</span>
                        <span className="font-mono tabular-nums font-medium text-[#1c1917]">
                          R$ {basePrice.toLocaleString('pt-BR')}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Taxa de higienização e lenha inclusa</span>
                        <span className="font-mono tabular-nums font-medium text-[#1c1917]">
                          R$ {cleaningFee.toLocaleString('pt-BR')}
                        </span>
                      </div>
                      {experiencesTotal > 0 && (
                        <div className="flex justify-between text-[#2d3a29]">
                          <span>Experiências extras ({selectedExperienceIds.length})</span>
                          <span className="font-mono tabular-nums font-medium">
                            + R$ {experiencesTotal.toLocaleString('pt-BR')}
                          </span>
                        </div>
                      )}
                      
                      <div className="pt-3 border-t border-[#e9e3d5] flex justify-between items-baseline text-sm">
                        <span className="font-semibold text-[#1c1917]">Total estimado</span>
                        <div className="text-right">
                          <div className="font-bold text-xl text-[#1c1917] font-mono tabular-nums">
                            R$ {rawTotal.toLocaleString('pt-BR')}
                          </div>
                          <div className="text-[10px] text-[#2d3a29] font-medium">
                            ou R$ {Math.round(rawTotal * 0.95).toLocaleString('pt-BR')} via PIX (-5%)
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Overlapping Booking Warning */}
                    {(() => {
                      const overlap = activeChaletBookings.find((range) => {
                        // O bloqueio é feito do dia de entrada ao dia de saída da reserva do ocupante (inclusive)
                        return !(checkOut < range.checkIn || checkIn > range.checkOut);
                      });

                      if (!overlap) return null;

                      const isConfirmed = overlap.status === 'confirmada';
                      const minsLeft = Math.max(1, Math.ceil(((overlap.expiresAt || (now + 3600000)) - now) / 60000));

                      return (
                        <div className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                          isConfirmed 
                            ? 'bg-red-50 border-red-200 text-red-900' 
                            : 'bg-amber-50 border-amber-300 text-amber-900'
                        }`}>
                          <AlertCircle className={`w-4 h-4 shrink-0 mt-0.5 ${isConfirmed ? 'text-red-600' : 'text-amber-600'}`} />
                          <div>
                            <strong>
                              {isConfirmed ? 'Período Reservado!' : 'Período Bloqueado Temporariamente!'}
                            </strong>
                            <p className="mt-1 text-[11px] leading-relaxed">
                              {isConfirmed
                                ? `Este chalé já possui reserva confirmada de ${overlap.checkIn.split('-').reverse().slice(0, 2).join('/')} a ${overlap.checkOut.split('-').reverse().slice(0, 2).join('/')} (bloqueado na entrada e na saída). Por favor, escolha datas livres na grade.`
                                : `Existe uma pré-reserva aguardando pagamento para estas datas. O período fica bloqueado por até 60 minutos (${minsLeft} min restantes). Se o pagamento não for concluído no prazo, a data é liberada automaticamente.`}
                            </p>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Booking Action */}
                    {(() => {
                      const hasOverlap = activeChaletBookings.some((range) => {
                        // Bloqueio abrangente do dia de entrada ao dia de saída (inclusive)
                        return !(checkOut < range.checkIn || checkIn > range.checkOut);
                      });
                      const isDisabled = !checkIn || !checkOut || checkOut <= checkIn || hasOverlap;

                      return (
                        <button
                          type="button"
                          disabled={isDisabled}
                          onClick={() => setStep('checkout')}
                          className={`w-full py-4 px-6 rounded-xl text-sm font-semibold tracking-wide flex items-center justify-center gap-2 transition-all shadow-md ${
                            isDisabled
                              ? 'bg-[#c7baa4] text-white cursor-not-allowed'
                              : 'bg-[#222c1f] hover:bg-[#2d3a29] text-white active:scale-95 cursor-pointer'
                          }`}
                        >
                          <span>
                            {!checkIn || !checkOut
                              ? 'Selecione as Datas Livres na Grade'
                              : hasOverlap
                              ? 'Datas Reservadas - Escolha Outro Período'
                              : 'Prosseguir para Reserva'}
                          </span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      );
                    })()}

                    <div className="text-[11px] text-[#78716c] text-center space-y-1">
                      <div>Garantia de cancelamento gratuito até 7 dias antes</div>
                      <div>Cesta de café colonial entregue todas as manhãs</div>
                    </div>

                  </div>
                </div>

              </div>
            </>
          )}

          {/* STEP 2: Checkout Form & Payment */}
          {step === 'checkout' && (
            <div className="max-w-2xl mx-auto space-y-6">
              <button
                type="button"
                onClick={() => setStep('details')}
                className="text-xs text-[#78716c] hover:text-[#1c1917] flex items-center gap-1"
              >
                ← Voltar para os detalhes do chalé
              </button>

              <div>
                <h2 className="font-serif-luxury text-3xl font-semibold text-[#1c1917] mb-1">
                  Finalizar Reserva do Refúgio
                </h2>
                <p className="text-xs text-[#78716c]">
                  {chalet.name} · {nights} noites ({checkIn} até {checkOut})
                </p>
              </div>

              <form onSubmit={handleFinalizeBooking} className="space-y-6">
                
                {/* Guest Details */}
                <div className="bg-white border border-[#e9e3d5] rounded-2xl p-6 space-y-4">
                  <h3 className="font-medium text-sm text-[#1c1917] flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#2d3a29]" />
                    Dados do Hóspede Principal
                  </h3>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-[#44403c] mb-1">
                        Nome Completo *
                      </label>
                      <input
                        type="text"
                        required
                        value={guestName}
                        onChange={(e) => setGuestName(e.target.value)}
                        placeholder="Ex: Beatriz Albuquerque Silva"
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-2 focus:ring-[#2d3a29]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-[#44403c] mb-1">
                          E-mail para Confirmação *
                        </label>
                        <input
                          type="email"
                          required
                          value={guestEmail}
                          onChange={(e) => setGuestEmail(e.target.value)}
                          placeholder="seu.email@exemplo.com"
                          className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-2 focus:ring-[#2d3a29]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#44403c] mb-1">
                          WhatsApp / Telefone *
                        </label>
                        <input
                          type="tel"
                          required
                          value={guestPhone}
                          onChange={(e) => setGuestPhone(e.target.value)}
                          placeholder="(11) 98765-4321"
                          className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-2 focus:ring-[#2d3a29]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#44403c] mb-1">
                        Observações Especiais ou Comemorações (Opcional)
                      </label>
                      <textarea
                        rows={2}
                        value={specialRequests}
                        onChange={(e) => setSpecialRequests(e.target.value)}
                        placeholder="Ex: É aniversário de casamento; preferência por pães sem glúten na cesta; levaremos um cão de pequeno porte..."
                        className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-2 focus:ring-[#2d3a29]"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Selection */}
                <div className="bg-white border border-[#e9e3d5] rounded-2xl p-6 space-y-4">
                  <h3 className="font-medium text-sm text-[#1c1917]">
                    Forma de Pagamento
                  </h3>

                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('pix')}
                      className={`p-4 rounded-xl border text-left transition-all ${
                        paymentMethod === 'pix'
                          ? 'border-[#222c1f] bg-[#f4efe4] ring-1 ring-[#222c1f]'
                          : 'border-[#e9e3d5] hover:border-[#cfc6b4]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-sm text-[#1c1917]">PIX Instantâneo</span>
                        <span className="text-[10px] bg-[#222c1f] text-white px-2 py-0.5 rounded font-semibold uppercase">
                          -5% OFF
                        </span>
                      </div>
                      <p className="text-xs text-[#78716c]">Aprovação imediata e reserva garantida</p>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cartao')}
                      className={`p-4 rounded-xl border text-left transition-all ${
                        paymentMethod === 'cartao'
                          ? 'border-[#222c1f] bg-[#f4efe4] ring-1 ring-[#222c1f]'
                          : 'border-[#e9e3d5] hover:border-[#cfc6b4]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-sm text-[#1c1917]">Cartão de Crédito</span>
                        <CreditCard className="w-4 h-4 text-[#78716c]" />
                      </div>
                      <p className="text-xs text-[#78716c]">Em até 6x sem juros no cartão</p>
                    </button>
                  </div>

                  {/* Summary & Price */}
                  <div className="p-4 rounded-xl bg-[#FAF9F5] border border-[#e9e3d5] flex items-center justify-between">
                    <div>
                      <span className="text-xs text-[#78716c]">Valor total a pagar:</span>
                      <div className="text-xl font-bold font-mono text-[#1c1917] tabular-nums">
                        R$ {finalTotal.toLocaleString('pt-BR')}
                      </div>
                    </div>
                    <span className="text-xs text-[#2d3a29] font-medium">
                      {paymentMethod === 'pix' ? 'Desconto de 5% aplicado no Pix' : 'Parcelável em até 6x de R$ ' + Math.round(finalTotal / 6).toLocaleString('pt-BR')}
                    </span>
                  </div>
                </div>

                {/* Opção de Enviar WhatsApp para a Empresa na Hora da Locação */}
                <div className="bg-[#f0fdf4] border border-emerald-300 rounded-2xl p-4 flex items-start gap-3 shadow-xs">
                  <input
                    type="checkbox"
                    id="sendWhatsAppOnSubmit"
                    checked={sendWhatsAppOnSubmit}
                    onChange={(e) => setSendWhatsAppOnSubmit(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-emerald-600 rounded border-emerald-300 focus:ring-emerald-500 cursor-pointer"
                  />
                  <label htmlFor="sendWhatsAppOnSubmit" className="text-xs text-[#222c1f] cursor-pointer">
                    <div className="flex items-center gap-1.5 font-bold text-emerald-950 mb-0.5">
                      <MessageCircle className="w-4 h-4 text-emerald-600" />
                      <span>Enviar dados da locação para o WhatsApp da Empresa na hora da reserva</span>
                    </div>
                    <p className="text-[#57534e] text-[11px] leading-relaxed">
                      Ao clicar em confirmar, você será redirecionado para o WhatsApp com todos os detalhes (código da reserva, datas, chalé, valores e contatos) prontos para enviar ao atendimento da empresa ({companyPhone}).
                    </p>
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 px-6 rounded-xl bg-[#222c1f] hover:bg-[#2d3a29] text-white text-sm font-semibold tracking-wide flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95"
                >
                  <Check className="w-4 h-4" />
                  <span>Confirmar e Concluir Reserva</span>
                </button>
              </form>
            </div>
          )}

          {/* STEP 3: Reservation Confirmed Voucher */}
          {step === 'success' && (
            <div className="max-w-xl mx-auto py-8 text-center space-y-6 animate-fadeIn">
              <div className="w-16 h-16 bg-[#222c1f] text-white rounded-full flex items-center justify-center mx-auto shadow-md">
                <Check className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs uppercase tracking-widest text-[#78716c] font-semibold">
                  {currentReservationStatus === 'pendente' ? 'Pré-Reserva Realizada · Aguardando Pagamento' : 'Reserva Garantida com Sucesso'}
                </span>
                <h2 className="font-serif-luxury text-3xl font-bold text-[#1c1917] mt-1">
                  {currentReservationStatus === 'pendente' ? 'Seu refúgio está reservado por 1 hora!' : 'Seu refúgio na serra está confirmado!'}
                </h2>
                <p className="text-xs sm:text-sm text-[#57534e] mt-2">
                  Enviamos o voucher completo com as instruções de trajeto e contato do anfitrião para <strong>{guestEmail}</strong>.
                </p>
              </div>

              {/* 1-Hour Countdown Banner for Pending PIX */}
              {currentReservationStatus === 'pendente' && (
                <div className="bg-amber-50 border border-amber-300 rounded-2xl p-5 text-left space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-600 animate-ping" />
                      <span className="font-bold text-xs uppercase tracking-wider text-amber-900">
                        Tempo Restante para Pagamento:
                      </span>
                    </div>
                    <span className="font-mono text-lg font-bold text-amber-900 tabular-nums bg-amber-200/70 px-3 py-0.5 rounded-lg">
                      {formatCountdown(remainingSeconds)}
                    </span>
                  </div>

                  <p className="text-xs text-amber-800 leading-relaxed">
                    O chalé foi bloqueado na grade exclusivamente para você. Realize a transferência PIX dentro deste prazo de 60 minutos. Se o pagamento não for identificado, o chalé será <strong>liberado automaticamente</strong> para outros hóspedes.
                  </p>

                  {/* PIX Copy & Paste Key */}
                  <div className="p-3 bg-white rounded-xl border border-amber-200 space-y-1.5">
                    <span className="text-[10px] uppercase font-bold text-[#78716c] block">
                      Chave PIX Copia e Cola (Valor: R$ {finalTotal.toLocaleString('pt-BR')})
                    </span>
                    <div className="flex items-center justify-between gap-2">
                      <code className="text-[11px] font-mono text-[#1c1917] truncate bg-[#FAF9F5] p-1.5 rounded flex-1">
                        00020126580014br.gov.bcb.pix0136123e4567-e89b-12d3-a456-4266141740005204000053039865802BR5925MANTIQUEIRA
                      </code>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText('00020126580014br.gov.bcb.pix0136123e4567-e89b-12d3-a456-4266141740005204000053039865802BR5925MANTIQUEIRA');
                          setIsCopiedPix(true);
                          setTimeout(() => setIsCopiedPix(false), 2000);
                        }}
                        className="px-3 py-1.5 bg-[#222c1f] text-white text-xs font-semibold rounded-lg hover:bg-[#2d3a29] transition-colors shrink-0"
                      >
                        {isCopiedPix ? 'Copiado!' : 'Copiar Chave'}
                      </button>
                    </div>
                  </div>

                  {/* Mark as paid button */}
                  <button
                    onClick={() => {
                      setCurrentReservationStatus('confirmada');
                      onConfirmReservation({
                        id: confirmedReservationCode,
                        chaletId: chalet.id,
                        chaletName: chalet.name,
                        chaletCity: chalet.city,
                        chaletState: chalet.state,
                        chaletImage: chalet.coverImage,
                        checkIn,
                        checkOut,
                        nights,
                        guests: guestCount,
                        selectedExperiences: selectedExperienceIds,
                        totalPrice: finalTotal,
                        guestName,
                        guestEmail,
                        guestPhone,
                        specialRequests,
                        paymentMethod,
                        status: 'confirmada',
                        createdAt: new Date().toLocaleDateString('pt-BR'),
                      });
                    }}
                    className="w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl transition-colors shadow-sm flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>Já realizei a transferência PIX (Confirmar Estadia)</span>
                  </button>
                </div>
              )}

              {/* Voucher Box */}
              <div className="bg-white border-2 border-dashed border-[#c7baa4] rounded-2xl p-6 text-left space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#e9e3d5]">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[#78716c]">Código da Reserva</span>
                    <div className="font-mono text-xl font-bold text-[#1c1917]">{confirmedReservationCode}</div>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(confirmedReservationCode);
                      setIsCopiedPix(true);
                      setTimeout(() => setIsCopiedPix(false), 2000);
                    }}
                    className="flex items-center gap-1 text-xs text-[#2d3a29] font-medium hover:underline"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{isCopiedPix ? 'Copiado!' : 'Copiar'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs text-[#44403c]">
                  <div>
                    <span className="text-[#a8a29e]">Chalé:</span>
                    <div className="font-semibold text-sm">{chalet.name}</div>
                  </div>
                  <div>
                    <span className="text-[#a8a29e]">Local:</span>
                    <div className="font-semibold text-sm">{chalet.city}, {chalet.state}</div>
                  </div>
                  <div>
                    <span className="text-[#a8a29e]">Check-in:</span>
                    <div className="font-semibold">{checkIn} (a partir das 15h)</div>
                  </div>
                  <div>
                    <span className="text-[#a8a29e]">Check-out:</span>
                    <div className="font-semibold">{checkOut} (até as 12h)</div>
                  </div>
                  <div>
                    <span className="text-[#a8a29e]">Hóspede:</span>
                    <div className="font-semibold">{guestName}</div>
                  </div>
                  <div>
                    <span className="text-[#a8a29e]">Total Pago:</span>
                    <div className="font-semibold font-mono text-[#2d3a29]">
                      R$ {finalTotal.toLocaleString('pt-BR')} ({paymentMethod.toUpperCase()})
                    </div>
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-[#78716c] border-t border-[#e9e3d5] flex items-center gap-2">
                  <Coffee className="w-4 h-4 text-[#2d3a29] shrink-0" />
                  <span>A cesta de café colonial artesanal será deixada na varanda às 08h30.</span>
                </div>
              </div>

              {/* Card de Envio para WhatsApp da Empresa */}
              <div className="bg-[#e8f5e9] border border-emerald-300 rounded-2xl p-5 text-left space-y-3 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
                    <MessageCircle className="w-4 h-4 text-emerald-600" />
                    <span>Enviar Locação para o WhatsApp da Empresa</span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full font-semibold w-fit">
                    WhatsApp Oficial: {companyPhone}
                  </span>
                </div>
                <p className="text-xs text-emerald-800 leading-relaxed">
                  Deseja falar com nossa equipe ou enviar o comprovante agora? Clique no botão abaixo para abrir a conversa no WhatsApp da <strong>{companySettings?.name || 'Mantiqueira & Co.'}</strong> com todos os dados da sua locação já formatados.
                </p>
                <a
                  href={`https://wa.me/${companyWhatsAppNumber}?text=${encodeURIComponent(buildWhatsAppMessage(confirmedReservationCode))}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3.5 px-4 bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Enviar Dados da Locação no WhatsApp da Empresa</span>
                </a>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-3 rounded-xl bg-[#222c1f] text-white text-xs font-semibold tracking-wide hover:bg-[#2e3b2a] transition-colors cursor-pointer"
                >
                  Concluir e Voltar ao Site
                </button>
                <a
                  href={`https://wa.me/${companyWhatsAppNumber}?text=${encodeURIComponent(buildWhatsAppMessage(confirmedReservationCode))}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-6 py-3 rounded-xl bg-emerald-800 text-white text-xs font-semibold tracking-wide hover:bg-emerald-900 transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-300" />
                  <span>Chamar Concierge no WhatsApp</span>
                </a>
              </div>

            </div>
          )}

        </div>

      </div>

      {/* Lightbox / Fullscreen Gallery Modal */}
      {isLightboxOpen && (
        <div className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-md flex flex-col justify-between p-4 sm:p-6 animate-fadeIn">
          {/* Top Bar */}
          <div className="flex items-center justify-between text-white pb-3 border-b border-white/10">
            <div>
              <div className="text-xs uppercase tracking-widest text-white/70">
                {activeImageIndex === 0 ? 'Foto Principal' : `Foto Secundária ${activeImageIndex}`}
              </div>
              <h4 className="font-serif-luxury text-xl sm:text-2xl text-white">{chalet.name}</h4>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs font-mono bg-white/10 px-3 py-1.5 rounded-full text-white">
                {activeImageIndex + 1} de {chalet.images.length}
              </span>
              <button
                type="button"
                onClick={() => setIsLightboxOpen(false)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                title="Fechar galeria"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Main Stage */}
          <div className="relative flex-1 flex items-center justify-center my-4 overflow-hidden">
            <img
              src={chalet.images[activeImageIndex] || chalet.coverImage}
              alt={`${chalet.name} - tela cheia`}
              className="max-h-[75vh] max-w-full object-contain rounded-xl shadow-2xl"
              referrerPolicy="no-referrer"
            />

            {/* Left / Right Nav */}
            {chalet.images.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={() => setActiveImageIndex((prev) => (prev === 0 ? chalet.images.length - 1 : prev - 1))}
                  className="absolute left-2 sm:left-6 p-3 rounded-full bg-black/50 hover:bg-black/80 text-white transition-all cursor-pointer shadow-lg"
                  title="Foto anterior"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  type="button"
                  onClick={() => setActiveImageIndex((prev) => (prev === chalet.images.length - 1 ? 0 : prev + 1))}
                  className="absolute right-2 sm:right-6 p-3 rounded-full bg-black/50 hover:bg-black/80 text-white transition-all cursor-pointer shadow-lg"
                  title="Próxima foto"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </>
            )}
          </div>

          {/* Bottom Thumbnails Strip */}
          <div className="flex items-center justify-center gap-2 overflow-x-auto py-2">
            {chalet.images.map((img, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setActiveImageIndex(idx)}
                className={`relative w-16 h-12 rounded-lg overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                  activeImageIndex === idx ? 'border-white scale-105 opacity-100 ring-2 ring-white/50' : 'border-transparent opacity-50 hover:opacity-100'
                }`}
              >
                <img src={img} alt="Miniatura" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <span className="absolute bottom-0 inset-x-0 bg-black/70 text-[7px] text-center text-white font-mono">
                  {idx === 0 ? 'Principal' : `Sec. ${idx}`}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
