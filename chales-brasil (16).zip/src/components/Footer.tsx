import React from 'react';
import { Compass, ShieldCheck, Heart, Mail, MapPin, Phone } from 'lucide-react';
import { CompanySettings } from '../types';

interface FooterProps {
  companySettings?: CompanySettings;
  onNavigateSection?: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ companySettings, onNavigateSection }) => {
  const companyName = companySettings?.name || 'Mantiqueira & Co.';
  const tagline = companySettings?.tagline || 'Chalés Exclusivos do Brasil';
  const fullAddress = companySettings 
    ? `${companySettings.address} · ${companySettings.city}, ${companySettings.state} · CEP ${companySettings.zipCode}`
    : 'Estrada Real das Araucárias, Km 12 · Gonçalves, MG';

  return (
    <footer id="sobre" className="bg-[#181d16] text-[#ded7c4] border-t border-[#2d3a29] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand Col */}
          <div className="md:col-span-4 space-y-4">
            <div>
              <span className="font-serif-luxury text-2xl sm:text-3xl font-light text-white tracking-tight">
                {companyName}
              </span>
              <p className="text-xs text-[#8b9b7a] font-medium mt-0.5">{tagline}</p>
            </div>
            
            <p className="text-xs sm:text-sm text-[#beb6a3] max-w-sm leading-relaxed font-light">
              Plataforma independente de curadoria e hospedagem em chalés exclusivos, cabanas A-frame e refúgios de montanha nas serras mais deslumbrantes do Brasil.
            </p>

            <div className="space-y-1.5 text-xs text-[#beb6a3] pt-1">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#8b9b7a] shrink-0 mt-0.5" />
                <span>{fullAddress}</span>
              </div>
              {companySettings?.phone && (
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-[#8b9b7a] shrink-0" />
                  <span>{companySettings.phone}</span>
                </div>
              )}
              {companySettings?.email && (
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-[#8b9b7a] shrink-0" />
                  <span>{companySettings.email}</span>
                </div>
              )}
            </div>

            <div className="pt-2 text-xs text-[#a89f8d] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#8b9b7a]" />
              <span>100% dos chalés avaliados e aprovados presencialmente.</span>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
              Navegação
            </h4>
            <ul className="space-y-2 text-xs text-[#beb6a3]">
              <li>
                <button
                  onClick={() => onNavigateSection?.('colecao')}
                  className="hover:text-white transition-colors"
                >
                  Coleção de Chalés
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection?.('destinos')}
                  className="hover:text-white transition-colors"
                >
                  Destinos de Altitude
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection?.('experiencias')}
                  className="hover:text-white transition-colors"
                >
                  Experiências & Rituais
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection?.('avaliacoes')}
                  className="hover:text-white transition-colors font-medium text-emerald-400"
                >
                  Avaliações dos Hóspedes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection?.('fale-conosco')}
                  className="hover:text-white transition-colors font-medium text-emerald-400"
                >
                  Fale Conosco
                </button>
              </li>
            </ul>
          </div>

          {/* Destinations Col */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
              Destinos de Altitude
            </h4>
            <ul className="space-y-2 text-xs text-[#beb6a3]">
              <li><span className="hover:text-white transition-colors cursor-pointer">Gonçalves · Serra da Mantiqueira, MG</span></li>
              <li><span className="hover:text-white transition-colors cursor-pointer">Urubici & São Joaquim · Serra Catarinense</span></li>
              <li><span className="hover:text-white transition-colors cursor-pointer">São Bento do Sapucaí · Pedra do Baú, SP</span></li>
              <li><span className="hover:text-white transition-colors cursor-pointer">Campos do Jordão · Alto da Mantiqueira, SP</span></li>
              <li><span className="hover:text-white transition-colors cursor-pointer">Gramado & Canela · Serra Gaúcha, RS</span></li>
              <li><span className="hover:text-white transition-colors cursor-pointer">Visconde de Mauá & Maringá, RJ/MG</span></li>
            </ul>
          </div>

          {/* Standards & Philosophy */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
              Compromisso com as Serras
            </h4>
            <p className="text-xs text-[#beb6a3] leading-relaxed font-light">
              Destinamos parte de cada reserva para projetos locais de conservação e replantio da <em>Araucaria angustifolia</em> (pinheiro-brasileiro) e apoio a pequenos produtores artesanais das serras.
            </p>
            <div className="pt-2">
              <div className="text-[11px] text-[#8b9b7a] font-medium flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 fill-[#8b9b7a]" />
                <span>Turismo regenerativo e sustentável</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#8a816e] gap-4">
          <div>
            © {new Date().getFullYear()} Mantiqueira & Co. Hospedagens Exclusivas Ltda. Todos os direitos reservados.
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <a
              href="/chales-brasil.zip"
              download="chales-brasil.zip"
              className="text-[#8b9b7a] hover:text-white transition-colors underline font-medium"
            >
              Baixar Projeto (.ZIP)
            </a>
            <span className="hover:text-white transition-colors cursor-pointer">Termos de Reserva</span>
            <span className="hover:text-white transition-colors cursor-pointer">Privacidade & Dados</span>
            <span className="hover:text-white transition-colors cursor-pointer">Seja um Anfitrião Credenciado</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
