import React, { useState } from 'react';
import { 
  Phone, MessageCircle, Mail, MapPin, Clock, Send, 
  CheckCircle, HelpCircle, ChevronDown, ChevronUp, Sparkles, ShieldCheck 
} from 'lucide-react';
import { CompanySettings } from '../types';

interface ContactSectionProps {
  companySettings?: CompanySettings;
  onAddToast?: (toast: { type: 'success' | 'info' | 'warning' | 'error'; title: string; message: string }) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ companySettings, onAddToast }) => {
  const phone = companySettings?.phone || '(11) 98765-4321';
  const cleanPhone = phone.replace(/\D/g, '');
  const email = companySettings?.email || 'concierge@mantiqueiraco.com.br';
  const address = companySettings 
    ? `${companySettings.address} · ${companySettings.city}, ${companySettings.state}`
    : 'Estrada Real das Araucárias, Km 12 · Gonçalves, MG';
  const openingHours = companySettings?.openingHours || 'Segunda a Domingo, das 08h às 22h';
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'Dúvidas sobre reservas',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: 'Dúvidas sobre reservas',
        message: '',
      });

      if (onAddToast) {
        onAddToast({
          type: 'success',
          title: 'Mensagem Enviada ao Concierge!',
          message: 'Recebemos seu contato. Nossa equipe responderá em até 1 hora útil.',
        });
      }
    }, 700);
  };

  const faqs = [
    {
      q: 'Como funciona o check-in nos chalés?',
      a: 'O check-in ocorre a partir das 15h e check-out até às 12h. O acesso é feito através de fechadura digital por senha individual gerada na confirmação da reserva, garantindo total privacidade sem burocracias de recepção.',
    },
    {
      q: 'O café da manhã colonial está incluso na diária?',
      a: 'Sim! Em todos os chalés da nossa curadoria, a cesta de café colonial artesanal com queijos premiados da Mantiqueira, pães rústicos, geleias do sítio e manteiga fresca é entregue pontualmente às 08h30 na varanda privativa.',
    },
    {
      q: 'A lenha para a lareira e a banheira é cobrada à parte?',
      a: 'Não. Cada chalé conta com um depósito privativo abastecido com lenha nobre de reflorestamento e gravetos para acendimento, sem custo extra. A banheira de imersão ou ofurô aquecido já está pronta para uso privativo.',
    },
    {
      q: 'Os chalés aceitam animais de estimação (Pet Friendly)?',
      a: 'A maioria dos nossos chalés aceita animais de pequeno e médio porte com muito carinho. No filtro de busca, você pode selecionar o filtro "Pet Friendly" para visualizar os refúgios com quintal gramado e mimos para seu pet.',
    },
  ];

  return (
    <section id="fale-conosco" className="py-24 bg-[#FAF9F5] border-t border-[#e8e2d4] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-[#2d3a29] text-xs font-bold tracking-widest uppercase mb-2">
            <Sparkles className="w-4 h-4" />
            <span>Atendimento Personalizado de Montanha</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1c1917] tracking-tight">
            Fale Conosco & Concierge
          </h2>
          <p className="text-sm text-[#78716c] mt-3 leading-relaxed">
            Dúvidas sobre estradas de acesso, pedidos de celebração romântica ou assessoria para escolher o refúgio perfeito? Nossa equipe está pronta para lhe atender.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Contact Channels & Cards */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#e5decb] shadow-xs space-y-6">
              <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
                Canais de Atendimento Direto
              </h3>

              <div className="space-y-4 text-xs">
                
                {/* WhatsApp */}
                <a
                  href={`https://wa.me/55${cleanPhone}?text=Olá!%20Gostaria%20de%20tirar%20dúvidas%20sobre%20os%20chalés.`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-[#f7f4ec] hover:bg-[#ede6d8] transition-colors border border-[#ded7c4] group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-[#1c1917] group-hover:text-emerald-800 transition-colors">
                      WhatsApp Concierge 24/7
                    </div>
                    <div className="text-[#57534e] mt-0.5">{phone}</div>
                    <div className="text-[11px] text-emerald-700 font-medium mt-1">
                      Tempo médio de resposta: ~5 minutos
                    </div>
                  </div>
                </a>

                {/* Email */}
                <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-[#FAF9F5] border border-[#e5decb]">
                  <div className="w-10 h-10 rounded-xl bg-[#222c1f] text-white flex items-center justify-center shrink-0 shadow-xs">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-[#1c1917]">E-mail Oficial</div>
                    <a
                      href={`mailto:${email}`}
                      className="text-[#57534e] hover:text-[#1c1917] hover:underline"
                    >
                      {email}
                    </a>
                    <div className="text-[11px] text-[#78716c] mt-0.5">
                      Para reservas corporativas e parcerias
                    </div>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-[#FAF9F5] border border-[#e5decb]">
                  <div className="w-10 h-10 rounded-xl bg-[#2d3a29] text-white flex items-center justify-center shrink-0 shadow-xs">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-[#1c1917]">Central Telefônica</div>
                    <div className="text-[#57534e] font-mono">{phone}</div>
                    <div className="text-[11px] text-[#78716c] mt-0.5">
                      {openingHours}
                    </div>
                  </div>
                </div>

                {/* Physical Location */}
                <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-[#FAF9F5] border border-[#e5decb]">
                  <div className="w-10 h-10 rounded-xl bg-[#78716c] text-white flex items-center justify-center shrink-0 shadow-xs">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-[#1c1917]">Endereço da Base</div>
                    <div className="text-[#57534e] leading-snug">
                      {address}
                    </div>
                  </div>
                </div>

              </div>

              <div className="pt-4 border-t border-[#f2ede4] flex items-center gap-2 text-xs text-emerald-800 font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Atendimento de excelência certificado pelos anfitriões</span>
              </div>
            </div>

            {/* Quick FAQ Mini Box */}
            <div className="bg-white p-6 rounded-3xl border border-[#e5decb] shadow-xs space-y-3">
              <h4 className="font-serif-luxury text-lg font-bold text-[#1c1917] flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-[#2d3a29]" />
                <span>Perguntas Frequentes</span>
              </h4>
              <div className="space-y-2">
                {faqs.map((faq, idx) => (
                  <div key={idx} className="border border-[#ede6d8] rounded-xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                      className="w-full px-3.5 py-2.5 text-left text-xs font-semibold text-[#1c1917] hover:bg-[#FAF9F5] flex items-center justify-between gap-2 transition-colors"
                    >
                      <span>{faq.q}</span>
                      {activeFaq === idx ? (
                        <ChevronUp className="w-3.5 h-3.5 text-[#78716c] shrink-0" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5 text-[#78716c] shrink-0" />
                      )}
                    </button>
                    {activeFaq === idx && (
                      <div className="px-3.5 pb-3 text-[11px] text-[#57534e] leading-relaxed bg-[#FAF9F5] border-t border-[#ede6d8]">
                        {faq.a}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-white p-8 sm:p-10 rounded-3xl border border-[#e5decb] shadow-sm">
              <h3 className="font-serif-luxury text-2xl font-bold text-[#1c1917] mb-2">
                Envie uma Mensagem Direta
              </h3>
              <p className="text-xs text-[#78716c] mb-6">
                Preencha os campos abaixo e nosso concierge retornará com todas as orientações.
              </p>

              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-[#44403c] mb-1.5">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Seu nome e sobrenome"
                    className="w-full px-4 py-3 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1.5">
                      E-mail para Retorno *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="seu.email@exemplo.com"
                      className="w-full px-4 py-3 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1.5">
                      Telefone / WhatsApp
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="(11) 99999-8888"
                      className="w-full px-4 py-3 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#44403c] mb-1.5">
                    Assunto do Contato
                  </label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none bg-[#FAF9F5] cursor-pointer"
                  >
                    <option value="Dúvidas sobre reservas">Dúvidas sobre Reservas & Datas</option>
                    <option value="Lua de Mel e Ocasiões Especiais">Lua de Mel ou Ocasião Especial (Flores, Vinho, Chef)</option>
                    <option value="Cadastrar meu Chalé">Sou Proprietário e Quero Cadastrar meu Chalé</option>
                    <option value="Acesso e Estradas">Condições da Estrada & Acesso aos Chalés</option>
                    <option value="Outros">Outras Dúvidas</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#44403c] mb-1.5">
                    Sua Mensagem *
                  </label>
                  <textarea
                    rows={5}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Descreva suas dúvidas, datas desejadas ou qualquer detalhe importante para sua estadia..."
                    className="w-full px-4 py-3 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 px-6 rounded-xl bg-[#222c1f] hover:bg-[#2d3a29] text-white font-semibold text-sm flex items-center justify-center gap-2 transition-all shadow-md"
                  >
                    {isSubmitting ? (
                      <span>Enviando mensagem...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Enviar Mensagem ao Concierge</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-[11px] text-[#78716c] text-center mt-3">
                  Seus dados estão protegidos pela Lei Geral de Proteção de Dados (LGPD).
                </p>
              </form>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
