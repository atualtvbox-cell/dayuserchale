import React, { useState, useMemo } from 'react';
import { 
  Star, Lock, Unlock, CheckCircle2, AlertCircle, Eye, EyeOff, 
  Trash2, Plus, Search, Filter, MessageSquare, ThumbsUp, Calendar,
  Building2, X, Check, ShieldCheck, Sparkles, User
} from 'lucide-react';
import { Review, Chalet } from '../types';

interface AdminReviewsManagerProps {
  reviews: Review[];
  chalets: Chalet[];
  onApproveReview: (reviewId: string) => void;
  onBlockReview: (reviewId: string) => void;
  onDeleteReview: (reviewId: string) => void;
  onAddReview: (review: Review) => void;
}

export const AdminReviewsManager: React.FC<AdminReviewsManagerProps> = ({
  reviews,
  chalets,
  onApproveReview,
  onBlockReview,
  onDeleteReview,
  onAddReview,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [filterRating, setFilterRating] = useState<number>(0);
  const [filterChalet, setFilterChalet] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modal for new review created by admin
  const [isNewReviewModalOpen, setIsNewReviewModalOpen] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newChaletName, setNewChaletName] = useState(chalets[0]?.name || 'Chalé Mirante das Araucárias');
  const [newStayType, setNewStayType] = useState('Estadia Romântica · 3 noites');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [newStatus, setNewStatus] = useState<'aprovada' | 'pendente'>('aprovada');

  // Counts
  const pendingCount = useMemo(() => {
    return reviews.filter((r) => r.status === 'pendente' || r.isApproved === false).length;
  }, [reviews]);

  const approvedCount = useMemo(() => {
    return reviews.filter((r) => r.status === 'aprovada' || (r.isApproved === true && r.status !== 'rejeitada')).length;
  }, [reviews]);

  const averageRating = useMemo(() => {
    if (reviews.length === 0) return 5.0;
    const sum = reviews.reduce((acc, r) => acc + (r.rating || 5), 0);
    return (sum / reviews.length).toFixed(1);
  }, [reviews]);

  // Filtered reviews list
  const filteredReviews = useMemo(() => {
    return reviews.filter((r) => {
      const isApproved = r.status === 'aprovada' || r.isApproved === true;
      const isPending = r.status === 'pendente' || r.isApproved === false;
      const isRejected = r.status === 'rejeitada';

      if (filterStatus === 'pending' && !isPending) return false;
      if (filterStatus === 'approved' && !isApproved) return false;
      if (filterStatus === 'rejected' && !isRejected) return false;

      if (filterRating > 0 && r.rating !== filterRating) return false;

      if (filterChalet !== 'all') {
        const chaletMatch = r.chaletName?.toLowerCase().includes(filterChalet.toLowerCase()) || 
                            r.chaletId === filterChalet;
        if (!chaletMatch) return false;
      }

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const authorMatch = r.author?.toLowerCase().includes(query);
        const commentMatch = r.comment?.toLowerCase().includes(query);
        const locationMatch = r.location?.toLowerCase().includes(query);
        const chaletNameMatch = r.chaletName?.toLowerCase().includes(query);
        if (!authorMatch && !commentMatch && !locationMatch && !chaletNameMatch) return false;
      }

      return true;
    });
  }, [reviews, filterStatus, filterRating, filterChalet, searchQuery]);

  const handleCreateReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) return;

    const matchedChalet = chalets.find((c) => c.name === newChaletName);

    const created: Review = {
      id: `rev-${Date.now()}`,
      author: newAuthor.trim(),
      location: newLocation.trim() || 'Hóspede Verificado',
      date: new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }),
      rating: newRating,
      chaletName: newChaletName,
      chaletId: matchedChalet?.id,
      stayType: newStayType,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=160&q=80',
      comment: newComment.trim(),
      status: newStatus,
      isApproved: newStatus === 'aprovada',
      createdAt: new Date().toISOString(),
    };

    onAddReview(created);
    setIsNewReviewModalOpen(false);
    setNewAuthor('');
    setNewLocation('');
    setNewComment('');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Moderation Warning */}
      <div className="bg-[#FAF9F5] border border-[#ded7c4] rounded-3xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-[#2d3a29] text-xs font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>Painel de Moderação & Controle de Qualidade</span>
          </div>
          <h2 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#1c1917]">
            Avaliações dos Hóspedes
          </h2>
          <p className="text-xs sm:text-sm text-[#78716c] mt-1 max-w-2xl leading-relaxed">
            As avaliações deixadas por clientes no site permanecem <strong>bloqueadas por padrão</strong> para moderação. Desbloqueie-as abaixo para que sejam exibidas publicamente para os visitantes.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsNewReviewModalOpen(true)}
          className="flex items-center gap-2 bg-[#222c1f] hover:bg-[#2d3a29] text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xs transition-all shrink-0 cursor-pointer self-start md:self-center"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Avaliação (Admin)</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total */}
        <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
            <span>Total de Avaliações</span>
            <MessageSquare className="w-4 h-4 text-[#78716c]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] mt-2 tabular-nums">
            {reviews.length}
          </div>
          <p className="text-[11px] text-[#78716c] mt-1">Registradas em todas as cabanas</p>
        </div>

        {/* Pendentes / Bloqueadas */}
        <div className={`border rounded-2xl p-5 shadow-xs transition-colors ${
          pendingCount > 0 ? 'bg-amber-50/70 border-amber-300' : 'bg-white border-[#e5decb]'
        }`}>
          <div className="flex items-center justify-between text-xs uppercase tracking-wider font-semibold text-amber-800">
            <span>Bloqueadas (Aguardando Desbloqueio)</span>
            <Lock className="w-4 h-4 text-amber-700" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-amber-900 mt-2 tabular-nums flex items-center gap-2">
            <span>{pendingCount}</span>
            {pendingCount > 0 && (
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 font-sans animate-pulse">
                Ação Necessária
              </span>
            )}
          </div>
          <p className="text-[11px] text-amber-800 mt-1">
            {pendingCount === 0 ? 'Nenhuma avaliação pendente' : 'Ocultas do site até serem desbloqueadas'}
          </p>
        </div>

        {/* Desbloqueadas / Visíveis */}
        <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-emerald-800 uppercase tracking-wider font-semibold">
            <span>Desbloqueadas no Site</span>
            <Unlock className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-900 mt-2 tabular-nums">
            {approvedCount}
          </div>
          <p className="text-[11px] text-emerald-700 mt-1">Visíveis publicamente para os clientes</p>
        </div>

        {/* Nota Média */}
        <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
            <span>Média das Avaliações</span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] mt-2 tabular-nums flex items-center gap-1.5">
            <span>{averageRating}</span>
            <span className="text-sm text-[#78716c] font-normal">/ 5.0</span>
          </div>
          <p className="text-[11px] text-[#78716c] mt-1">Índice de excelência dos hóspedes</p>
        </div>

      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-[#e5decb] rounded-2xl p-4 shadow-xs space-y-3">
        
        {/* Row 1: Status Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#f0ece1] pb-3">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer ${
                filterStatus === 'all'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#57534e]'
              }`}
            >
              Todas ({reviews.length})
            </button>

            <button
              type="button"
              onClick={() => setFilterStatus('pending')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterStatus === 'pending'
                  ? 'bg-amber-700 text-white shadow-xs'
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Bloqueadas / Pendentes ({pendingCount})</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterStatus('approved')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterStatus === 'approved'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200'
              }`}
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>Desbloqueadas / Visíveis ({approvedCount})</span>
            </button>
          </div>

          <div className="text-xs text-[#78716c]">
            Exibindo <strong>{filteredReviews.length}</strong> de {reviews.length} avaliações
          </div>
        </div>

        {/* Row 2: Chalet filter, Rating filter and Search */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
          <div className="flex flex-wrap items-center gap-3">
            
            {/* Filter by Chalet */}
            <div className="flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5 text-[#78716c]" />
              <span className="font-semibold text-[#44403c]">Chalé:</span>
              <select
                value={filterChalet}
                onChange={(e) => setFilterChalet(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-[#d6cdbd] bg-[#FAF9F5] text-xs font-medium text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
              >
                <option value="all">Todas as Propriedades</option>
                {chalets.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter by Rating */}
            <div className="flex items-center gap-2">
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span className="font-semibold text-[#44403c]">Classificação:</span>
              <select
                value={filterRating}
                onChange={(e) => setFilterRating(Number(e.target.value))}
                className="px-2.5 py-1.5 rounded-lg border border-[#d6cdbd] bg-[#FAF9F5] text-xs font-medium text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
              >
                <option value={0}>Todas as Estrelas</option>
                <option value={5}>5 Estrelas ★★★★★</option>
                <option value={4}>4 Estrelas ★★★★☆</option>
                <option value={3}>3 Estrelas ★★★☆☆</option>
              </select>
            </div>

          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#a8a29e]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar por hóspede ou texto..."
              className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-[#d6cdbd] text-xs focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 text-stone-400 hover:text-stone-600"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

        </div>

      </div>

      {/* Reviews Cards List */}
      <div className="space-y-4">
        {filteredReviews.length === 0 ? (
          <div className="bg-white border border-[#e5decb] rounded-3xl p-12 text-center space-y-3">
            <MessageSquare className="w-10 h-10 mx-auto text-[#c7baa4]" />
            <h4 className="font-serif-luxury text-lg font-bold text-[#1c1917]">
              Nenhuma avaliação encontrada
            </h4>
            <p className="text-xs text-[#78716c] max-w-sm mx-auto">
              Não há avaliações correspondentes aos filtros selecionados. Tente alterar o status ou o termo de busca.
            </p>
          </div>
        ) : (
          filteredReviews.map((review) => {
            const isApproved = review.status === 'aprovada' || review.isApproved === true;
            const isPending = review.status === 'pendente' || review.isApproved === false;
            
            return (
              <div
                key={review.id}
                className={`bg-white rounded-2xl border transition-all p-5 shadow-xs space-y-4 ${
                  isPending
                    ? 'border-amber-300 ring-2 ring-amber-100 bg-amber-50/20'
                    : 'border-[#e5decb] hover:border-[#cfc6b4]'
                }`}
              >
                {/* Header Row: Author info + Status badge + Action buttons */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-[#f0ece1]">
                  
                  {/* Left: Author + Chalet */}
                  <div className="flex items-center gap-3">
                    <img
                      src={review.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=160&q=80'}
                      alt={review.author}
                      className="w-11 h-11 rounded-full object-cover border border-[#e5decb] shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-semibold text-sm text-[#1c1917]">{review.author}</h4>
                        <span className="text-[11px] text-[#78716c]">· {review.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-[#57534e] mt-0.5">
                        <span className="font-medium text-[#2d3a29] bg-[#f4efe4] px-2 py-0.5 rounded text-[11px]">
                          {review.chaletName || 'Chalé Exclusivo'}
                        </span>
                        <span className="text-[#a8a29e]">·</span>
                        <span className="text-[11px] text-[#78716c]">{review.stayType}</span>
                        <span className="text-[#a8a29e]">·</span>
                        <span className="text-[11px] text-[#78716c]">{review.date}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Status badge & Moderation Actions */}
                  <div className="flex items-center gap-2.5 flex-wrap sm:flex-nowrap">
                    
                    {/* Status Badge */}
                    {isPending ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                        <Lock className="w-3.5 h-3.5 text-amber-700" />
                        <span>Bloqueada (Oculta do Site)</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                        <Unlock className="w-3.5 h-3.5 text-emerald-700" />
                        <span>Desbloqueada no Site</span>
                      </span>
                    )}

                    {/* Unlock / Block Button */}
                    {isPending ? (
                      <button
                        type="button"
                        onClick={() => onApproveReview(review.id)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs transition-all active:scale-95 cursor-pointer"
                        title="Desbloquear para exibir no site"
                      >
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Desbloquear (Publicar)</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onBlockReview(review.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 text-xs font-medium transition-all cursor-pointer"
                        title="Bloquear e ocultar do site"
                      >
                        <Lock className="w-3.5 h-3.5 text-amber-700" />
                        <span>Bloquear (Ocultar)</span>
                      </button>
                    )}

                    {/* Delete button */}
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Deseja realmente excluir a avaliação de "${review.author}"?`)) {
                          onDeleteReview(review.id);
                        }
                      }}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                      title="Excluir Avaliação"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                  </div>

                </div>

                {/* Rating Stars & Comment Body */}
                <div className="space-y-2">
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-3.5 h-3.5 ${
                          star <= review.rating
                            ? 'text-amber-500 fill-amber-500'
                            : 'text-stone-300'
                        }`}
                      />
                    ))}
                    <span className="text-xs font-bold text-[#1c1917] ml-1.5">
                      {review.rating}.0
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-[#44403c] leading-relaxed italic bg-[#FAF9F5] p-3.5 rounded-xl border border-[#ede6d8]">
                    "{review.comment}"
                  </p>
                </div>

                {/* Status Notice footer */}
                <div className="flex items-center justify-between text-[11px] pt-1 text-[#78716c]">
                  <span>ID: <code className="font-mono text-[10px] text-[#2d3a29]">{review.id}</code></span>
                  <span>
                    {isPending ? (
                      <span className="text-amber-800 font-medium">
                        ⚠️ Visível apenas para administradores. Clique em "Desbloquear" para publicar.
                      </span>
                    ) : (
                      <span className="text-emerald-700 font-medium flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        Visível para todos os visitantes do site na seção de avaliações.
                      </span>
                    )}
                  </span>
                </div>

              </div>
            );
          })
        )}
      </div>

      {/* Modal: New Review (Admin Created) */}
      {isNewReviewModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex justify-center items-center p-4 animate-fadeIn">
          <div className="bg-[#FAF9F5] text-[#1c1917] rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#ded7c4] p-6 space-y-5">
            
            <div className="flex items-center justify-between border-b border-[#e9e3d5] pb-3">
              <div>
                <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
                  Adicionar Nova Avaliação
                </h3>
                <p className="text-xs text-[#78716c]">
                  Cadastre avaliações recebidas por WhatsApp, Google ou livro de visitas.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsNewReviewModalOpen(false)}
                className="p-1 rounded-full text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateReview} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-semibold text-[#44403c] mb-1">
                  Nome do Hóspede *
                </label>
                <input
                  type="text"
                  required
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="Ex: Dra. Letícia & Carlos Eduardo"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#d6cdbd] bg-white focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#44403c] mb-1">
                    Cidade / Origem
                  </label>
                  <input
                    type="text"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    placeholder="Ex: São Paulo, SP"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#d6cdbd] bg-white focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#44403c] mb-1">
                    Tipo de Estadia
                  </label>
                  <input
                    type="text"
                    value={newStayType}
                    onChange={(e) => setNewStayType(e.target.value)}
                    placeholder="Ex: Lua de Mel · 3 noites"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#d6cdbd] bg-white focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#44403c] mb-1">
                    Chalé Referente *
                  </label>
                  <select
                    value={newChaletName}
                    onChange={(e) => setNewChaletName(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#d6cdbd] bg-white focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                  >
                    {chalets.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#44403c] mb-1">
                    Nota (Classificação)
                  </label>
                  <select
                    value={newRating}
                    onChange={(e) => setNewRating(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#d6cdbd] bg-white focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                  >
                    <option value={5}>5 Estrelas (Excelente)</option>
                    <option value={4}>4 Estrelas (Muito Bom)</option>
                    <option value={3}>3 Estrelas (Bom)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#44403c] mb-1">
                  Status de Publicação
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewStatus('aprovada')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer ${
                      newStatus === 'aprovada'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-1 ring-emerald-600'
                        : 'border-[#d6cdbd] bg-white text-[#78716c]'
                    }`}
                  >
                    <Unlock className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Desbloqueada (Publicar no Site)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setNewStatus('pendente')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer ${
                      newStatus === 'pendente'
                        ? 'border-amber-600 bg-amber-50 text-amber-900 ring-1 ring-amber-600'
                        : 'border-[#d6cdbd] bg-white text-[#78716c]'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-700" />
                    <span>Bloqueada (Manter Oculta)</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#44403c] mb-1">
                  Depoimento / Comentário *
                </label>
                <textarea
                  required
                  rows={4}
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Relato detalhado da experiência no chalé, instalações, café da manhã..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#d6cdbd] bg-white focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#e9e3d5]">
                <button
                  type="button"
                  onClick={() => setIsNewReviewModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-[#d6cdbd] text-xs font-semibold text-[#57534e] hover:bg-stone-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#222c1f] hover:bg-[#2d3a29] text-white text-xs font-semibold shadow-xs"
                >
                  Salvar Avaliação
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
