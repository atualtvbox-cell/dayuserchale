import React, { useState, useEffect } from 'react';
import { 
  X, ChevronLeft, ChevronRight, Camera, MapPin, 
  Sparkles, Calendar, Maximize2, Share2, Check, Star 
} from 'lucide-react';
import { Chalet } from '../types';

interface ChaletGalleryModalProps {
  chalet: Chalet | null;
  initialIndex?: number;
  isOpen: boolean;
  onClose: () => void;
  onBookChalet?: (chalet: Chalet) => void;
}

export const ChaletGalleryModal: React.FC<ChaletGalleryModalProps> = ({
  chalet,
  initialIndex = 0,
  isOpen,
  onClose,
  onBookChalet,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [copiedShare, setCopiedShare] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(initialIndex);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, initialIndex]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen || !chalet) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft') {
        setCurrentIndex((prev) => (prev === 0 ? chalet.images.length - 1 : prev - 1));
      } else if (e.key === 'ArrowRight') {
        setCurrentIndex((prev) => (prev === chalet.images.length - 1 ? 0 : prev + 1));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, chalet, onClose]);

  if (!isOpen || !chalet) return null;

  const totalImages = chalet.images.length;
  const currentImage = chalet.images[currentIndex] || chalet.coverImage;

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === totalImages - 1 ? 0 : prev + 1));
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? totalImages - 1 : prev - 1));
  };

  const handleShare = async () => {
    const shareUrl = `${window.location.origin}/#chale-${chalet.id}`;
    const shareData = {
      title: `Galeria: ${chalet.name}`,
      text: `Veja as fotos do refúgio ${chalet.name} em ${chalet.city}, ${chalet.state}.`,
      url: shareUrl,
    };

    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
        return;
      } catch (err) {}
    }

    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2500);
    } catch {}
  };

  return (
    <div 
      className="fixed inset-0 z-[80] bg-black/95 backdrop-blur-md flex flex-col justify-between animate-in fade-in duration-200"
      onClick={onClose}
    >
      {/* Top Header Bar */}
      <div 
        className="w-full flex items-center justify-between px-4 sm:px-8 py-4 border-b border-white/10 z-10 bg-black/40 backdrop-blur-sm"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Chalet Info */}
        <div className="flex items-center gap-4">
          <div className="hidden sm:flex w-10 h-10 rounded-xl bg-white/10 items-center justify-center text-amber-300">
            <Camera className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-white/70">
              <span className="font-semibold text-white">{chalet.name}</span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-amber-300" />
                {chalet.city}, {chalet.state}
              </span>
              <span className="hidden md:inline">·</span>
              <span className="hidden md:inline font-mono text-white/50">{chalet.altitudeMeters}m</span>
            </div>
            <div className="text-white text-sm sm:text-base font-serif-luxury font-light">
              Galeria de Fotos Exclusivas
            </div>
          </div>
        </div>

        {/* Top Right Actions */}
        <div className="flex items-center gap-3">
          {/* Photo Counter */}
          <div className="px-3.5 py-1.5 rounded-full bg-white/10 border border-white/15 text-white text-xs font-mono font-medium">
            <span className="text-amber-300 font-bold">{currentIndex + 1}</span>
            <span className="text-white/50"> / </span>
            <span>{totalImages}</span>
          </div>

          {/* Share */}
          <button
            type="button"
            onClick={handleShare}
            className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="Compartilhar fotos deste chalé"
          >
            {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
          </button>

          {/* Book Chalet Button (in gallery) */}
          {onBookChalet && (
            <button
              type="button"
              onClick={() => onBookChalet(chalet)}
              className="hidden sm:flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-[#FAF9F5] text-[#1c1917] text-xs font-semibold shadow-md transition-all cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5 text-[#2d3a29]" />
              <span>Ver Grade & Reservar</span>
            </button>
          )}

          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/10 hover:bg-red-500/80 text-white transition-colors cursor-pointer"
            title="Fechar galeria (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Photo Viewport */}
      <div 
        className="relative flex-1 flex items-center justify-center p-4 sm:p-8 overflow-hidden select-none"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Current Image */}
        <div className="relative max-h-full max-w-full flex items-center justify-center">
          <img
            key={currentImage}
            src={currentImage}
            alt={`${chalet.name} - foto ${currentIndex + 1}`}
            className="max-h-[72vh] max-w-full object-contain rounded-2xl shadow-2xl transition-all duration-300"
            referrerPolicy="no-referrer"
          />

          {/* Subtle bottom caption on photo */}
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white/90 bg-black/60 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/15 max-w-lg mx-auto pointer-events-none">
            <span className="font-serif-luxury font-medium text-sm truncate">
              {chalet.name}
            </span>
            <span className="text-[11px] text-amber-200/90 whitespace-nowrap pl-2">
              Foto {currentIndex + 1} de {totalImages}
            </span>
          </div>
        </div>

        {/* Previous Button */}
        {totalImages > 1 && (
          <button
            type="button"
            onClick={handlePrev}
            className="absolute left-3 sm:left-8 top-1/2 -translate-y-1/2 p-3.5 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition-all cursor-pointer shadow-xl hover:scale-105 active:scale-95"
            aria-label="Foto anterior"
            title="Foto anterior (Seta esquerda)"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Next Button */}
        {totalImages > 1 && (
          <button
            type="button"
            onClick={handleNext}
            className="absolute right-3 sm:right-8 top-1/2 -translate-y-1/2 p-3.5 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition-all cursor-pointer shadow-xl hover:scale-105 active:scale-95"
            aria-label="Próxima foto"
            title="Próxima foto (Seta direita)"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom Thumbnail Strip */}
      <div 
        className="w-full bg-black/60 backdrop-blur-md border-t border-white/10 px-4 sm:px-8 py-3.5 z-10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          
          {/* Thumbnails Carousel */}
          <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-thin scrollbar-thumb-white/20 flex-1">
            {chalet.images.map((img, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                className={`relative flex-shrink-0 w-16 h-12 sm:w-20 sm:h-14 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                  currentIndex === idx
                    ? 'border-amber-400 scale-105 shadow-md shadow-amber-400/20'
                    : 'border-white/20 opacity-60 hover:opacity-100 hover:border-white/50'
                }`}
                title={`Ir para foto ${idx + 1}`}
              >
                <img
                  src={img}
                  alt={`Miniatura ${idx + 1}`}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                {currentIndex === idx && (
                  <div className="absolute inset-0 bg-amber-400/10" />
                )}
              </button>
            ))}
          </div>

          {/* Mobile Book Button */}
          {onBookChalet && (
            <button
              type="button"
              onClick={() => onBookChalet(chalet)}
              className="sm:hidden flex items-center gap-1 px-3.5 py-2 rounded-xl bg-white text-[#1c1917] text-xs font-semibold shadow-md whitespace-nowrap"
            >
              <span>Reservar</span>
            </button>
          )}

        </div>
      </div>

    </div>
  );
};
