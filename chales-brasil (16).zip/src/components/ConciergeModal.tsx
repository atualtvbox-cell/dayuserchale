import React, { useState } from 'react';
import { X, Send, Sparkles, MessageCircle, PhoneCall, ShieldCheck, Check, ArrowRight } from 'lucide-react';
import { CHALETS } from '../data/chalets';
import { Chalet } from '../types';

interface ConciergeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectChalet: (chalet: Chalet) => void;
}

interface Message {
  sender: 'concierge' | 'user';
  text: string;
  recommendedChaletId?: string;
}

export const ConciergeModal: React.FC<ConciergeModalProps> = ({
  isOpen,
  onClose,
  onSelectChalet,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'concierge',
      text: 'Olá! Sou Sofia, Concierge da Mantiqueira & Co. Nossa missão é encontrar o chalé perfeito para o seu momento a dois ou em família. Como posso personalizar sua experiência hoje?',
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  if (!isOpen) return null;

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputValue;
    if (!text.trim()) return;

    const userMsg: Message = { sender: 'user', text };
    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');

    // Concierge intelligent guidance
    setTimeout(() => {
      const lower = text.toLowerCase();
      let reply: Message;

      if (lower.includes('casamento') || lower.includes('lua de mel') || lower.includes('romântico')) {
        reply = {
          sender: 'concierge',
          text: 'Para momentos a dois inesquecíveis, nossa principal recomendação é o "Chalé Mirante das Araucárias" em Gonçalves (MG) ou a "Cabana Glass & Mist" em Urubici. Ambos contam com ofurô aquecido privativo no deck, banheira esculpida, lareira a lenha e privacidade total.',
          recommendedChaletId: 'chale-mirante-araucarias',
        };
      } else if (lower.includes('pet') || lower.includes('cachorro') || lower.includes('animais')) {
        reply = {
          sender: 'concierge',
          text: 'Amamos pets! O "Refúgio Pedra do Baú" em São Bento do Sapucaí e o "Eco-Lodge Neblina Dourada" em Monte Verde possuem gramado amplo e aceitam cães com carinho especial, incluindo potes e mantinhas.',
          recommendedChaletId: 'refugio-pedra-do-bau',
        };
      } else if (lower.includes('frio') || lower.includes('geada') || lower.includes('neve') || lower.includes('sul')) {
        reply = {
          sender: 'concierge',
          text: 'Para quem busca o frio mais rigoroso do Brasil com lareira crepitando, recomendo a "Cabana Glass & Mist" em Urubici (SC), a mais de 1.700m de altitude com frequente registro de temperaturas negativas e geada!',
          recommendedChaletId: 'cabana-glass-mist-urubici',
        };
      } else if (lower.includes('fondue') || lower.includes('chef') || lower.includes('jantar')) {
        reply = {
          sender: 'concierge',
          text: 'Temos opções de jantar de fondue artesanal harmonizado com vinhos da serra ou até chef privado servido na varanda do seu chalé. No "Vila dos Pinhais A-Frame" em Campos do Jordão isso pode ser agendado com nosso concierge direto.',
          recommendedChaletId: 'vila-dos-pinhais-campos-jordao',
        };
      } else {
        reply = {
          sender: 'concierge',
          text: 'Excelente! Nossos chalés são inspecionados presencialmente com isolamento acústico térmico, lareira a lenha inclusa e cesta de café colonial entregue toda manhã. Dê uma olhada na nossa coleção principal!',
        };
      }

      setMessages((prev) => [...prev, reply]);
    }, 600);
  };

  const quickQuestions = [
    'Qual o mais romântico para pedido de casamento?',
    'Quais aceitam pets?',
    'Onde faz mais frio com geada?',
    'Como funciona o café da manhã na cesta?',
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-center items-center p-4 animate-fadeIn">
      <div className="bg-[#FAF9F5] text-[#1c1917] rounded-3xl max-w-xl w-full h-[620px] shadow-2xl border border-[#ded7c4] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#e9e3d5] flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#222c1f] text-[#FAF9F5] flex items-center justify-center font-serif-luxury text-lg font-semibold">
              M
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-serif-luxury text-lg font-semibold text-[#1c1917]">Sofia · Concierge Mantiqueira</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>
              <span className="text-[11px] text-[#78716c]">Atendimento exclusivo & curadoria personalizada</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#ede6d8] text-[#78716c] hover:text-[#1c1917] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-[#222c1f] text-white rounded-br-none shadow-sm'
                    : 'bg-white text-[#1c1917] border border-[#e9e3d5] rounded-bl-none shadow-sm'
                }`}
              >
                {m.text}

                {/* If there is a recommended chalet */}
                {m.recommendedChaletId && (
                  <div className="mt-3 pt-3 border-t border-[#ede6d8]">
                    {(() => {
                      const c = CHALETS.find((item) => item.id === m.recommendedChaletId);
                      if (!c) return null;
                      return (
                        <div
                          onClick={() => {
                            onSelectChalet(c);
                            onClose();
                          }}
                          className="flex items-center justify-between gap-3 p-2 rounded-lg bg-[#FAF9F5] hover:bg-[#ede6d8] transition-colors cursor-pointer border border-[#ded7c4]"
                        >
                          <div className="flex items-center gap-2">
                            <img
                              src={c.coverImage}
                              alt={c.name}
                              className="w-10 h-10 rounded-md object-cover"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <div className="font-serif-luxury font-semibold text-xs text-[#1c1917]">{c.name}</div>
                              <div className="text-[10px] text-[#78716c]">{c.city} · R$ {c.pricePerNight}/noite</div>
                            </div>
                          </div>
                          <ArrowRight className="w-4 h-4 text-[#222c1f]" />
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Quick Suggestions */}
        <div className="p-3 bg-[#f2ede4] border-t border-[#e9e3d5] flex gap-1.5 overflow-x-auto text-[11px] whitespace-nowrap scrollbar-none">
          {quickQuestions.map((q, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(q)}
              className="px-3 py-1.5 rounded-full bg-white text-[#44403c] border border-[#d6cdbd] hover:border-[#222c1f] transition-all hover:bg-[#FAF9F5]"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-white border-t border-[#e9e3d5] flex items-center gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendMessage();
            }}
            placeholder="Pergunte sobre datas, comemorações, gastronomia..."
            className="flex-1 px-4 py-2.5 text-xs sm:text-sm rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-2 focus:ring-[#222c1f]"
          />
          <button
            onClick={() => handleSendMessage()}
            className="p-2.5 bg-[#222c1f] hover:bg-[#2d3a29] text-white rounded-xl transition-colors shadow-sm"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
