import React, { useState, useEffect } from 'react';
import { Star, CheckCircle, MessageSquare, ThumbsUp, Sparkles, Filter, Plus, X, Lock } from 'lucide-react';
import { Review } from '../types';
import { INITIAL_REVIEWS } from '../data/reviews';

interface ReviewsSectionProps {
  reviews?: Review[];
  onAddReview?: (review: Review) => void;
  onAddToast?: (toast: { type: 'success' | 'info' | 'warning' | 'error'; title: string; message: string }) => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ 
  reviews: propReviews, 
  onAddReview,
  onAddToast 
}) => {
  const [localReviews, setLocalReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_reviews_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_REVIEWS;
  });

  const allReviews = propReviews || localReviews;

  useEffect(() => {
    if (!propReviews) {
      try {
        localStorage.setItem('mantiqueira_reviews_v2', JSON.stringify(localReviews));
      } catch (e) {
        console.error(e);
      }
    }
  }, [localReviews, propReviews]);

  const [filterRating, setFilterRating] = useState<number>(0);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New review form
  const [newAuthor, setNewAuthor] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newChaletName, setNewChaletName] = useState('Chalé Mirante das Araucárias');
  const [newStayType, setNewStayType] = useState('Estadia Romântica');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) return;

    // As avaliações enviadas por clientes no site entram como 'pendente' (bloqueadas)
    // para aguardar desbloqueio pelo administrador no painel Admin
    const newRev: Review = {
      id: `rev-${Date.now()}`,
      author: newAuthor.trim(),
      location: newLocation.trim() || 'Hóspede Verificado',
      date: new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }),
      rating: newRating,
      chaletName: newChaletName,
      stayType: newStayType,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=160&q=80',
      comment: newComment.trim(),
      status: 'pendente',
      isApproved: false,
      createdAt: new Date().toISOString(),
    };

    if (onAddReview) {
      onAddReview(newRev);
    } else {
      setLocalReviews([newRev, ...localReviews]);
    }

    setIsModalOpen(false);
    setNewAuthor('');
    setNewLocation('');
    setNewComment('');

    if (onAddToast) {
      onAddToast({
        type: 'info',
        title: 'Avaliação Enviada para Moderação!',
        message: 'Obrigado por compartilhar suas memórias! Sua avaliação será exibida no site assim que for desbloqueada pela administração.',
      });
    }
  };

  // Exibir SOMENTE avaliações desbloqueadas/aprovadas no site
  const visibleReviews = allReviews.filter(
    (r) => r.status === 'aprovada' || (r.isApproved === true && r.status !== 'rejeitada')
  );

  const filtered = filterRating > 0 
    ? visibleReviews.filter((r) => r.rating === filterRating) 
    : visibleReviews;

  return (
    <section id="avaliacoes" className="py-24 bg-[#f8f5ee] border-t border-[#e8e2d4] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 text-[#2d3a29] text-xs font-bold tracking-widest uppercase mb-2">
              <Sparkles className="w-4 h-4" />
              <span>Depoimentos & Experiências Reais</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1c1917] tracking-tight">
              Avaliações dos Hóspedes
            </h2>
            <p className="text-sm text-[#78716c] max-w-xl mt-3 leading-relaxed">
              Memórias autênticas de quem viveu a quietude, o aconchego da lareira e o amanhecer nas montanhas mais nobres do país.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsModalOpen(true)}
              className="px-5 py-2.5 rounded-xl bg-[#222c1f] hover:bg-[#2d3a29] text-white text-xs font-semibold flex items-center gap-2 transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Avaliar Minha Estadia</span>
            </button>
          </div>
        </div>

        {/* Aggregate Ratings Scoreboard */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-[#f4efe4] flex items-center justify-center text-[#2d3a29] font-serif-luxury text-2xl font-bold">
              4.98
            </div>
            <div>
              <div className="flex items-center gap-0.5 text-amber-500 mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <div className="text-xs font-semibold text-[#1c1917]">Média Geral de Satisfação</div>
              <div className="text-[11px] text-[#78716c]">+1.480 estadias avaliadas</div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs">
            <div className="text-xs text-[#78716c] uppercase font-bold tracking-wider">Conforto & Lareira</div>
            <div className="text-2xl font-bold font-serif-luxury text-[#1c1917] mt-1">5.0 / 5.0</div>
            <div className="text-[11px] text-[#2d3a29] font-medium mt-1">Lenha nobre e isolamento térmico</div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs">
            <div className="text-xs text-[#78716c] uppercase font-bold tracking-wider">Café Colonial Artesanal</div>
            <div className="text-2xl font-bold font-serif-luxury text-[#1c1917] mt-1">4.97 / 5.0</div>
            <div className="text-[11px] text-[#2d3a29] font-medium mt-1">Produtos frescos e queijos locais</div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs">
            <div className="text-xs text-[#78716c] uppercase font-bold tracking-wider">Concierge & Atendimento</div>
            <div className="text-2xl font-bold font-serif-luxury text-[#1c1917] mt-1">99.4%</div>
            <div className="text-[11px] text-emerald-700 font-medium mt-1">Hóspedes que retornam ou indicam</div>
          </div>
        </div>

        {/* Reviews Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((rev: any) => (
            <div
              key={rev.id}
              className="bg-white rounded-2xl p-6 sm:p-7 border border-[#e5decb] shadow-xs flex flex-col justify-between hover:border-[#cfc6b4] transition-all"
            >
              <div>
                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={rev.avatar}
                      alt={rev.author}
                      className="w-12 h-12 rounded-full object-cover border border-[#d6cdbd]"
                    />
                    <div>
                      <h4 className="font-semibold text-sm text-[#1c1917]">{rev.author}</h4>
                      <p className="text-xs text-[#78716c]">{rev.location}</p>
                    </div>
                  </div>

                  <div className="flex flex-col items-end">
                    <div className="flex items-center gap-0.5 text-amber-500">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-current" />
                      ))}
                    </div>
                    <span className="text-[10px] text-[#a8a29e] mt-1 font-mono">{rev.date}</span>
                  </div>
                </div>

                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#FAF9F5] border border-[#e5decb] text-[11px] text-[#57534e] font-medium mb-3">
                  <span className="font-semibold text-[#1c1917]">{rev.chaletName}</span>
                  <span>·</span>
                  <span>{rev.stayType}</span>
                </div>

                <p className="text-xs sm:text-sm text-[#44403c] leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-[#f2ede4] flex items-center justify-between text-[11px] text-[#78716c]">
                <div className="flex items-center gap-1 text-emerald-700 font-medium">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Estadia Verificada</span>
                </div>
                <div className="flex items-center gap-1 text-[#57534e]">
                  <ThumbsUp className="w-3 h-3" />
                  <span>Recomenda esta experiência</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Modal: Write New Review */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-center p-4">
          <div className="bg-[#FAF9F5] text-[#1c1917] rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#ded7c4] flex flex-col">
            <div className="px-6 py-4 border-b border-[#e5decb] flex items-center justify-between bg-white">
              <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
                Compartilhe sua Avaliação
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-[#ede6d8] text-[#78716c]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitReview} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#44403c] mb-1">Seu Nome Completo *</label>
                <input
                  type="text"
                  required
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="Ex: Dra. Mariana Costa"
                  className="w-full px-3.5 py-2 rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-white text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#44403c] mb-1">Sua Cidade / Estado</label>
                  <input
                    type="text"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    placeholder="Ex: São Paulo, SP"
                    className="w-full px-3.5 py-2 rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#44403c] mb-1">Nota (Estrelas)</label>
                  <select
                    value={newRating}
                    onChange={(e) => setNewRating(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-[#d6cdbd] focus:outline-none bg-white cursor-pointer"
                  >
                    <option value={5}>⭐⭐⭐⭐⭐ (5 estrelas - Excepcional)</option>
                    <option value={4}>⭐⭐⭐⭐ (4 estrelas - Excelente)</option>
                    <option value={3}>⭐⭐⭐ (3 estrelas - Muito Bom)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#44403c] mb-1">Chalé Onde se Hospedou</label>
                  <input
                    type="text"
                    value={newChaletName}
                    onChange={(e) => setNewChaletName(e.target.value)}
                    placeholder="Nome do chalé"
                    className="w-full px-3.5 py-2 rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#44403c] mb-1">Ocasião da Viagem</label>
                  <input
                    type="text"
                    value={newStayType}
                    onChange={(e) => setNewStayType(e.target.value)}
                    placeholder="Ex: Lua de Mel · 3 noites"
                    className="w-full px-3.5 py-2 rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#44403c] mb-1">Seu Depoimento *</label>
                <textarea
                  rows={4}
                  required
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Conte como foi sua experiência com a lareira, a banheira, o café da manhã e a vista das montanhas..."
                  className="w-full px-3.5 py-2 rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-white"
                />
              </div>

              <div className="bg-[#FAF9F5] p-3 rounded-xl border border-[#ede6d8] flex items-center gap-2 text-[11px] text-[#78716c]">
                <Lock className="w-4 h-4 text-amber-700 shrink-0" />
                <span>
                  Para garantir a autenticidade da comunidade, sua avaliação será revisada e <strong>desbloqueada pela administração</strong> antes de ser exibida no site.
                </span>
              </div>

              <div className="pt-3 border-t border-[#e5decb] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-[#d6cdbd] text-[#57534e] hover:bg-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#222c1f] hover:bg-[#2d3a29] text-white font-semibold shadow-xs"
                >
                  Publicar Avaliação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </section>
  );
};
