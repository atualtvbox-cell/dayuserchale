import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Chalet, Reservation } from '../types';
import { Star, MapPin, Users, ChevronRight, Compass, Layers, ShieldCheck } from 'lucide-react';

interface ChaletMapViewProps {
  chalets: Chalet[];
  reservations: Reservation[];
  onSelectChalet: (chalet: Chalet) => void;
  onOpenGallery?: (chalet: Chalet) => void;
}

export const ChaletMapView: React.FC<ChaletMapViewProps> = ({
  chalets,
  reservations,
  onSelectChalet,
  onOpenGallery,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  
  const [selectedChaletId, setSelectedChaletId] = useState<string | null>(chalets[0]?.id || null);
  const [activeRegionFilter, setActiveRegionFilter] = useState<'all' | 'mantiqueira' | 'catarinense' | 'gaucha'>('all');

  // Check if a chalet is booked in October
  const isChaletOccupied = (chaletId: string) => {
    return reservations.some((r) => r.chaletId === chaletId && r.status === 'confirmada');
  };

  // Initialize and update Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Create map if not existing
    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [-25.5, -48.0],
        zoom: 6,
        scrollWheelZoom: true,
      });

      // CartoDB Positron / OSM clean tile layer for luxury look
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        maxZoom: 18,
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Clear previous markers
    markersRef.current.forEach((marker) => marker.remove());
    markersRef.current = [];

    // Filter chalets based on active region
    const displayedChalets = chalets.filter((c) => {
      if (activeRegionFilter === 'mantiqueira') {
        return c.region.toLowerCase().includes('mantiqueira');
      }
      if (activeRegionFilter === 'catarinense') {
        return c.region.toLowerCase().includes('catarinense') || c.state === 'SC';
      }
      if (activeRegionFilter === 'gaucha') {
        return c.region.toLowerCase().includes('gaúcha') || c.state === 'RS';
      }
      return true;
    });

    const bounds = L.latLngBounds([]);

    // Add luxury custom DivIcon markers
    displayedChalets.forEach((chalet) => {
      if (!chalet.coordinates) return;

      const { lat, lng } = chalet.coordinates;
      bounds.extend([lat, lng]);

      const occupied = isChaletOccupied(chalet.id);
      const isSelected = selectedChaletId === chalet.id;

      // Custom HTML Marker matching luxury aesthetic
      const markerHtml = `
        <div class="group cursor-pointer transform transition-all duration-300 ${
          isSelected ? 'scale-110 z-50' : 'hover:scale-105'
        }">
          <div class="px-2.5 py-1 rounded-full text-xs font-mono font-bold flex items-center gap-1.5 shadow-md border ${
            occupied
              ? 'bg-[#1c1917] text-white border-red-500'
              : 'bg-[#222c1f] text-white border-[#d6cdbd]'
          } ${isSelected ? 'ring-2 ring-emerald-500 shadow-xl' : ''}">
            <span class="w-2 h-2 rounded-full ${occupied ? 'bg-red-400 animate-pulse' : 'bg-emerald-400'}"></span>
            <span>R$ ${chalet.pricePerNight}</span>
          </div>
          <div class="w-2 h-2 bg-[#222c1f] rotate-45 mx-auto -mt-1 shadow-sm"></div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'chalet-map-marker-container',
        html: markerHtml,
        iconSize: [85, 34],
        iconAnchor: [42, 34],
      });

      const marker = L.marker([lat, lng], { icon: customIcon }).addTo(map);

      marker.on('click', () => {
        setSelectedChaletId(chalet.id);
        map.panTo([lat, lng], { animate: true, duration: 0.6 });
      });

      markersRef.current.push(marker);
    });

    if (displayedChalets.length > 0 && bounds.isValid()) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 12 });
    }

    return () => {
      // Keep map alive for fast switching, destroyed on unmount
    };
  }, [chalets, activeRegionFilter, reservations, selectedChaletId]);

  // Clean cleanup on component unmount
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  const selectedChalet = chalets.find((c) => c.id === selectedChaletId) || chalets[0];

  const handleRegionClick = (region: 'all' | 'mantiqueira' | 'catarinense' | 'gaucha') => {
    setActiveRegionFilter(region);
    const map = mapInstanceRef.current;
    if (!map) return;

    if (region === 'mantiqueira') {
      map.flyTo([-22.65, -45.7], 9, { duration: 1.2 });
    } else if (region === 'catarinense') {
      map.flyTo([-28.3, -49.8], 8, { duration: 1.2 });
    } else if (region === 'gaucha') {
      map.flyTo([-29.37, -50.87], 9, { duration: 1.2 });
    } else {
      map.flyTo([-25.5, -48.0], 6, { duration: 1.2 });
    }
  };

  return (
    <div className="bg-[#FAF9F5] border border-[#e5decb] rounded-3xl overflow-hidden shadow-lg flex flex-col my-6">
      
      {/* Map Control Header */}
      <div className="p-4 sm:p-5 bg-white border-b border-[#e5decb] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-[#222c1f] text-white">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
              Mapa das Serras Brasileiras
            </h3>
            <p className="text-xs text-[#78716c]">
              Explore a localização geográfica real dos chalés de altitude
            </p>
          </div>
        </div>

        {/* Region Quick Filters */}
        <div className="flex flex-wrap items-center gap-1.5 bg-[#FAF9F5] p-1 rounded-xl border border-[#ded7c4] text-xs font-medium">
          <button
            onClick={() => handleRegionClick('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeRegionFilter === 'all' ? 'bg-[#222c1f] text-white' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            Todas as Serras ({chalets.length})
          </button>
          <button
            onClick={() => handleRegionClick('mantiqueira')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeRegionFilter === 'mantiqueira' ? 'bg-[#222c1f] text-white' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            Mantiqueira (SP/MG/RJ)
          </button>
          <button
            onClick={() => handleRegionClick('catarinense')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeRegionFilter === 'catarinense' ? 'bg-[#222c1f] text-white' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            Serra Catarinense (SC)
          </button>
          <button
            onClick={() => handleRegionClick('gaucha')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              activeRegionFilter === 'gaucha' ? 'bg-[#222c1f] text-white' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            Serra Gaúcha (RS)
          </button>
        </div>
      </div>

      {/* Map Viewport & Interactive Floating Card Grid */}
      <div className="relative w-full h-[520px] sm:h-[600px] flex">
        
        {/* Leaflet Map Div */}
        <div ref={mapContainerRef} className="w-full h-full z-10" />

        {/* Floating Selected Chalet Card */}
        {selectedChalet && (
          <div className="absolute bottom-5 left-4 right-4 sm:right-auto sm:left-6 z-30 max-w-sm w-full bg-white/95 backdrop-blur-md border border-[#ded7c4] rounded-2xl p-4 shadow-2xl animate-fadeIn">
            <div className="flex gap-3">
              <img
                src={selectedChalet.coverImage}
                alt={selectedChalet.name}
                onClick={() => {
                  if (onOpenGallery) {
                    onOpenGallery(selectedChalet);
                  } else {
                    onSelectChalet(selectedChalet);
                  }
                }}
                className="w-24 h-24 rounded-xl object-cover bg-[#222c1f] shrink-0 cursor-pointer hover:opacity-90 transition-opacity"
                title="Clique para abrir a galeria de fotos deste chalé"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-[11px] text-[#78716c]">
                    <span className="uppercase tracking-wider font-semibold truncate">
                      {selectedChalet.city}, {selectedChalet.state}
                    </span>
                    <span className="font-mono tabular-nums">{selectedChalet.altitudeMeters}m</span>
                  </div>
                  <h4 className="font-serif-luxury text-base font-bold text-[#1c1917] truncate leading-tight mt-0.5">
                    {selectedChalet.name}
                  </h4>
                  <div className="flex items-center text-xs text-[#2d3a29] font-medium mt-1">
                    <Star className="w-3 h-3 fill-[#2d3a29] mr-0.5" />
                    <span>{selectedChalet.rating.toFixed(2)} ({selectedChalet.reviewCount})</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#f2ede4] mt-2">
                  <div className="text-xs font-mono font-bold text-[#1c1917]">
                    R$ {selectedChalet.pricePerNight.toLocaleString('pt-BR')} <span className="text-[10px] font-normal text-[#78716c]">/ noite</span>
                  </div>
                  <button
                    onClick={() => onSelectChalet(selectedChalet)}
                    className="px-3 py-1.5 rounded-lg bg-[#222c1f] hover:bg-[#2d3a29] text-white text-xs font-semibold flex items-center gap-1 transition-colors shadow-xs"
                  >
                    <span>Ver Chalé</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Occupied / Free quick indicator */}
            <div className="mt-2.5 pt-2 border-t border-[#f2ede4] flex items-center justify-between text-[11px]">
              {isChaletOccupied(selectedChalet.id) ? (
                <span className="text-red-700 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" />
                  Datas ocupadas neste mês
                </span>
              ) : (
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                  Datas livres disponíveis
                </span>
              )}
              <span className="text-[#a8a29e]">{selectedChalet.style}</span>
            </div>
          </div>
        )}

        {/* Map Legend Overlay */}
        <div className="absolute top-4 right-4 z-20 bg-white/90 backdrop-blur-md border border-[#e5decb] rounded-xl px-3 py-2 text-[11px] text-[#57534e] shadow-sm hidden sm:flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Datas Livres</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            <span>Com Reservas</span>
          </div>
        </div>

      </div>

    </div>
  );
};
