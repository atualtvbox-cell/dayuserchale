import React, { useState } from 'react';
import { Bookmark, Calendar, Download, PhoneCall, ShieldCheck, Menu, X, Star, MessageCircle, Home, MapPin, Sparkles } from 'lucide-react';

interface NavbarProps {
  companyName?: string;
  favoriteCount: number;
  reservationCount: number;
  onOpenFavorites: () => void;
  onOpenReservations: () => void;
  onOpenConcierge: () => void;
  onOpenAdmin: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  companyName = 'Mantiqueira & Co.',
  favoriteCount,
  reservationCount,
  onOpenFavorites,
  onOpenReservations,
  onOpenConcierge,
  onOpenAdmin,
  onNavigateSection,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string) => {
    onNavigateSection(sectionId);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#121711]/90 backdrop-blur-md border-b border-white/15 text-white shadow-lg transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Zone 1: Wordmark */}
        <button
          onClick={() => handleNavClick('hero')}
          className="text-left group focus:outline-none flex items-center gap-2"
        >
          <span className="font-serif-luxury text-2xl sm:text-3xl font-semibold tracking-tight text-white group-hover:text-[#ded7c4] transition-colors drop-shadow-sm">
            {companyName}
          </span>
          <span className="sr-only">Chalés Exclusivos do Brasil</span>
        </button>

        {/* Zone 2: Navigation Links (High contrast on top of hero) */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-sm font-semibold text-white/90">
          <button
            onClick={() => handleNavClick('colecao')}
            className="hover:text-white transition-colors relative py-1.5 focus:outline-none after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#d4c5a9] hover:after:w-full after:transition-all"
          >
            Coleção de Chalés
          </button>
          <button
            onClick={() => handleNavClick('destinos')}
            className="hover:text-white transition-colors relative py-1.5 focus:outline-none after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#d4c5a9] hover:after:w-full after:transition-all"
          >
            Destinos
          </button>
          <button
            onClick={() => handleNavClick('experiencias')}
            className="hover:text-white transition-colors relative py-1.5 focus:outline-none after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#d4c5a9] hover:after:w-full after:transition-all"
          >
            Experiências
          </button>
          <button
            onClick={() => handleNavClick('avaliacoes')}
            className="hover:text-amber-300 transition-colors relative py-1.5 focus:outline-none flex items-center gap-1.5 font-bold text-amber-300/90"
          >
            <Star className="w-3.5 h-3.5 fill-current" />
            <span>Avaliações</span>
          </button>
          <button
            onClick={() => handleNavClick('fale-conosco')}
            className="hover:text-emerald-300 transition-colors relative py-1.5 focus:outline-none flex items-center gap-1.5 font-bold text-emerald-300/90"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Fale Conosco</span>
          </button>
        </nav>

        {/* Zone 3: Primary action buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          <a
            href="/chales-brasil.zip"
            download="chales-brasil.zip"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-white hover:bg-white/15 transition-colors text-xs font-semibold border border-white/25 focus-visible:ring-2 focus-visible:ring-white"
            title="Baixar projeto compactado (.ZIP)"
          >
            <Download className="w-3.5 h-3.5 text-[#ded7c4]" />
            <span className="hidden sm:inline">Baixar .ZIP</span>
          </a>

          <button
            onClick={onOpenFavorites}
            className="relative p-2 rounded-lg text-white/90 hover:text-white hover:bg-white/10 transition-colors flex items-center gap-1 focus-visible:ring-2 focus-visible:ring-white"
            title="Chalés salvos"
            aria-label="Chalés salvos"
          >
            <Bookmark className="w-4 h-4" />
            <span className="hidden xl:inline text-xs font-medium">Salvos</span>
            {favoriteCount > 0 && (
              <span className="tabular-nums text-xs font-bold bg-[#ded7c4] text-[#121711] px-1.5 py-0.5 rounded-full min-w-5 text-center leading-none">
                {favoriteCount}
              </span>
            )}
          </button>

          <button
            onClick={onOpenReservations}
            className="relative p-2 rounded-lg text-white/90 hover:text-white hover:bg-white/10 transition-colors flex items-center gap-1 focus-visible:ring-2 focus-visible:ring-white"
            title="Minhas reservas"
            aria-label="Minhas reservas"
          >
            <Calendar className="w-4 h-4" />
            <span className="hidden xl:inline text-xs font-medium">Reservas</span>
            {reservationCount > 0 && (
              <span className="tabular-nums text-xs font-bold bg-amber-500 text-white px-1.5 py-0.5 rounded-full min-w-5 text-center leading-none">
                {reservationCount}
              </span>
            )}
          </button>

          <button
            onClick={onOpenAdmin}
            className="p-2 rounded-lg text-white/90 hover:text-white hover:bg-white/10 transition-colors flex items-center gap-1 focus-visible:ring-2 focus-visible:ring-white"
            title="Painel Administrativo"
            aria-label="Painel Administrativo"
          >
            <ShieldCheck className="w-4 h-4 text-[#ded7c4]" />
            <span className="hidden xl:inline text-xs font-medium">Admin</span>
          </button>

          <button
            onClick={onOpenConcierge}
            className="px-3.5 py-2 text-xs font-semibold tracking-wide uppercase text-white bg-[#2d3a29] hover:bg-[#384833] border border-white/20 rounded-xl transition-all flex items-center gap-1.5 shadow-md whitespace-nowrap"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Concierge</span>
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-white hover:bg-white/10 transition-colors ml-1"
            title="Abrir menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

      </div>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#161d15] border-t border-white/15 px-4 py-4 space-y-2 animate-fadeIn">
          <button
            onClick={() => handleNavClick('colecao')}
            className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/10 text-sm font-semibold flex items-center gap-2 text-white"
          >
            <Home className="w-4 h-4 text-[#ded7c4]" />
            <span>Coleção de Chalés</span>
          </button>
          <button
            onClick={() => handleNavClick('destinos')}
            className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/10 text-sm font-semibold flex items-center gap-2 text-white"
          >
            <MapPin className="w-4 h-4 text-[#ded7c4]" />
            <span>Destinos de Altitude</span>
          </button>
          <button
            onClick={() => handleNavClick('experiencias')}
            className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-white/10 text-sm font-semibold flex items-center gap-2 text-white"
          >
            <Sparkles className="w-4 h-4 text-[#ded7c4]" />
            <span>Experiências & Rituais</span>
          </button>
          <button
            onClick={() => handleNavClick('avaliacoes')}
            className="w-full text-left px-3 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-sm font-semibold flex items-center gap-2 text-amber-300"
          >
            <Star className="w-4 h-4 fill-current" />
            <span>Avaliações dos Hóspedes</span>
          </button>
          <button
            onClick={() => handleNavClick('fale-conosco')}
            className="w-full text-left px-3 py-2.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-sm font-semibold flex items-center gap-2 text-emerald-300"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Fale Conosco & Concierge</span>
          </button>
        </div>
      )}
    </header>
  );
};

