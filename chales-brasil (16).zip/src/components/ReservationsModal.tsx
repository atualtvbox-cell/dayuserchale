import React, { useState, useEffect } from 'react';
import { X, Calendar, MapPin, Users, CheckCircle, Coffee, MessageCircle, Trash2, Clock, Check } from 'lucide-react';
import { Reservation } from '../types';
import { ChaletHostChat } from './ChaletHostChat';

interface ReservationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  reservations: Reservation[];
  onCancelReservation: (id: string) => void;
  onConfirmPayment?: (id: string) => void;
}

export const ReservationsModal: React.FC<ReservationsModalProps> = ({
  isOpen,
  onClose,
  reservations,
  onCancelReservation,
  onConfirmPayment,
}) => {
  const [, setTick] = useState(0);
  const [activeChatReservationId, setActiveChatReservationId] = useState<string | null>(null);

  // Update countdown every second
  useEffect(() => {
    if (!isOpen) return;
    const timer = setInterval(() => {
      setTick((t) => t + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const formatCountdown = (expiresAt?: number) => {
    if (!expiresAt) return '60:00';
    const diff = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
    const mins = Math.floor(diff / 60);
    const secs = diff % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-center p-4">
      <div className="bg-[#FAF9F5] text-[#1c1917] rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-[#ded7c4] flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#e9e3d5] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#2d3a29]" />
            <h2 className="font-serif-luxury text-2xl font-semibold text-[#1c1917]">
              Minhas Reservas de Refúgio
            </h2>
            <span className="text-xs font-mono tabular-nums bg-[#ede6d8] px-2 py-0.5 rounded-full text-[#44403c]">
              {reservations.length}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#ede6d8] text-[#78716c] hover:text-[#1c1917] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {reservations.length === 0 ? (
            <div className="text-center py-16 px-4 text-[#78716c] space-y-3">
              <Calendar className="w-10 h-10 mx-auto text-[#c7baa4]" />
              <h3 className="font-serif-luxury text-xl text-[#1c1917]">
                Você ainda não tem reservas confirmadas
              </h3>
              <p className="text-xs leading-relaxed max-w-xs mx-auto">
                Explore nossos chalés exclusivos e faça sua reserva com cancelamento flexível e café colonial incluso.
              </p>
            </div>
          ) : (
            reservations.map((res) => (
              <div
                key={res.id}
                className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-sm space-y-4 hover:border-[#cfc6b4] transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex gap-4">
                    <img
                      src={res.chaletImage}
                      alt={res.chaletName}
                      className="w-20 h-20 rounded-xl object-cover bg-[#222c1f]"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-[#2d3a29] bg-[#f2ecde] px-2 py-0.5 rounded">
                          {res.id}
                        </span>
                        {res.status === 'confirmada' ? (
                          <span className="text-xs text-emerald-700 font-medium flex items-center gap-1">
                            <CheckCircle className="w-3.5 h-3.5" />
                            Confirmada
                          </span>
                        ) : (
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs text-amber-700 font-semibold bg-amber-100 px-2 py-0.5 rounded flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-amber-600" />
                              Pendente ({formatCountdown(res.expiresAt)})
                            </span>
                          </div>
                        )}
                      </div>
                      <h3 className="font-serif-luxury text-xl font-semibold text-[#1c1917] mt-1">
                        {res.chaletName}
                      </h3>
                      <div className="text-xs text-[#78716c] flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{res.chaletCity}, {res.chaletState}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (confirm('Deseja realmente cancelar esta reserva?')) {
                        onCancelReservation(res.id);
                      }
                    }}
                    className="text-[#a8a29e] hover:text-red-600 transition-colors p-1"
                    title="Cancelar reserva"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 py-3 border-y border-[#f2ede4] text-xs text-[#44403c]">
                  <div>
                    <span className="text-[10px] text-[#78716c] uppercase block">Check-in</span>
                    <span className="font-semibold">{res.checkIn}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#78716c] uppercase block">Check-out</span>
                    <span className="font-semibold">{res.checkOut}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#78716c] uppercase block">Hóspedes</span>
                    <span className="font-semibold">{res.guests} pessoas</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#78716c] uppercase block">Total</span>
                    <span className="font-semibold font-mono text-[#2d3a29]">
                      R$ {res.totalPrice.toLocaleString('pt-BR')}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs gap-3">
                  <div className="flex items-center gap-1.5 text-[#57534e]">
                    <Coffee className="w-4 h-4 text-[#2d3a29]" />
                    <span>Cesta de café colonial inclusa às 08h30</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {res.status === 'pendente' && onConfirmPayment && (
                      <button
                        onClick={() => onConfirmPayment(res.id)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold transition-colors flex items-center gap-1 shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Confirmar Pagamento</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() =>
                        setActiveChatReservationId(activeChatReservationId === res.id ? null : res.id)
                      }
                      className="px-3 py-1.5 rounded-lg border border-[#222c1f] text-[#222c1f] hover:bg-[#ede6d8] transition-colors flex items-center gap-1 font-semibold"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>{activeChatReservationId === res.id ? 'Fechar Chat' : 'Chat com Administrador'}</span>
                    </button>
                    <a
                      href={`https://wa.me/5511999999999?text=Olá!%20Tenho%20dúvidas%20sobre%20minha%20reserva%20${res.id}%20no%20chalé%20${encodeURIComponent(res.chaletName)}.`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[#57534e] hover:text-[#1c1917] hover:underline flex items-center gap-1 text-[11px]"
                    >
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>

                {/* Inline Direct Chat for this reservation */}
                {activeChatReservationId === res.id && (
                  <div className="pt-2 animate-fadeIn">
                    <ChaletHostChat
                      chaletName={res.chaletName}
                      hostName="Administração do Chalé"
                      hostAvatar={res.chaletImage}
                      hostRole="Superhost & Administrador"
                      chaletCity={res.chaletCity}
                      reservationId={res.id}
                      onClose={() => setActiveChatReservationId(null)}
                    />
                  </div>
                )}
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
