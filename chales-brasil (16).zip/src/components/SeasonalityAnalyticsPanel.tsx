import React, { useState, useMemo } from 'react';
import { 
  BarChart3, TrendingUp, Calendar, DollarSign, Snowflake, 
  Sun, Flower2, Filter, ArrowUpRight, Info, CheckCircle2,
  Percent, Sparkles, Building2, Flame
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  ComposedChart
} from 'recharts';
import { Chalet, Reservation } from '../types';

interface SeasonalityAnalyticsPanelProps {
  chalets: Chalet[];
  reservations: Reservation[];
}

interface MonthlyData {
  monthKey: string; // '01' to '12'
  monthName: string;
  shortName: string;
  season: 'Inverno' | 'Primavera' | 'Verão' | 'Outono';
  seasonColor: string;
  seasonBadge: string;
  baseReservations: number;
  baseRevenue: number;
  baseNights: number;
  // Dynamic computed totals
  totalReservations: number;
  totalRevenue: number;
  totalNights: number;
  occupancyRate: number; // percentage (0-100)
  avgTicket: number;
  isPeak: boolean;
  highlightNote: string;
}

export const SeasonalityAnalyticsPanel: React.FC<SeasonalityAnalyticsPanelProps> = ({
  chalets,
  reservations,
}) => {
  const [metricView, setMetricView] = useState<'combined' | 'volume' | 'revenue' | 'occupancy'>('combined');
  const [selectedChaletId, setSelectedChaletId] = useState<string>('all');
  const [selectedSeason, setSelectedSeason] = useState<string>('all');

  // Baseline seasonal patterns for high-end mountain chalets (Mantiqueira, Serra Catarinense, Serra Gaúcha)
  const baselineSeasonality: Omit<MonthlyData, 'totalReservations' | 'totalRevenue' | 'totalNights' | 'occupancyRate' | 'avgTicket'>[] = [
    {
      monthKey: '01',
      monthName: 'Janeiro',
      shortName: 'Jan',
      season: 'Verão',
      seasonColor: '#eab308',
      seasonBadge: 'Férias de Verão',
      baseReservations: 28,
      baseRevenue: 106400,
      baseNights: 84,
      isPeak: false,
      highlightNote: 'Férias escolares de verão; fuga do calor litorâneo para cachoeiras e noites frescas.',
    },
    {
      monthKey: '02',
      monthName: 'Fevereiro',
      shortName: 'Fev',
      season: 'Verão',
      seasonColor: '#eab308',
      seasonBadge: 'Carnaval na Serra',
      baseReservations: 24,
      baseRevenue: 93600,
      baseNights: 72,
      isPeak: false,
      highlightNote: 'Feriado prolongado de Carnaval com 100% de ocupação no pacote de 4 noites.',
    },
    {
      monthKey: '03',
      monthName: 'Março',
      shortName: 'Mar',
      season: 'Outono',
      seasonColor: '#f97316',
      seasonBadge: 'Entrada do Outono',
      baseReservations: 20,
      baseRevenue: 78000,
      baseNights: 60,
      isPeak: false,
      highlightNote: 'Início da queda de temperatura nas serras e dias límpidos sem chuva.',
    },
    {
      monthKey: '04',
      monthName: 'Abril',
      shortName: 'Abr',
      season: 'Outono',
      seasonColor: '#f97316',
      seasonBadge: 'Páscoa & Pinhão',
      baseReservations: 32,
      baseRevenue: 128000,
      baseNights: 96,
      isPeak: false,
      highlightNote: 'Páscoa e feriados de Tiradentes; colheita do pinhão e fondue.',
    },
    {
      monthKey: '05',
      monthName: 'Maio',
      shortName: 'Mai',
      season: 'Outono',
      seasonColor: '#f97316',
      seasonBadge: 'Pré-Inverno',
      baseReservations: 38,
      baseRevenue: 155800,
      baseNights: 114,
      isPeak: false,
      highlightNote: 'Termômetros abaixo de 10°C; aumento substancial de reservas para casais.',
    },
    {
      monthKey: '06',
      monthName: 'Junho',
      shortName: 'Jun',
      season: 'Inverno',
      seasonColor: '#3b82f6',
      seasonBadge: 'Pico de Inverno',
      baseReservations: 52,
      baseRevenue: 228800,
      baseNights: 156,
      isPeak: true,
      highlightNote: 'Alta temporada de inverno; geadas matinais, lareiras e festivais de inverno.',
    },
    {
      monthKey: '07',
      monthName: 'Julho',
      shortName: 'Jul',
      season: 'Inverno',
      seasonColor: '#2563eb',
      seasonBadge: 'Pico Máximo Anual',
      baseReservations: 64,
      baseRevenue: 288000,
      baseNights: 192,
      isPeak: true,
      highlightNote: 'Mês mais forte do ano; lotação esgotada semanas antes em todas as propriedades.',
    },
    {
      monthKey: '08',
      monthName: 'Agosto',
      shortName: 'Ago',
      season: 'Inverno',
      seasonColor: '#3b82f6',
      seasonBadge: 'Inverno Estendido',
      baseReservations: 46,
      baseRevenue: 202400,
      baseNights: 138,
      isPeak: true,
      highlightNote: 'Clima seco e noites com céu estrelado propício para observação astronômica.',
    },
    {
      monthKey: '09',
      monthName: 'Setembro',
      shortName: 'Set',
      season: 'Primavera',
      seasonColor: '#10b981',
      seasonBadge: 'Florada & Vinhos',
      baseReservations: 34,
      baseRevenue: 139400,
      baseNights: 102,
      isPeak: false,
      highlightNote: 'Início da florada de cerejeiras e hortênsias; turismo enológico aquecido.',
    },
    {
      monthKey: '10',
      monthName: 'Outubro',
      shortName: 'Out',
      season: 'Primavera',
      seasonColor: '#10b981',
      seasonBadge: 'Primavera da Serra',
      baseReservations: 30,
      baseRevenue: 123000,
      baseNights: 90,
      isPeak: false,
      highlightNote: 'Mês atual com alta procura para finais de semana de descanso e aniversários.',
    },
    {
      monthKey: '11',
      monthName: 'Novembro',
      shortName: 'Nov',
      season: 'Primavera',
      seasonColor: '#10b981',
      seasonBadge: 'Pré-Festas',
      baseReservations: 31,
      baseRevenue: 127100,
      baseNights: 93,
      isPeak: false,
      highlightNote: 'Feriados de Finados e Proclamação da República; clima primaveril agradável.',
    },
    {
      monthKey: '12',
      monthName: 'Dezembro',
      shortName: 'Dez',
      season: 'Verão',
      seasonColor: '#eab308',
      seasonBadge: 'Natal Luz & Réveillon',
      baseReservations: 48,
      baseRevenue: 216000,
      baseNights: 144,
      isPeak: true,
      highlightNote: 'Pacotes especiais de Natal nas montanhas e Réveillon com queima de fogos ecológica.',
    },
  ];

  // Process and compute dynamic monthly data aggregating baseline + live reservations
  const monthlyData: MonthlyData[] = useMemo(() => {
    // Filter live reservations by selected chalet if not 'all'
    const filteredLive = reservations.filter((r) => {
      if (selectedChaletId !== 'all' && r.chaletId !== selectedChaletId) {
        return false;
      }
      return r.status !== 'cancelada' && r.status !== 'expirada';
    });

    // 8 chalets * 30 days = 240 room-nights max per month (or scaled by selected chalet)
    const chaletsCount = selectedChaletId === 'all' ? chalets.length || 8 : 1;
    const maxCapacityPerMonth = chaletsCount * 30;

    return baselineSeasonality.map((b) => {
      // Find live reservations that touch this month
      const liveForMonth = filteredLive.filter((r) => {
        const checkInMonth = r.checkIn ? r.checkIn.substring(5, 7) : '';
        return checkInMonth === b.monthKey;
      });

      // Scale base if filtered to a single chalet
      const scaleFactor = selectedChaletId === 'all' ? 1 : 1 / (chalets.length || 8);
      const computedBaseRes = Math.round(b.baseReservations * scaleFactor);
      const computedBaseRev = Math.round(b.baseRevenue * scaleFactor);
      const computedBaseNights = Math.round(b.baseNights * scaleFactor);

      const liveCount = liveForMonth.length;
      const liveRev = liveForMonth.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
      const liveNights = liveForMonth.reduce((sum, item) => sum + (item.nights || 2), 0);

      const totalReservations = computedBaseRes + liveCount;
      const totalRevenue = computedBaseRev + liveRev;
      const totalNights = computedBaseNights + liveNights;

      // Occupancy rate calculation capped at 98%
      const rawOccupancy = Math.min(98, Math.round((totalNights / maxCapacityPerMonth) * 100));
      const avgTicket = totalReservations > 0 ? Math.round(totalRevenue / totalReservations) : 0;

      return {
        ...b,
        baseReservations: computedBaseRes,
        baseRevenue: computedBaseRev,
        baseNights: computedBaseNights,
        totalReservations,
        totalRevenue,
        totalNights,
        occupancyRate: Math.max(25, rawOccupancy),
        avgTicket,
      };
    });
  }, [reservations, selectedChaletId, chalets]);

  // Filtered by season if selected
  const displayedData = useMemo(() => {
    if (selectedSeason === 'all') return monthlyData;
    return monthlyData.filter((d) => d.season === selectedSeason);
  }, [monthlyData, selectedSeason]);

  // Summary Metrics
  const summaryMetrics = useMemo(() => {
    const totalYearReservations = monthlyData.reduce((acc, m) => acc + m.totalReservations, 0);
    const totalYearRevenue = monthlyData.reduce((acc, m) => acc + m.totalRevenue, 0);
    const totalYearNights = monthlyData.reduce((acc, m) => acc + m.totalNights, 0);
    const avgYearOccupancy = Math.round(monthlyData.reduce((acc, m) => acc + m.occupancyRate, 0) / monthlyData.length);
    
    // Find peak month
    const peakMonth = [...monthlyData].sort((a, b) => b.totalReservations - a.totalReservations)[0];
    // Find low month
    const lowMonth = [...monthlyData].sort((a, b) => a.totalReservations - b.totalReservations)[0];

    // Winter vs Summer revenue comparison
    const winterRevenue = monthlyData
      .filter((m) => m.season === 'Inverno')
      .reduce((acc, m) => acc + m.totalRevenue, 0);
    const winterShare = totalYearRevenue > 0 ? Math.round((winterRevenue / totalYearRevenue) * 100) : 0;

    return {
      totalYearReservations,
      totalYearRevenue,
      totalYearNights,
      avgYearOccupancy,
      peakMonth,
      lowMonth,
      winterRevenue,
      winterShare,
    };
  }, [monthlyData]);

  // Custom Tooltip for Recharts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = monthlyData.find((d) => d.shortName === label || d.monthName === label);
      if (!dataPoint) return null;

      return (
        <div className="bg-[#1c1917] text-white p-4 rounded-xl shadow-2xl border border-white/20 text-xs max-w-xs space-y-2">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-amber-400">
                {dataPoint.seasonBadge}
              </span>
              <h4 className="font-serif-luxury text-base font-bold text-white">
                {dataPoint.monthName} (2026)
              </h4>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full font-bold uppercase" style={{ backgroundColor: `${dataPoint.seasonColor}33`, color: dataPoint.seasonColor }}>
              {dataPoint.season}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
            <div>
              <span className="text-stone-400 block text-[10px]">Reservas:</span>
              <strong className="text-white text-sm font-mono">{dataPoint.totalReservations}</strong>
            </div>
            <div>
              <span className="text-stone-400 block text-[10px]">Receita Total:</span>
              <strong className="text-emerald-400 text-sm font-mono">
                R$ {dataPoint.totalRevenue.toLocaleString('pt-BR')}
              </strong>
            </div>
            <div>
              <span className="text-stone-400 block text-[10px]">Diárias Ocupadas:</span>
              <strong className="text-stone-200 text-xs font-mono">{dataPoint.totalNights} noites</strong>
            </div>
            <div>
              <span className="text-stone-400 block text-[10px]">Taxa Ocupação:</span>
              <strong className="text-amber-300 text-xs font-mono">{dataPoint.occupancyRate}%</strong>
            </div>
          </div>

          <div className="text-[10px] text-stone-300 bg-white/5 p-2 rounded-lg leading-relaxed mt-1">
            {dataPoint.highlightNote}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      
      {/* Header with Title and Control Toolbar */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#e5decb] shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#f2ede4] pb-5">
          <div>
            <div className="flex items-center gap-2 text-[#2d3a29] text-xs font-bold uppercase tracking-wider mb-1">
              <BarChart3 className="w-4 h-4" />
              <span>Inteligência de Mercado & Análise Temporal</span>
            </div>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#1c1917]">
              Sazonalidade & Volume de Reservas
            </h3>
            <p className="text-xs text-[#78716c] mt-1">
              Acompanhe a curva de demanda anual, os picos de frio do inverno, feriados prolongados e a distribuição de receita mês a mês.
            </p>
          </div>

          {/* View Mode Toggle Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-semibold text-[#78716c] mr-1 hidden sm:inline">Exibir:</span>
            <button
              type="button"
              onClick={() => setMetricView('combined')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                metricView === 'combined'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#44403c] border border-[#d6cdbd]'
              }`}
            >
              Visão Combinada
            </button>
            <button
              type="button"
              onClick={() => setMetricView('volume')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                metricView === 'volume'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#44403c] border border-[#d6cdbd]'
              }`}
            >
              Volume (Reservas)
            </button>
            <button
              type="button"
              onClick={() => setMetricView('revenue')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                metricView === 'revenue'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#44403c] border border-[#d6cdbd]'
              }`}
            >
              Receita (R$)
            </button>
            <button
              type="button"
              onClick={() => setMetricView('occupancy')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                metricView === 'occupancy'
                  ? 'bg-[#222c1f] text-white shadow-xs'
                  : 'bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#44403c] border border-[#d6cdbd]'
              }`}
            >
              Taxa de Ocupação (%)
            </button>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
          <div className="flex flex-wrap items-center gap-3">
            {/* Filter by Chalet */}
            <div className="flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5 text-[#78716c]" />
              <label className="font-semibold text-[#44403c]">Chalé:</label>
              <select
                value={selectedChaletId}
                onChange={(e) => setSelectedChaletId(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-[#d6cdbd] bg-[#FAF9F5] text-xs font-medium text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
              >
                <option value="all">Todos os Chalés ({chalets.length} propriedades)</option>
                {chalets.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.city})
                  </option>
                ))}
              </select>
            </div>

            {/* Filter by Season */}
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-[#78716c]" />
              <label className="font-semibold text-[#44403c]">Estação:</label>
              <select
                value={selectedSeason}
                onChange={(e) => setSelectedSeason(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-[#d6cdbd] bg-[#FAF9F5] text-xs font-medium text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
              >
                <option value="all">Todas as Estações do Ano</option>
                <option value="Inverno">Inverno (Junho a Agosto - Pico)</option>
                <option value="Primavera">Primavera (Setembro a Novembro)</option>
                <option value="Verão">Verão (Dezembro a Fevereiro)</option>
                <option value="Outono">Outono (Março a Maio)</option>
              </select>
            </div>
          </div>

          <div className="text-[11px] text-[#78716c] font-medium bg-[#FAF9F5] px-3 py-1 rounded-full border border-[#e5decb]">
            * Inclui dados de benchmarking de mercado + reservas ativas no sistema
          </div>
        </div>
      </div>

      {/* KPI Cards: Seasonality Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Peak Month */}
        <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase font-bold tracking-wider">
            <span>Mês de Pico Máximo</span>
            <Snowflake className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-serif-luxury text-[#1c1917]">
              {summaryMetrics.peakMonth.monthName}
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-bold">
              {summaryMetrics.peakMonth.occupancyRate}% Ocupação
            </span>
          </div>
          <div className="text-xs text-[#57534e] mt-1 font-mono">
            {summaryMetrics.peakMonth.totalReservations} reservas · R$ {summaryMetrics.peakMonth.totalRevenue.toLocaleString('pt-BR')}
          </div>
        </div>

        {/* Total Annual Projected Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase font-bold tracking-wider">
            <span>Faturamento Anual</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-[#1c1917] tabular-nums">
            R$ {summaryMetrics.totalYearRevenue.toLocaleString('pt-BR')}
          </div>
          <div className="text-xs text-emerald-700 font-medium flex items-center gap-1 mt-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Média de R$ {Math.round(summaryMetrics.totalYearRevenue / 12).toLocaleString('pt-BR')} / mês</span>
          </div>
        </div>

        {/* Winter Concentration */}
        <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase font-bold tracking-wider">
            <span>Concentração no Inverno</span>
            <Flame className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#1c1917]">
              {summaryMetrics.winterShare}%
            </span>
            <span className="text-xs text-[#78716c]">da receita anual</span>
          </div>
          <div className="text-xs text-[#57534e] mt-1">
            R$ {summaryMetrics.winterRevenue.toLocaleString('pt-BR')} em Jun/Jul/Ago
          </div>
        </div>

        {/* Occupancy Rate */}
        <div className="bg-white p-5 rounded-2xl border border-[#e5decb] shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#78716c] uppercase font-bold tracking-wider">
            <span>Ocupação Média Anual</span>
            <Percent className="w-4 h-4 text-[#2d3a29]" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#1c1917]">
              {summaryMetrics.avgYearOccupancy}%
            </span>
            <span className="text-xs text-emerald-700 font-semibold">+8% vs média do setor</span>
          </div>
          <div className="text-xs text-[#57534e] mt-1 font-mono">
            {summaryMetrics.totalYearNights} noites reservadas no ano
          </div>
        </div>

      </div>

      {/* MAIN RECHARTS CONTAINER */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#e5decb] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#f2ede4] pb-4">
          <div>
            <h4 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
              {metricView === 'combined' && 'Curva Anual de Sazonalidade: Volume de Reservas vs Faturamento'}
              {metricView === 'volume' && 'Volume Mensal de Reservas (Agendamentos por Mês)'}
              {metricView === 'revenue' && 'Evolução da Receita Bruta Mensal (R$)'}
              {metricView === 'occupancy' && 'Taxa de Ocupação Média Mensal (%)'}
            </h4>
            <p className="text-xs text-[#78716c] mt-0.5">
              Passe o mouse sobre as colunas para ver detalhes de cada mês, temporada e motivos do fluxo de turistas.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold text-[#44403c]">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-[#222c1f]" />
              <span>Volume de Reservas</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded bg-amber-500" />
              <span>Faturamento (R$)</span>
            </div>
          </div>
        </div>

        {/* Recharts Render Area */}
        <div className="w-full h-80 sm:h-96 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            {metricView === 'combined' ? (
              <ComposedChart data={displayedData} margin={{ top: 20, right: 30, left: 10, bottom: 20 }}>
                <defs>
                  <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d97706" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f2ede4" vertical={false} />
                <XAxis 
                  dataKey="shortName" 
                  stroke="#78716c" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={{ stroke: '#e5decb' }}
                />
                {/* Left Y Axis for Reservations Count */}
                <YAxis 
                  yAxisId="left" 
                  stroke="#222c1f" 
                  fontSize={11} 
                  tickLine={false} 
                  axisLine={false}
                  label={{ value: 'Qtd Reservas', angle: -90, position: 'insideLeft', style: { fill: '#78716c', fontSize: 11 } }}
                />
                {/* Right Y Axis for Revenue */}
                <YAxis 
                  yAxisId="right" 
                  orientation="right" 
                  stroke="#d97706" 
                  fontSize={11} 
                  tickLine={false} 
                  axisLine={false}
                  tickFormatter={(val) => `R$ ${(val / 1000).toFixed(0)}k`}
                  label={{ value: 'Receita (R$)', angle: 90, position: 'insideRight', style: { fill: '#d97706', fontSize: 11 } }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend 
                  wrapperStyle={{ paddingTop: '10px', fontSize: '12px' }}
                  formatter={(value) => (value === 'totalReservations' ? 'Volume de Reservas' : 'Receita Bruta (R$)')}
                />
                {/* Bar for Volume */}
                <Bar 
                  yAxisId="left" 
                  dataKey="totalReservations" 
                  name="totalReservations" 
                  radius={[6, 6, 0, 0]}
                  barSize={32}
                  fill="#222c1f"
                >
                  {displayedData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.isPeak ? '#1c1917' : '#3c4d38'} 
                    />
                  ))}
                </Bar>
                {/* Area for Revenue */}
                <Area 
                  yAxisId="right" 
                  type="monotone" 
                  dataKey="totalRevenue" 
                  name="totalRevenue" 
                  stroke="#d97706" 
                  strokeWidth={2.5}
                  fillOpacity={1} 
                  fill="url(#revenueGradient)" 
                />
              </ComposedChart>
            ) : metricView === 'volume' ? (
              <BarChart data={displayedData} margin={{ top: 20, right: 30, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f2ede4" vertical={false} />
                <XAxis dataKey="shortName" stroke="#78716c" fontSize={12} tickLine={false} axisLine={{ stroke: '#e5decb' }} />
                <YAxis stroke="#78716c" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="totalReservations" name="Reservas" radius={[8, 8, 0, 0]} fill="#222c1f">
                  {displayedData.map((entry, index) => (
                    <Cell 
                      key={`cell-vol-${index}`} 
                      fill={entry.isPeak ? '#1c1917' : '#455941'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            ) : metricView === 'revenue' ? (
              <AreaChart data={displayedData} margin={{ top: 20, right: 30, left: 10, bottom: 20 }}>
                <defs>
                  <linearGradient id="pureRevGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f2ede4" vertical={false} />
                <XAxis dataKey="shortName" stroke="#78716c" fontSize={12} tickLine={false} axisLine={{ stroke: '#e5decb' }} />
                <YAxis stroke="#78716c" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `R$ ${(v / 1000).toFixed(0)}k`} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="totalRevenue" stroke="#059669" strokeWidth={3} fill="url(#pureRevGrad)" />
              </AreaChart>
            ) : (
              <LineChart data={displayedData} margin={{ top: 20, right: 30, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f2ede4" vertical={false} />
                <XAxis dataKey="shortName" stroke="#78716c" fontSize={12} tickLine={false} axisLine={{ stroke: '#e5decb' }} />
                <YAxis stroke="#78716c" fontSize={11} tickLine={false} axisLine={false} domain={[0, 100]} tickFormatter={(v) => `${v}%`} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="occupancyRate" stroke="#2563eb" strokeWidth={3} dot={{ r: 5, fill: '#2563eb' }} activeDot={{ r: 8 }} />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Season Badges Legend */}
        <div className="pt-3 border-t border-[#f2ede4] flex flex-wrap items-center justify-between text-xs text-[#78716c] gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-semibold text-[#44403c]">Estacões:</span>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
              <span>Inverno (Pico Alto · Jun a Ago)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Primavera (Set a Nov)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
              <span>Verão (Dez a Fev)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
              <span>Outono (Mar a Mai)</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] text-[#2d3a29] font-medium">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Julho representa o ápice com 64 reservas estimadas</span>
          </div>
        </div>
      </div>

      {/* DETAILED SEASONALITY BREAKDOWN TABLE */}
      <div className="bg-white rounded-3xl border border-[#e5decb] overflow-hidden shadow-xs">
        <div className="p-5 sm:p-6 border-b border-[#f2ede4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="font-serif-luxury text-lg font-bold text-[#1c1917]">
              Detalhamento Mensal & Comportamento do Hóspede
            </h4>
            <p className="text-xs text-[#78716c] mt-0.5">
              Volume de agendamentos, ticket médio e fatores determinantes de cada período do ano.
            </p>
          </div>
          <span className="text-xs font-mono font-semibold bg-[#FAF9F5] text-[#2d3a29] px-3 py-1 rounded-full border border-[#d6cdbd] w-fit">
            12 Meses Analisados
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#44403c]">
            <thead className="bg-[#FAF9F5] border-b border-[#e5decb] text-[11px] uppercase tracking-wider text-[#78716c] font-semibold">
              <tr>
                <th className="py-3 px-4">Mês / Época</th>
                <th className="py-3 px-4">Estação</th>
                <th className="py-3 px-4 text-center">Volume (Reservas)</th>
                <th className="py-3 px-4 text-center">Diárias Ocupadas</th>
                <th className="py-3 px-4 text-right">Faturamento Estimado</th>
                <th className="py-3 px-4 text-center">Taxa de Ocupação</th>
                <th className="py-3 px-4">Fator de Demanda / Observação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f2ede4]">
              {displayedData.map((m) => (
                <tr 
                  key={m.monthKey} 
                  className={`hover:bg-[#FAF9F5] transition-colors ${m.isPeak ? 'bg-amber-50/40 font-medium' : ''}`}
                >
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-[#1c1917]">{m.monthName}</div>
                    <span className="text-[10px] text-[#78716c]">{m.seasonBadge}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span 
                      className="px-2 py-0.5 rounded-full text-[10px] font-bold"
                      style={{ backgroundColor: `${m.seasonColor}22`, color: m.seasonColor }}
                    >
                      {m.season}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-bold text-sm text-[#1c1917]">
                    {m.totalReservations}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono text-xs text-[#57534e]">
                    {m.totalNights} noites
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-[#2d3a29]">
                    R$ {m.totalRevenue.toLocaleString('pt-BR')}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <div className="inline-flex items-center gap-1.5">
                      <div className="w-16 h-2 rounded-full bg-stone-100 overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${m.occupancyRate >= 80 ? 'bg-blue-600' : m.occupancyRate >= 60 ? 'bg-emerald-600' : 'bg-amber-500'}`}
                          style={{ width: `${m.occupancyRate}%` }}
                        />
                      </div>
                      <span className="font-mono text-[11px] font-bold text-[#1c1917]">{m.occupancyRate}%</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-[11px] text-[#57534e] max-w-xs leading-relaxed">
                    {m.highlightNote}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
