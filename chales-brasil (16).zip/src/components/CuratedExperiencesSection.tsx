import React from 'react';
import { Flame, Droplets, Coffee, Sparkles } from 'lucide-react';

export const CuratedExperiencesSection: React.FC = () => {
  return (
    <section id="experiencias" className="py-20 sm:py-28 bg-[#FAF9F5] border-t border-[#e9e3d5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-3 text-xs tracking-widest uppercase text-[#78716c] mb-3">
            <span className="w-6 h-[1px] bg-[#c7baa4]" />
            <span>A Arte da Desconexão</span>
            <span className="w-6 h-[1px] bg-[#c7baa4]" />
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-[#1c1917] leading-tight text-balance mb-4">
            Rituais que transformam uma estadia em memória eterna.
          </h2>
          <p className="text-sm sm:text-base text-[#57534e] font-light leading-relaxed">
            Cada chalé de nossa curadoria é avaliado por rituais sensoriais indispensáveis: o crepitar da lenha nativa, a água aquecida de frente para as montanhas e o despertar com os sabores artesanais da serra.
          </p>
        </div>

        {/* 3 Pillars with generated photography */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Pillar 1: Lareira & Fogo */}
          <div className="group bg-white rounded-2xl overflow-hidden border border-[#e8e2d5] hover:border-[#cfc6b4] transition-all hover:shadow-md flex flex-col">
            <div className="relative aspect-[4/3] overflow-hidden bg-[#222c1f]">
              <img
                src="/src/assets/images/chalet_interior_fireplace_1790997538840.jpg"
                alt="Lareira a lenha no interior do chalé de serra"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-white text-[11px] font-medium tracking-wider uppercase">
                01. O Fogo
              </div>
            </div>
            <div className="p-6 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917] mb-2">
                  Lareiras a Lenha de Reflorestamento
                </h3>
                <p className="text-xs sm:text-sm text-[#57534e] leading-relaxed font-light">
                  Todos os chalés contam com lareiras tradicionais ou suspensas de tiragem perfeita, com cesto de lenha de nó de pinho e eucalipto sempre abastecido para noites aquecidas.
                </p>
              </div>
              <div className="mt-4 pt-4 border-t border-[#ede6d8] text-xs text-[#2d3a29] font-medium flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" />
                <span>Kit fondue & vinhos serranos disponíveis</span>
              </div>
            </div>
          </div>

          {/* Pillar 2: Banheiras & Imersão */}
          <div className="group bg-white rounded-2xl overflow-hidden border border-[#e8e2d5] hover:border-[#cfc6b4] transition-all hover:shadow-md flex flex-col">
            <div className="relative aspect-[4/3] overflow-hidden bg-[#222c1f]">
              <img
                src="/src/assets/images/chalet_jacuzzi_deck_view_1790997529472.jpg"
                alt="Deck com hidromassagem e vista para as montanhas"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-white text-[11px] font-medium tracking-wider uppercase">
                02. A Água
              </div>
            </div>
            <div className="p-6 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917] mb-2">
                  Imersão Panorâmica na Névoa
                </h3>
                <p className="text-xs sm:text-sm text-[#57534e] leading-relaxed font-light">
                  Ofurôs de cedro e hidromassagens aquecidas posicionadas nos decks externos ou de frente para paredes inteiras de vidro para contemplar o mar de nuvens e o pôr do sol.
                </p>
              </div>
              <div className="mt-4 pt-4 border-t border-[#ede6d8] text-xs text-[#2d3a29] font-medium flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5" />
                <span>Sais de banho botânicos orgânicos inclusos</span>
              </div>
            </div>
          </div>

          {/* Pillar 3: Café Colonial */}
          <div className="group bg-white rounded-2xl overflow-hidden border border-[#e8e2d5] hover:border-[#cfc6b4] transition-all hover:shadow-md flex flex-col">
            <div className="relative aspect-[4/3] overflow-hidden bg-[#222c1f]">
              <img
                src="/src/assets/images/chalet_breakfast_basket_veranda_1790997548474.jpg"
                alt="Cesta de café colonial artesanal servida na varanda"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-white text-[11px] font-medium tracking-wider uppercase">
                03. A Terra
              </div>
            </div>
            <div className="p-6 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917] mb-2">
                  Café da Manhã Colonial na Cesta
                </h3>
                <p className="text-xs sm:text-sm text-[#57534e] leading-relaxed font-light">
                  Entregue pontualmente na varanda sem interromper sua privacidade: pães de fermentação natural, queijos artesanais da Canastra e Mantiqueira, favo de mel e café moído na hora.
                </p>
              </div>
              <div className="mt-4 pt-4 border-t border-[#ede6d8] text-xs text-[#2d3a29] font-medium flex items-center gap-1.5">
                <Coffee className="w-3.5 h-3.5" />
                <span>100% de produtores e queijarias locais</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
