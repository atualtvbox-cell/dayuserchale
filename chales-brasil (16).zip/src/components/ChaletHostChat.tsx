import React, { useState, useEffect, useRef } from 'react';
import { Send, MessageCircle, X, ShieldCheck, Clock, Sparkles, Paperclip, Image as ImageIcon } from 'lucide-react';
import { fileToOptimizedDataUrl } from '../utils/imageUpload';

interface ChatMessage {
  id: string;
  sender: 'guest' | 'host';
  text: string;
  image?: string;
  time: string;
}

interface ChaletHostChatProps {
  chaletName: string;
  hostName: string;
  hostAvatar: string;
  hostRole: string;
  chaletCity: string;
  reservationId?: string;
  onClose?: () => void;
}

export const ChaletHostChat: React.FC<ChaletHostChatProps> = ({
  chaletName,
  hostName,
  hostAvatar,
  hostRole,
  chaletCity,
  reservationId,
  onClose,
}) => {
  const storageKey = `mantiqueira_chat_${chaletName.replace(/\s+/g, '_')}_${reservationId || 'pre'}`;

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) return JSON.parse(saved);
    } catch {}

    return [
      {
        id: 'msg-1',
        sender: 'host',
        text: `Olá! Sou ${hostName}, administrador(a) do ${chaletName} em ${chaletCity}. Como posso ajudar com sua estadia nas montanhas?`,
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(messages));
    } catch (e) {
      console.error(e);
    }
  }, [messages, storageKey]);

  const [inputText, setInputText] = useState('');
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, attachedImage]);

  const handleImageFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      try {
        const dataUrl = await fileToOptimizedDataUrl(file, 900, 700, 0.82);
        setAttachedImage(dataUrl);
      } catch (err) {
        console.error('Erro ao anexar imagem local:', err);
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const quickQuestions = [
    '🚗 Como é a estrada de acesso?',
    '☕ O que vem no café colonial?',
    '🐶 O chalé aceita animais de estimação?',
    '🔥 A lenha da lareira está inclusa?',
  ];

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text && !attachedImage) return;

    const newMsg: ChatMessage = {
      id: `guest-${Date.now()}`,
      sender: 'guest',
      text: text || (attachedImage ? 'Foto anexada do computador' : ''),
      image: attachedImage || undefined,
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, newMsg]);
    if (!textToSend) setInputText('');
    setAttachedImage(null);

    // Simulate host response
    setIsTyping(true);
    setTimeout(() => {
      let replyText = 'Com certeza! Teremos prazer em recebê-lo(a) nas montanhas. Se precisar de qualquer ajuste de horário ou personalização, é só nos avisar.';

      const lower = text.toLowerCase();
      if (newMsg.image) {
        replyText = 'Obrigado por compartilhar a foto! Confirmamos os detalhes com a equipe de recepção do chalé.';
      } else if (lower.includes('estrada') || lower.includes('acesso')) {
        replyText = 'O acesso é totalmente transitável para qualquer veículo de passeio, com apenas 1,8 km de estrada de terra batida bem cascalhada após o asfalto.';
      } else if (lower.includes('café') || lower.includes('colonial') || lower.includes('cesta')) {
        replyText = 'Nossa cesta colonial artesanal inclui queijos premiados da região, pães artesanais de fermentação natural, geleia de frutas vermelhas colhidas no sítio, manteiga fresca e bolo caseiro saindo do forno às 08h30 na varanda!';
      } else if (lower.includes('pet') || lower.includes('animal') || lower.includes('cachorro')) {
        replyText = 'Sim, somos pet friendly para animais de pequeno e médio porte com muito carinho! Inclusive deixamos potes de água e manta especial para eles.';
      } else if (lower.includes('lenha') || lower.includes('lareira') || lower.includes('ofurô')) {
        replyText = 'A lenha nobre de reflorestamento fica disponível no depósito privativo do chalé, sem custo adicional. Ao chegar, podemos deixar a primeira lareira pré-montada se desejar!';
      }

      const hostReply: ChatMessage = {
        id: `host-${Date.now()}`,
        sender: 'host',
        text: replyText,
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, hostReply]);
      setIsTyping(false);
    }, 1100);
  };

  return (
    <div className="flex flex-col h-full bg-[#FAF9F5] border border-[#e5decb] rounded-2xl overflow-hidden shadow-md">
      
      {/* Chat Header */}
      <div className="px-4 py-3.5 bg-white border-b border-[#e5decb] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={hostAvatar}
              alt={hostName}
              className="w-10 h-10 rounded-full object-cover border border-[#d6cdbd]"
            />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-xs text-[#1c1917]">{hostName}</span>
              <ShieldCheck className="w-3.5 h-3.5 text-[#2d3a29]" />
            </div>
            <p className="text-[11px] text-[#78716c] truncate max-w-[200px] sm:max-w-xs">
              {hostRole} · {chaletName}
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#ede6d8] text-[#78716c] transition-colors"
            title="Fechar chat"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {reservationId && (
        <div className="px-4 py-1.5 bg-[#ede6d8]/60 text-[10px] text-[#57534e] flex items-center justify-between border-b border-[#e5decb]">
          <span>Referente à Reserva: <strong>{reservationId}</strong></span>
          <span className="text-emerald-700 font-medium flex items-center gap-1">
            <Clock className="w-3 h-3" /> Responde em ~15 min
          </span>
        </div>
      )}

      {/* Messages Thread */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 min-h-[240px] max-h-[340px]">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'guest' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                msg.sender === 'guest'
                  ? 'bg-[#222c1f] text-white rounded-br-none shadow-xs'
                  : 'bg-white border border-[#e5decb] text-[#1c1917] rounded-bl-none shadow-xs'
              }`}
            >
              {msg.image && (
                <div className="mb-2 rounded-xl overflow-hidden border border-black/10 bg-black/5">
                  <img
                    src={msg.image}
                    alt="Foto enviada"
                    className="w-full max-h-48 object-cover rounded-xl"
                  />
                </div>
              )}
              {msg.text && <div>{msg.text}</div>}
            </div>
            <span className="text-[9px] text-[#a8a29e] mt-1 px-1 font-mono">
              {msg.time}
            </span>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2 text-xs text-[#78716c] italic">
            <span className="w-2 h-2 rounded-full bg-[#78716c] animate-bounce" />
            <span className="w-2 h-2 rounded-full bg-[#78716c] animate-bounce [animation-delay:0.2s]" />
            <span className="w-2 h-2 rounded-full bg-[#78716c] animate-bounce [animation-delay:0.4s]" />
            <span className="text-[11px]">{hostName} está digitando...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Questions Chips */}
      <div className="p-2.5 bg-white border-t border-[#f2ede4] overflow-x-auto whitespace-nowrap flex gap-1.5 text-[11px]">
        {quickQuestions.map((q, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => handleSendMessage(q)}
            className="px-2.5 py-1 rounded-lg bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#44403c] border border-[#d6cdbd] transition-colors shrink-0"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Attached Image Preview from Computer */}
      {attachedImage && (
        <div className="px-4 py-2 bg-[#f4efe4] border-t border-[#e5decb] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img
              src={attachedImage}
              alt="Anexo local"
              className="w-10 h-10 rounded-lg object-cover border border-[#c7baa4]"
            />
            <span className="text-[11px] font-medium text-[#44403c]">
              Foto do computador pronta para envio
            </span>
          </div>
          <button
            type="button"
            onClick={() => setAttachedImage(null)}
            className="p-1 rounded-full hover:bg-black/10 text-[#78716c]"
            title="Remover anexo"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Message Input Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="p-3 bg-white border-t border-[#e5decb] flex items-center gap-2"
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageFileSelect}
          className="hidden"
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-2 rounded-xl text-[#57534e] hover:text-[#1c1917] hover:bg-[#ede6d8] transition-colors"
          title="Enviar foto do computador"
        >
          <Paperclip className="w-4 h-4" />
        </button>

        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Envie sua dúvida para o anfitrião..."
          className="flex-1 px-3.5 py-2 rounded-xl text-xs border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
        />

        <button
          type="submit"
          disabled={!inputText.trim() && !attachedImage}
          className={`p-2 rounded-xl text-white transition-colors shadow-xs ${
            inputText.trim() || attachedImage
              ? 'bg-[#222c1f] hover:bg-[#2d3a29]'
              : 'bg-[#c7baa4] cursor-not-allowed'
          }`}
          title="Enviar mensagem"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

    </div>
  );
};
