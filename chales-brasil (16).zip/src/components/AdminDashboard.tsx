import React, { useState, useMemo } from 'react';
import { 
  LayoutDashboard, Calendar, Home, DollarSign, Users, 
  Plus, Search, Edit2, Trash2, CheckCircle, Clock, 
  ArrowUpRight, ArrowLeft, Star, Coffee, Flame, Droplets,
  AlertCircle, ChevronRight, X, Save, TrendingUp, SlidersHorizontal,
  Building2, MapPin, Phone, Mail, Check, BarChart3, MessageSquare, Lock, Unlock, Download,
  Briefcase, Lightbulb, Compass, Sparkles
} from 'lucide-react';
import { Chalet, Reservation, CompanySettings, Review, HeroSettings, DEFAULT_HERO_SETTINGS } from '../types';
import { INITIAL_REVIEWS } from '../data/reviews';
import { getDefaultWhatToBring, getDefaultRegionalTips } from '../data/chaletTipsDefaults';
import { LocalImageUploader } from './LocalImageUploader';
import { LocalGalleryUploader } from './LocalGalleryUploader';
import { MonthlyOccupancyPanel } from './MonthlyOccupancyPanel';
import { AdminReviewsManager } from './AdminReviewsManager';
import { AdminHeroEditor } from './AdminHeroEditor';

interface AdminDashboardProps {
  chalets: Chalet[];
  reservations: Reservation[];
  companySettings: CompanySettings;
  reviews?: Review[];
  heroSettings?: HeroSettings;
  onUpdateChalet: (updatedChalet: Chalet) => void;
  onAddChalet: (newChalet: Chalet) => void;
  onDeleteChalet: (chaletId: string) => void;
  onUpdateCompanySettings: (settings: CompanySettings) => void;
  onUpdateHeroSettings?: (newSettings: HeroSettings) => void;
  onUpdateReservationStatus: (reservationId: string, status: 'confirmada' | 'pendente') => void;
  onDeleteReservation: (reservationId: string) => void;
  onApproveReview?: (reviewId: string) => void;
  onBlockReview?: (reviewId: string) => void;
  onDeleteReview?: (reviewId: string) => void;
  onAddReview?: (review: Review) => void;
  onCloseAdmin: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  chalets,
  reservations,
  companySettings,
  reviews: propReviews,
  heroSettings = DEFAULT_HERO_SETTINGS,
  onUpdateChalet,
  onAddChalet,
  onDeleteChalet,
  onUpdateCompanySettings,
  onUpdateHeroSettings,
  onUpdateReservationStatus,
  onDeleteReservation,
  onApproveReview,
  onBlockReview,
  onDeleteReview,
  onAddReview,
  onCloseAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'occupancy' | 'seasonality' | 'reviews' | 'reservations' | 'chalets' | 'company' | 'hero'>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [reservationStatusFilter, setReservationStatusFilter] = useState<'all' | 'confirmada' | 'pendente'>('all');
  
  // Modal for new/edit chalet
  const [isChaletModalOpen, setIsChaletModalOpen] = useState(false);
  const [editingChalet, setEditingChalet] = useState<Partial<Chalet> | null>(null);
  const [deletingChalet, setDeletingChalet] = useState<Chalet | null>(null);

  // Amenity editor state inside chalet modal
  const [newAmenityInput, setNewAmenityInput] = useState('');
  const [editingAmenityIndex, setEditingAmenityIndex] = useState<number | null>(null);
  const [editingAmenityValue, setEditingAmenityValue] = useState('');

  const handleAddAmenity = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || !editingChalet) return;
    const current = editingChalet.amenities || [];
    if (!current.includes(trimmed)) {
      setEditingChalet({
        ...editingChalet,
        amenities: [...current, trimmed],
      });
    }
    setNewAmenityInput('');
  };

  const handleStartEditAmenity = (index: number) => {
    setEditingAmenityIndex(index);
    setEditingAmenityValue(editingChalet?.amenities?.[index] || '');
  };

  const handleSaveEditAmenity = (index: number) => {
    if (!editingChalet || !editingAmenityValue.trim()) return;
    const current = [...(editingChalet.amenities || [])];
    current[index] = editingAmenityValue.trim();
    setEditingChalet({
      ...editingChalet,
      amenities: current,
    });
    setEditingAmenityIndex(null);
    setEditingAmenityValue('');
  };

  const handleDeleteAmenity = (index: number) => {
    if (!editingChalet) return;
    const current = [...(editingChalet.amenities || [])];
    current.splice(index, 1);
    setEditingChalet({
      ...editingChalet,
      amenities: current,
    });
    if (editingAmenityIndex === index) {
      setEditingAmenityIndex(null);
      setEditingAmenityValue('');
    }
  };

  // What to bring editor state
  const [newWhatToBringInput, setNewWhatToBringInput] = useState('');
  const [editingWhatToBringIndex, setEditingWhatToBringIndex] = useState<number | null>(null);
  const [editingWhatToBringValue, setEditingWhatToBringValue] = useState('');

  const handleAddWhatToBring = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || !editingChalet) return;
    const current = editingChalet.whatToBring || [];
    if (!current.includes(trimmed)) {
      setEditingChalet({
        ...editingChalet,
        whatToBring: [...current, trimmed],
      });
    }
    setNewWhatToBringInput('');
  };

  const handleStartEditWhatToBring = (index: number) => {
    setEditingWhatToBringIndex(index);
    setEditingWhatToBringValue(editingChalet?.whatToBring?.[index] || '');
  };

  const handleSaveEditWhatToBring = (index: number) => {
    if (!editingChalet || !editingWhatToBringValue.trim()) return;
    const current = [...(editingChalet.whatToBring || [])];
    current[index] = editingWhatToBringValue.trim();
    setEditingChalet({
      ...editingChalet,
      whatToBring: current,
    });
    setEditingWhatToBringIndex(null);
    setEditingWhatToBringValue('');
  };

  const handleDeleteWhatToBring = (index: number) => {
    if (!editingChalet) return;
    const current = [...(editingChalet.whatToBring || [])];
    current.splice(index, 1);
    setEditingChalet({
      ...editingChalet,
      whatToBring: current,
    });
    if (editingWhatToBringIndex === index) {
      setEditingWhatToBringIndex(null);
      setEditingWhatToBringValue('');
    }
  };

  // Regional tips editor state
  const [newRegionalTipInput, setNewRegionalTipInput] = useState('');
  const [editingRegionalTipIndex, setEditingRegionalTipIndex] = useState<number | null>(null);
  const [editingRegionalTipValue, setEditingRegionalTipValue] = useState('');

  const handleAddRegionalTip = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || !editingChalet) return;
    const current = editingChalet.regionalTips || [];
    if (!current.includes(trimmed)) {
      setEditingChalet({
        ...editingChalet,
        regionalTips: [...current, trimmed],
      });
    }
    setNewRegionalTipInput('');
  };

  const handleStartEditRegionalTip = (index: number) => {
    setEditingRegionalTipIndex(index);
    setEditingRegionalTipValue(editingChalet?.regionalTips?.[index] || '');
  };

  const handleSaveEditRegionalTip = (index: number) => {
    if (!editingChalet || !editingRegionalTipValue.trim()) return;
    const current = [...(editingChalet.regionalTips || [])];
    current[index] = editingRegionalTipValue.trim();
    setEditingChalet({
      ...editingChalet,
      regionalTips: current,
    });
    setEditingRegionalTipIndex(null);
    setEditingRegionalTipValue('');
  };

  const handleDeleteRegionalTip = (index: number) => {
    if (!editingChalet) return;
    const current = [...(editingChalet.regionalTips || [])];
    current.splice(index, 1);
    setEditingChalet({
      ...editingChalet,
      regionalTips: current,
    });
    if (editingRegionalTipIndex === index) {
      setEditingRegionalTipIndex(null);
      setEditingRegionalTipValue('');
    }
  };

  // Company settings form state
  const [companyForm, setCompanyForm] = useState<CompanySettings>(companySettings);
  const [isCompanySaved, setIsCompanySaved] = useState(false);

  // Reviews moderation state (fallback to local storage if not passed from root)
  const [internalReviews, setInternalReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_reviews_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_REVIEWS;
  });

  const reviewsList = propReviews || internalReviews;

  const handleApproveReview = (id: string) => {
    if (onApproveReview) {
      onApproveReview(id);
    } else {
      setInternalReviews((prev) => {
        const updated = prev.map((r) => r.id === id ? { ...r, status: 'aprovada' as const, isApproved: true } : r);
        localStorage.setItem('mantiqueira_reviews_v2', JSON.stringify(updated));
        return updated;
      });
    }
  };

  const handleBlockReview = (id: string) => {
    if (onBlockReview) {
      onBlockReview(id);
    } else {
      setInternalReviews((prev) => {
        const updated = prev.map((r) => r.id === id ? { ...r, status: 'pendente' as const, isApproved: false } : r);
        localStorage.setItem('mantiqueira_reviews_v2', JSON.stringify(updated));
        return updated;
      });
    }
  };

  const handleDeleteReview = (id: string) => {
    if (onDeleteReview) {
      onDeleteReview(id);
    } else {
      setInternalReviews((prev) => {
        const updated = prev.filter((r) => r.id !== id);
        localStorage.setItem('mantiqueira_reviews_v2', JSON.stringify(updated));
        return updated;
      });
    }
  };

  const handleAddReview = (newRev: Review) => {
    if (onAddReview) {
      onAddReview(newRev);
    } else {
      setInternalReviews((prev) => {
        const updated = [newRev, ...prev];
        localStorage.setItem('mantiqueira_reviews_v2', JSON.stringify(updated));
        return updated;
      });
    }
  };

  const pendingReviewsCount = useMemo(() => {
    return reviewsList.filter((r) => r.status === 'pendente' || r.isApproved === false).length;
  }, [reviewsList]);

  // Financial calculations
  const totalRevenue = useMemo(() => {
    return reservations.reduce((acc, curr) => acc + (curr.totalPrice || 0), 0);
  }, [reservations]);

  const confirmedCount = useMemo(() => {
    return reservations.filter((r) => r.status === 'confirmada').length;
  }, [reservations]);

  const averageDailyRate = useMemo(() => {
    if (chalets.length === 0) return 0;
    const sum = chalets.reduce((acc, c) => acc + c.pricePerNight, 0);
    return Math.round(sum / chalets.length);
  }, [chalets]);

  // Filtered reservations
  const filteredReservations = useMemo(() => {
    return reservations.filter((r) => {
      if (reservationStatusFilter !== 'all' && r.status !== reservationStatusFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          r.id.toLowerCase().includes(query) ||
          r.guestName.toLowerCase().includes(query) ||
          r.chaletName.toLowerCase().includes(query) ||
          r.chaletCity.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [reservations, reservationStatusFilter, searchQuery]);

  // Filtered chalets
  const filteredChalets = useMemo(() => {
    if (!searchQuery.trim()) return chalets;
    const query = searchQuery.toLowerCase();
    return chalets.filter(
      (c) =>
        c.name.toLowerCase().includes(query) ||
        c.city.toLowerCase().includes(query) ||
        c.region.toLowerCase().includes(query)
    );
  }, [chalets, searchQuery]);

  const handleOpenNewChaletModal = () => {
    setEditingChalet({
      name: '',
      tagline: '',
      city: 'Gonçalves',
      state: 'MG',
      region: 'Serra da Mantiqueira',
      altitudeMeters: 1600,
      coordinates: { lat: -22.6586, lng: -45.8561 },
      pricePerNight: 1200,
      cleaningFee: 180,
      maxGuests: 2,
      bedrooms: 1,
      bathrooms: 1,
      style: 'A-Frame',
      rating: 5.0,
      reviewCount: 1,
      coverImage: '/src/assets/images/hero_brazilian_luxury_chalet_1790997520247.jpg',
      images: [
        '/src/assets/images/hero_brazilian_luxury_chalet_1790997520247.jpg',
        '/src/assets/images/chalet_interior_fireplace_1790997538840.jpg',
        '/src/assets/images/chalet_jacuzzi_deck_view_1790997529472.jpg',
      ],
      architecturalNote: 'Cabana de montanha com fechamento térmico em vidro e madeira nobre.',
      description: 'Refúgio de alto padrão com vista espetacular para o mar de morros e privacidade completa.',
      amenities: [
        'Hidromassagem com vista panorâmica',
        'Lareira a lenha tradicional',
        'Cesta de café colonial artesanal',
        'Wi-Fi Starlink de alta velocidade'
      ],
      experiences: [],
      host: {
        name: 'Administração Mantiqueira',
        role: 'Superhost Verificado',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
        responseTime: 'Responde em 15 minutos',
        isSuperhost: true,
      },
      whatToBring: getDefaultWhatToBring({ city: 'Gonçalves', altitudeMeters: 1600 }),
      regionalTips: getDefaultRegionalTips({ city: 'Gonçalves', state: 'MG' }),
      reviews: [],
    });
    setIsChaletModalOpen(true);
  };

  const handleSaveChalet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingChalet || !editingChalet.name) return;

    if (editingChalet.id) {
      onUpdateChalet(editingChalet as Chalet);
    } else {
      const newId = `chale-${Date.now()}`;
      onAddChalet({
        ...editingChalet,
        id: newId,
      } as Chalet);
    }
    setIsChaletModalOpen(false);
    setEditingChalet(null);
  };

  return (
    <div className="min-h-screen bg-[#F6F5F0] text-[#1c1917] flex flex-col font-sans-body">
      
      {/* Admin Top Navigation */}
      <header className="bg-white border-b border-[#e5decb] sticky top-0 z-30 px-6 py-4 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-4">
          <button
            onClick={onCloseAdmin}
            className="flex items-center gap-1.5 text-xs font-semibold text-[#57534e] hover:text-[#1c1917] bg-[#f2ede4] hover:bg-[#e8e2d5] px-3 py-1.5 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Voltar ao Site</span>
          </button>
          <div className="h-5 w-[1px] bg-[#e5decb]" />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif-luxury text-xl font-bold tracking-tight text-[#1c1917]">
                Mantiqueira & Co.
              </span>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-[#222c1f] text-white px-2 py-0.5 rounded">
                Admin Console
              </span>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex flex-wrap items-center gap-1 bg-[#ede6d8] p-1 rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'overview' ? 'bg-white text-[#1c1917] shadow-xs' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span>Visão Geral</span>
          </button>
          
          <button
            onClick={() => setActiveTab('occupancy')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'occupancy' || activeTab === 'seasonality' ? 'bg-white text-[#1c1917] shadow-xs' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-blue-600" />
            <span className="font-semibold">Ocupação Mensal</span>
            <span className="px-1.5 py-0.2 bg-amber-100 text-amber-900 rounded text-[9px] font-bold">Alta Temporada</span>
          </button>

          <button
            onClick={() => setActiveTab('reviews')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'reviews' ? 'bg-white text-[#1c1917] shadow-xs' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
            <span className="font-semibold">Avaliações & Moderação</span>
            {pendingReviewsCount > 0 ? (
              <span className="px-1.5 py-0.2 bg-amber-200 text-amber-900 rounded text-[9px] font-bold animate-pulse">
                {pendingReviewsCount} bloqueada{pendingReviewsCount > 1 ? 's' : ''}
              </span>
            ) : (
              <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-900 rounded text-[9px] font-bold">
                {reviewsList.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('reservations')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'reservations' ? 'bg-white text-[#1c1917] shadow-xs' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Reservas ({reservations.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('chalets')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'chalets' ? 'bg-white text-[#1c1917] shadow-xs' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>Chalés & Tarifas ({chalets.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('company')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'company' ? 'bg-white text-[#1c1917] shadow-xs' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Empresa & Endereço</span>
          </button>

          <button
            onClick={() => setActiveTab('hero')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
              activeTab === 'hero' ? 'bg-white text-[#1c1917] shadow-xs' : 'text-[#57534e] hover:text-[#1c1917]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Textos do Hero</span>
          </button>
        </div>

        <div className="flex items-center gap-2.5">
          <a
            href="/chales-brasil.zip"
            download="chales-brasil.zip"
            className="flex items-center gap-1.5 bg-[#FAF9F5] hover:bg-[#ede6d8] text-[#222c1f] border border-[#d6cdbd] px-3.5 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            title="Baixar arquivo ZIP com todo o código-fonte atualizado"
          >
            <Download className="w-3.5 h-3.5 text-[#2d3a29]" />
            <span>Baixar Projeto (.zip)</span>
          </a>

          <button
            onClick={handleOpenNewChaletModal}
            className="flex items-center gap-1.5 bg-[#222c1f] hover:bg-[#2d3a29] text-white px-3.5 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Novo Chalé</span>
          </button>
        </div>
      </header>

      {/* Main Body View */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full space-y-8">
        
        {/* VIEW 1: OVERVIEW METRICS */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            
            {/* KPI Cards (Tabular numerals, no nested cards) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              
              <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs">
                <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
                  <span>Faturamento Total</span>
                  <DollarSign className="w-4 h-4 text-[#2d3a29]" />
                </div>
                <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] tabular-nums mt-2">
                  R$ {totalRevenue.toLocaleString('pt-BR')}
                </div>
                <div className="text-xs text-emerald-700 font-medium flex items-center gap-1 mt-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>+18.4% em relação ao mês anterior</span>
                </div>
              </div>

              <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs">
                <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
                  <span>Reservas Confirmadas</span>
                  <Calendar className="w-4 h-4 text-[#2d3a29]" />
                </div>
                <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] tabular-nums mt-2">
                  {confirmedCount} estadias
                </div>
                <div className="text-xs text-[#57534e] mt-1">
                  Total acumulado no sistema
                </div>
              </div>

              <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs">
                <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
                  <span>Diária Média (ADR)</span>
                  <Home className="w-4 h-4 text-[#2d3a29]" />
                </div>
                <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] tabular-nums mt-2">
                  R$ {averageDailyRate.toLocaleString('pt-BR')}
                </div>
                <div className="text-xs text-[#57534e] mt-1">
                  Baseado em {chalets.length} chalés ativos
                </div>
              </div>

              <div className="bg-white border border-[#e5decb] rounded-2xl p-5 shadow-xs">
                <div className="flex items-center justify-between text-xs text-[#78716c] uppercase tracking-wider font-semibold">
                  <span>Taxa de Ocupação Média</span>
                  <TrendingUp className="w-4 h-4 text-[#2d3a29]" />
                </div>
                <div className="text-2xl sm:text-3xl font-bold font-mono text-[#1c1917] tabular-nums mt-2">
                  86.2%
                </div>
                <div className="text-xs text-emerald-700 font-medium mt-1">
                  Alta procura para inverno e feriados
                </div>
              </div>

            </div>

            {/* Seasonality Quick Insight Banner */}
            <div className="bg-gradient-to-r from-[#222c1f] to-[#2d3a29] text-white p-5 sm:p-6 rounded-3xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 border border-[#3c4d38]">
              <div className="space-y-1 max-w-2xl">
                <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
                  <BarChart3 className="w-4 h-4" />
                  <span>Análise de Sazonalidade (Gráficos Recharts)</span>
                </div>
                <h4 className="font-serif-luxury text-xl sm:text-2xl font-bold text-white">
                  Pico de Alta Temporada em Julho: 64 reservas estimadas (+120%)
                </h4>
                <p className="text-xs text-stone-300 leading-relaxed">
                  O inverno concentra 48% da receita bruta anual dos chalés de montanha. Acompanhe a projeção mês a mês com gráficos interativos de volume, faturamento e taxa de ocupação.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setActiveTab('seasonality')}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-[#1c1917] text-xs font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-2 shrink-0 cursor-pointer"
              >
                <span>Ver Gráficos Detalhados</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Overview Tables */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Recent Bookings */}
              <div className="lg:col-span-7 bg-white border border-[#e5decb] rounded-2xl p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
                    Últimas Reservas Recebidas
                  </h3>
                  <button
                    onClick={() => setActiveTab('reservations')}
                    className="text-xs text-[#2d3a29] font-semibold hover:underline flex items-center gap-1"
                  >
                    <span>Ver todas</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="divide-y divide-[#f2ede4] text-xs">
                  {reservations.slice(0, 5).map((res) => (
                    <div key={res.id} className="py-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <img
                          src={res.chaletImage}
                          alt={res.chaletName}
                          className="w-10 h-10 rounded-lg object-cover bg-[#222c1f]"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="font-semibold text-sm text-[#1c1917]">{res.guestName}</div>
                          <div className="text-[#78716c] text-[11px]">
                            {res.chaletName} · {res.checkIn} até {res.checkOut}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-bold font-mono text-[#1c1917]">
                          R$ {res.totalPrice.toLocaleString('pt-BR')}
                        </div>
                        <span className="text-[10px] uppercase font-semibold text-emerald-700">
                          {res.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chalet Occupancy & Highlights */}
              <div className="lg:col-span-5 bg-white border border-[#e5decb] rounded-2xl p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
                    Chalés Mais Desejados
                  </h3>
                  <button
                    onClick={() => setActiveTab('chalets')}
                    className="text-xs text-[#2d3a29] font-semibold hover:underline"
                  >
                    Gerenciar
                  </button>
                </div>

                <div className="space-y-3">
                  {chalets.slice(0, 4).map((c) => (
                    <div key={c.id} className="flex items-center justify-between p-3 rounded-xl bg-[#FAF9F5] border border-[#ede6d8]">
                      <div>
                        <div className="font-medium text-xs text-[#1c1917]">{c.name}</div>
                        <div className="text-[11px] text-[#78716c]">{c.city} · {c.region}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono text-xs font-semibold text-[#2d3a29]">
                          R$ {c.pricePerNight}/noite
                        </div>
                        <div className="flex items-center text-[10px] text-[#78716c]">
                          <Star className="w-3 h-3 fill-[#2d3a29] text-[#2d3a29] mr-0.5" />
                          <span>{c.rating} ({c.reviewCount})</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* VIEW: MONTHLY OCCUPANCY & HIGH SEASON (BAR CHART) */}
        {(activeTab === 'occupancy' || activeTab === 'seasonality') && (
          <MonthlyOccupancyPanel
            chalets={chalets}
            reservations={reservations}
          />
        )}

        {/* VIEW: REVIEWS & MODERATION (LOCK/UNLOCK REVIEWS BEFORE SHOWING ON SITE) */}
        {activeTab === 'reviews' && (
          <AdminReviewsManager
            reviews={reviewsList}
            chalets={chalets}
            onApproveReview={handleApproveReview}
            onBlockReview={handleBlockReview}
            onDeleteReview={handleDeleteReview}
            onAddReview={handleAddReview}
          />
        )}

        {/* VIEW 2: RESERVATIONS MANAGEMENT */}
        {activeTab === 'reservations' && (
          <div className="space-y-6">
            
            {/* Control Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-[#e5decb]">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-[#78716c] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar hóspede, código ou chalé..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <span className="text-xs text-[#78716c]">Filtrar por:</span>
                <select
                  value={reservationStatusFilter}
                  onChange={(e) => setReservationStatusFilter(e.target.value as any)}
                  className="text-xs bg-[#f4efe4] border border-[#d6cdbd] rounded-lg px-2.5 py-1.5 focus:outline-none cursor-pointer"
                >
                  <option value="all">Todos os Status</option>
                  <option value="confirmada">Confirmadas</option>
                  <option value="pendente">Pendentes</option>
                </select>
              </div>
            </div>

            {/* Reservations Table */}
            <div className="bg-white border border-[#e5decb] rounded-2xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#FAF9F5] border-b border-[#e5decb] text-[#78716c] uppercase tracking-wider text-[10px]">
                      <th className="py-3.5 px-4 font-semibold">Código</th>
                      <th className="py-3.5 px-4 font-semibold">Hóspede</th>
                      <th className="py-3.5 px-4 font-semibold">Chalé</th>
                      <th className="py-3.5 px-4 font-semibold">Período</th>
                      <th className="py-3.5 px-4 font-semibold text-right">Valor Total</th>
                      <th className="py-3.5 px-4 font-semibold">Pagamento</th>
                      <th className="py-3.5 px-4 font-semibold">Status</th>
                      <th className="py-3.5 px-4 font-semibold text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#f2ede4] text-[#44403c]">
                    {filteredReservations.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-12 text-center text-[#78716c]">
                          Nenhuma reserva encontrada com os filtros selecionados.
                        </td>
                      </tr>
                    ) : (
                      filteredReservations.map((res) => (
                        <tr key={res.id} className="hover:bg-[#FAF9F5] transition-colors">
                          <td className="py-3.5 px-4 font-mono font-bold text-[#1c1917]">
                            {res.id}
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-semibold text-[#1c1917]">{res.guestName}</div>
                            <div className="text-[11px] text-[#78716c]">{res.guestPhone}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-medium text-[#1c1917]">{res.chaletName}</div>
                            <div className="text-[11px] text-[#78716c]">{res.chaletCity}, {res.chaletState}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div>{res.checkIn} até {res.checkOut}</div>
                            <div className="text-[11px] text-[#78716c]">{res.nights} noites · {res.guests} hóspedes</div>
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-semibold text-[#1c1917] tabular-nums">
                            R$ {res.totalPrice.toLocaleString('pt-BR')}
                          </td>
                          <td className="py-3.5 px-4 uppercase font-semibold text-[10px] text-[#78716c]">
                            {res.paymentMethod}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded ${
                              res.status === 'confirmada' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {res.status === 'confirmada' && <CheckCircle className="w-3 h-3" />}
                              {res.status === 'pendente' && <Clock className="w-3 h-3" />}
                              {res.status}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right space-x-2">
                            <button
                              onClick={() => {
                                const newStatus = res.status === 'confirmada' ? 'pendente' : 'confirmada';
                                onUpdateReservationStatus(res.id, newStatus);
                              }}
                              className="text-xs text-[#2d3a29] hover:underline font-semibold"
                            >
                              {res.status === 'confirmada' ? 'Pendente' : 'Confirmar'}
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Deseja excluir a reserva ${res.id}?`)) {
                                  onDeleteReservation(res.id);
                                }
                              }}
                              className="text-xs text-red-600 hover:underline"
                            >
                              Excluir
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* VIEW 3: CHALETS MANAGEMENT */}
        {activeTab === 'chalets' && (
          <div className="space-y-6">
            
            {/* Action & Filter Bar */}
            <div className="bg-white p-5 rounded-2xl border border-[#e5decb] flex flex-col md:flex-row items-center justify-between gap-4 shadow-xs">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-serif-luxury text-xl font-bold text-[#1c1917]">
                    Gerenciamento de Chalés
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-[#f4efe4] text-[#2d3a29] text-xs font-mono font-bold">
                    {chalets.length} cadastrados
                  </span>
                </div>
                <p className="text-xs text-[#78716c] mt-0.5">
                  Insira novos chalés exclusivos, edite valores e comodidades ou exclua propriedades.
                </p>
              </div>

              <div className="flex items-center gap-3 w-full md:w-auto">
                <div className="relative flex-1 md:w-72">
                  <Search className="w-4 h-4 text-[#78716c] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar por nome, cidade ou estilo..."
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                  />
                </div>

                <button
                  onClick={handleOpenNewChaletModal}
                  className="flex items-center gap-2 bg-[#222c1f] hover:bg-[#2d3a29] text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-md transition-all shrink-0 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Inserir Novo Chalé</span>
                </button>
              </div>
            </div>

            {/* Chalets Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredChalets.map((chalet) => (
                <div
                  key={chalet.id}
                  className="bg-white border border-[#e5decb] rounded-2xl overflow-hidden shadow-xs hover:border-[#cfc6b4] transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-[16/9] w-full overflow-hidden bg-[#222c1f]">
                      <img
                        src={chalet.coverImage}
                        alt={chalet.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded text-white text-[10px] font-medium uppercase">
                        {chalet.style}
                      </div>
                      <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-2 py-0.5 rounded text-[#1c1917] text-xs font-bold font-mono tabular-nums">
                        R$ {chalet.pricePerNight}/noite
                      </div>
                    </div>

                    <div className="p-4 space-y-2">
                      <div className="text-[11px] text-[#78716c]">
                        {chalet.city}, {chalet.state} · {chalet.altitudeMeters}m
                      </div>
                      <h4 className="font-serif-luxury text-lg font-bold text-[#1c1917] leading-snug">
                        {chalet.name}
                      </h4>
                      <p className="text-xs text-[#57534e] line-clamp-2 leading-relaxed">
                        {chalet.tagline}
                      </p>

                      {/* Amenities Preview */}
                      {chalet.amenities && chalet.amenities.length > 0 && (
                        <div className="pt-2 border-t border-[#f2ede4] space-y-1">
                          <div className="text-[10px] font-bold uppercase tracking-wider text-[#78716c] flex items-center gap-1">
                            <Flame className="w-3 h-3 text-[#2d3a29]" />
                            <span>O que tem ({chalet.amenities.length}):</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {chalet.amenities.slice(0, 3).map((item, idx) => (
                              <span
                                key={idx}
                                className="text-[10px] px-2 py-0.5 rounded-md bg-[#ede6d8]/80 text-[#44403c] font-medium truncate max-w-[140px]"
                              >
                                {item}
                              </span>
                            ))}
                            {chalet.amenities.length > 3 && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-[#ded7c4] text-[#2d3a29] font-bold">
                                +{chalet.amenities.length - 3}
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions Bar with explicit buttons */}
                  <div className="p-3.5 bg-[#FAF9F5] border-t border-[#ede6d8] flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1 text-[#2d3a29] font-medium">
                      <Star className="w-3.5 h-3.5 fill-[#2d3a29]" />
                      <span>{chalet.rating.toFixed(2)} ({chalet.reviewCount})</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setEditingChalet({
                            ...chalet,
                            whatToBring: chalet.whatToBring && chalet.whatToBring.length > 0 
                              ? chalet.whatToBring 
                              : getDefaultWhatToBring(chalet),
                            regionalTips: chalet.regionalTips && chalet.regionalTips.length > 0
                              ? chalet.regionalTips
                              : getDefaultRegionalTips(chalet),
                          });
                          setIsChaletModalOpen(true);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#ede6d8] text-[#1c1917] font-semibold transition-colors border border-[#d6cdbd] shadow-xs cursor-pointer"
                        title="Editar Chalé"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-[#2d3a29]" />
                        <span>Editar</span>
                      </button>
                      <button
                        onClick={() => setDeletingChalet(chalet)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 font-semibold transition-colors border border-red-200 cursor-pointer"
                        title="Excluir Chalé"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Excluir</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredChalets.length === 0 && (
              <div className="text-center py-12 bg-white rounded-2xl border border-[#e5decb] space-y-3">
                <Home className="w-8 h-8 text-[#a8a29e] mx-auto" />
                <p className="text-sm font-semibold text-[#1c1917]">Nenhum chalé encontrado</p>
                <button
                  onClick={handleOpenNewChaletModal}
                  className="px-4 py-2 rounded-xl bg-[#222c1f] text-white text-xs font-semibold"
                >
                  Inserir Primeiro Chalé
                </button>
              </div>
            )}

          </div>
        )}

        {/* VIEW 4: COMPANY SETTINGS & ADDRESS */}
        {activeTab === 'company' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#e5decb] shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#f2ede4] mb-6">
                <div>
                  <div className="flex items-center gap-2 text-[#2d3a29] text-xs font-bold uppercase tracking-wider mb-1">
                    <Building2 className="w-4 h-4" />
                    <span>Identidade Institucional & Localização</span>
                  </div>
                  <h3 className="font-serif-luxury text-2xl font-bold text-[#1c1917]">
                    Dados da Empresa & Endereço
                  </h3>
                  <p className="text-xs text-[#78716c] mt-1">
                    Essas informações são refletidas no cabeçalho do site, no rodapé, no formulário de contato e nos canais de atendimento.
                  </p>
                </div>

                {isCompanySaved && (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 text-xs font-semibold animate-pulse">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Alterações Salvas com Sucesso!</span>
                  </div>
                )}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  onUpdateCompanySettings(companyForm);
                  setIsCompanySaved(true);
                  setTimeout(() => setIsCompanySaved(false), 3000);
                }}
                className="space-y-6 text-xs"
              >
                {/* Nome e Slogan */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1.5">
                      Nome da Empresa / Marca *
                    </label>
                    <input
                      type="text"
                      required
                      value={companyForm.name}
                      onChange={(e) => setCompanyForm({ ...companyForm, name: e.target.value })}
                      placeholder="Ex: Mantiqueira & Co."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1.5">
                      Slogan / Subtítulo Institucional
                    </label>
                    <input
                      type="text"
                      value={companyForm.tagline}
                      onChange={(e) => setCompanyForm({ ...companyForm, tagline: e.target.value })}
                      placeholder="Ex: Chalés Exclusivos do Brasil"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>
                </div>

                {/* CNPJ e Horário */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1.5">
                      CNPJ da Empresa
                    </label>
                    <input
                      type="text"
                      value={companyForm.cnpj || ''}
                      onChange={(e) => setCompanyForm({ ...companyForm, cnpj: e.target.value })}
                      placeholder="Ex: 38.452.910/0001-44"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm font-mono focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1.5">
                      Horário de Funcionamento / Atendimento
                    </label>
                    <input
                      type="text"
                      value={companyForm.openingHours || ''}
                      onChange={(e) => setCompanyForm({ ...companyForm, openingHours: e.target.value })}
                      placeholder="Ex: Segunda a Domingo, das 08h às 22h"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>
                </div>

                {/* Endereço */}
                <div className="space-y-4 pt-4 border-t border-[#f2ede4]">
                  <h4 className="font-semibold text-sm text-[#1c1917] flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-[#2d3a29]" />
                    <span>Endereço Completo da Sede / Base Operacional</span>
                  </h4>

                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1.5">
                      Logradouro / Rua / Estrada e Número *
                    </label>
                    <input
                      type="text"
                      required
                      value={companyForm.address}
                      onChange={(e) => setCompanyForm({ ...companyForm, address: e.target.value })}
                      placeholder="Ex: Estrada Real das Araucárias, Km 12"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block font-semibold text-[#44403c] mb-1.5">Cidade *</label>
                      <input
                        type="text"
                        required
                        value={companyForm.city}
                        onChange={(e) => setCompanyForm({ ...companyForm, city: e.target.value })}
                        placeholder="Gonçalves"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-[#44403c] mb-1.5">Estado (UF) *</label>
                      <input
                        type="text"
                        required
                        value={companyForm.state}
                        onChange={(e) => setCompanyForm({ ...companyForm, state: e.target.value })}
                        placeholder="MG"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-[#44403c] mb-1.5">CEP</label>
                      <input
                        type="text"
                        value={companyForm.zipCode}
                        onChange={(e) => setCompanyForm({ ...companyForm, zipCode: e.target.value })}
                        placeholder="37660-000"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm font-mono focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                    </div>
                  </div>
                </div>

                {/* Contatos */}
                <div className="space-y-4 pt-4 border-t border-[#f2ede4]">
                  <h4 className="font-semibold text-sm text-[#1c1917] flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-[#2d3a29]" />
                    <span>Canais de Atendimento</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold text-[#44403c] mb-1.5">
                        Telefone / WhatsApp Comercial *
                      </label>
                      <input
                        type="text"
                        required
                        value={companyForm.phone}
                        onChange={(e) => setCompanyForm({ ...companyForm, phone: e.target.value })}
                        placeholder="(11) 98765-4321"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm font-mono focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-[#44403c] mb-1.5">
                        E-mail de Contato & Concierge *
                      </label>
                      <input
                        type="email"
                        required
                        value={companyForm.email}
                        onChange={(e) => setCompanyForm({ ...companyForm, email: e.target.value })}
                        placeholder="concierge@mantiqueiraco.com.br"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                    </div>
                  </div>
                </div>

                {/* Submit button */}
                <div className="pt-6 border-t border-[#ede6d8] flex items-center justify-end gap-3">
                  <button
                    type="submit"
                    className="flex items-center gap-2 bg-[#222c1f] hover:bg-[#2d3a29] text-white px-6 py-3 rounded-xl font-semibold text-xs shadow-md transition-all cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Salvar Dados da Empresa</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* VIEW 5: HERO TEXTS & BADGES EDITOR */}
        {activeTab === 'hero' && (
          <AdminHeroEditor
            heroSettings={heroSettings}
            onUpdateHeroSettings={(newSettings) => {
              onUpdateHeroSettings?.(newSettings);
            }}
          />
        )}

      </main>

      {/* MODAL: NEW / EDIT CHALET */}
      {isChaletModalOpen && editingChalet && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-center p-4">
          <div className="bg-[#FAF9F5] text-[#1c1917] rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-[#ded7c4] flex flex-col max-h-[92vh]">
            
            <div className="px-6 py-4 border-b border-[#e5decb] flex items-center justify-between bg-white">
              <h3 className="font-serif-luxury text-2xl font-bold text-[#1c1917]">
                {editingChalet.id ? 'Editar Chalé' : 'Cadastrar Novo Chalé Exclusivo'}
              </h3>
              <button
                onClick={() => {
                  setIsChaletModalOpen(false);
                  setEditingChalet(null);
                }}
                className="p-1.5 rounded-full hover:bg-[#ede6d8] text-[#78716c]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveChalet} className="p-6 overflow-y-auto space-y-4 text-xs">
              
              <div className="space-y-3">
                <div>
                  <label className="block font-semibold text-[#44403c] mb-1">Nome do Chalé *</label>
                  <input
                    type="text"
                    required
                    value={editingChalet.name || ''}
                    onChange={(e) => setEditingChalet({ ...editingChalet, name: e.target.value })}
                    placeholder="Ex: Chalé Neblina Sublime"
                    className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] text-sm focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#44403c] mb-1">Frase de Destaque (Tagline)</label>
                  <input
                    type="text"
                    value={editingChalet.tagline || ''}
                    onChange={(e) => setEditingChalet({ ...editingChalet, tagline: e.target.value })}
                    placeholder="Ex: Arquitetura A-Frame com deck panorâmico sobre o vale"
                    className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1">Cidade *</label>
                    <input
                      type="text"
                      required
                      value={editingChalet.city || ''}
                      onChange={(e) => setEditingChalet({ ...editingChalet, city: e.target.value })}
                      placeholder="Gonçalves"
                      className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1">Estado *</label>
                    <select
                      value={editingChalet.state || 'MG'}
                      onChange={(e) => setEditingChalet({ ...editingChalet, state: e.target.value as any })}
                      className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] focus:outline-none bg-white cursor-pointer"
                    >
                      <option value="MG">Minas Gerais (MG)</option>
                      <option value="SP">São Paulo (SP)</option>
                      <option value="SC">Santa Catarina (SC)</option>
                      <option value="RS">Rio Grande do Sul (RS)</option>
                      <option value="RJ">Rio de Janeiro (RJ)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1">Estilo Arquitetônico</label>
                    <select
                      value={editingChalet.style || 'A-Frame'}
                      onChange={(e) => setEditingChalet({ ...editingChalet, style: e.target.value as any })}
                      className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] focus:outline-none bg-white cursor-pointer"
                    >
                      <option value="A-Frame">A-Frame Contemporâneo</option>
                      <option value="Cabana de Vidro">Cabana de Vidro</option>
                      <option value="Alpino Contemporâneo">Alpino Contemporâneo</option>
                      <option value="Eco-Lodge">Eco-Lodge Bioclimático</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1">Diária (R$) *</label>
                    <input
                      type="number"
                      required
                      value={editingChalet.pricePerNight || 1200}
                      onChange={(e) => setEditingChalet({ ...editingChalet, pricePerNight: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] font-mono focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1">Taxa de Limpeza (R$)</label>
                    <input
                      type="number"
                      value={editingChalet.cleaningFee || 180}
                      onChange={(e) => setEditingChalet({ ...editingChalet, cleaningFee: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] font-mono focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#44403c] mb-1">Máx. Hóspedes</label>
                    <input
                      type="number"
                      value={editingChalet.maxGuests || 2}
                      onChange={(e) => setEditingChalet({ ...editingChalet, maxGuests: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                    />
                  </div>
                </div>

                {/* Local Image Uploader: Foto de Capa do Computador */}
                <div className="bg-white p-4 rounded-xl border border-[#e5decb] space-y-3">
                  <LocalImageUploader
                    label="Foto Principal de Capa (Carregar do Computador) *"
                    helperText="Formato paisagem 16:9 de alta resolução"
                    currentValue={editingChalet.coverImage || ''}
                    onImageSelected={(dataUrl) =>
                      setEditingChalet({ ...editingChalet, coverImage: dataUrl })
                    }
                    aspectRatio="landscape"
                  />
                  
                  {/* Fallback URL input (collapsible or discreet) */}
                  <div className="pt-2 border-t border-[#f2ede4]">
                    <span className="text-[10px] text-[#78716c] block mb-1">Ou cole uma URL da imagem:</span>
                    <input
                      type="text"
                      value={editingChalet.coverImage || ''}
                      onChange={(e) => setEditingChalet({ ...editingChalet, coverImage: e.target.value })}
                      placeholder="/src/assets/images/... ou URL HTTPS"
                      className="w-full px-3 py-1.5 rounded-lg border border-[#e5decb] text-[11px] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                    />
                  </div>
                </div>

                {/* Local Gallery Uploader: Fotos Adicionais do Computador */}
                <div className="bg-white p-4 rounded-xl border border-[#e5decb]">
                  <LocalGalleryUploader
                    label="Galeria de Fotos do Chalé (Upload Local)"
                    images={editingChalet.images || []}
                    onChange={(newImages) =>
                      setEditingChalet({ ...editingChalet, images: newImages })
                    }
                  />
                </div>

                {/* Host Info & Host Avatar from Computer */}
                <div className="bg-white p-4 rounded-xl border border-[#e5decb] space-y-3">
                  <h4 className="font-semibold text-xs text-[#1c1917]">Dados do Anfitrião / Concierge</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-[#44403c] mb-1">Nome do Anfitrião</label>
                      <input
                        type="text"
                        value={editingChalet.host?.name || 'Anfitrião Mantiqueira'}
                        onChange={(e) =>
                          setEditingChalet({
                            ...editingChalet,
                            host: {
                              ...(editingChalet.host || {
                                avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
                                isSuperhost: true,
                                responseTime: 'Responde em até 1 hora',
                                role: 'Proprietário & Concierge',
                              }),
                              name: e.target.value,
                            },
                          })
                        }
                        placeholder="Nome do anfitrião"
                        className="w-full px-3 py-1.5 rounded-lg border border-[#d6cdbd] text-xs focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                      />
                    </div>

                    <div>
                      <LocalImageUploader
                        label="Foto do Anfitrião (Upload Local)"
                        currentValue={editingChalet.host?.avatar || ''}
                        onImageSelected={(dataUrl) =>
                          setEditingChalet({
                            ...editingChalet,
                            host: {
                              ...(editingChalet.host || {
                                name: 'Anfitrião Mantiqueira',
                                isSuperhost: true,
                                responseTime: 'Responde em até 1 hora',
                                role: 'Proprietário & Concierge',
                              }),
                              avatar: dataUrl,
                            },
                          })
                        }
                        aspectRatio="square"
                        maxWidth={400}
                        maxHeight={400}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#44403c] mb-1">Descrição Completa</label>
                  <textarea
                    rows={3}
                    value={editingChalet.description || ''}
                    onChange={(e) => setEditingChalet({ ...editingChalet, description: e.target.value })}
                    placeholder="Descreva a atmosfera poética, a vista para as montanhas e os detalhes de conforto."
                    className="w-full px-3.5 py-2 rounded-lg border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f]"
                  />
                </div>

                {/* O QUE TEM NO CHALÉ (Comodidades & Itens de Conforto) */}
                <div className="bg-white p-5 rounded-2xl border border-[#ded7c4] shadow-xs space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#f2ede4] pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <Flame className="w-4 h-4 text-[#2d3a29]" />
                        <h4 className="font-semibold text-sm text-[#1c1917]">
                          O que tem no chalé (Comodidades & Conforto)
                        </h4>
                      </div>
                      <p className="text-[11px] text-[#78716c] mt-0.5">
                        Insira, edite e apague comodidades do chalé (ex: ar-condicionado, lareira, banheira, jacuzzi, etc.)
                      </p>
                    </div>
                    <span className="text-xs font-mono font-semibold bg-[#FAF9F5] text-[#2d3a29] px-2.5 py-1 rounded-full border border-[#ded7c4] w-fit">
                      {(editingChalet.amenities || []).length} itens
                    </span>
                  </div>

                  {/* Campo para Inserir Novo Item */}
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-[#44403c]">
                      + Inserir novo item no chalé:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newAmenityInput}
                        onChange={(e) => setNewAmenityInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddAmenity(newAmenityInput);
                          }
                        }}
                        placeholder="Ex: Ar-condicionado Split Quente/Frio, Lareira a lenha tradicional..."
                        className="flex-1 px-3.5 py-2 rounded-xl border border-[#d6cdbd] text-xs focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                      <button
                        type="button"
                        onClick={() => handleAddAmenity(newAmenityInput)}
                        disabled={!newAmenityInput.trim()}
                        className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs ${
                          newAmenityInput.trim()
                            ? 'bg-[#222c1f] hover:bg-[#2d3a29] text-white cursor-pointer'
                            : 'bg-[#ded7c4] text-white cursor-not-allowed'
                        }`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Inserir</span>
                      </button>
                    </div>

                    {/* Sugestões Rápidas (Chips de 1 clique) */}
                    <div className="pt-1">
                      <span className="text-[10px] uppercase font-bold text-[#78716c] tracking-wider block mb-1.5">
                        Sugestões rápidas para adicionar:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          'Ar-condicionado Quente/Frio',
                          'Lareira tradicional a lenha',
                          'Lareira suspensa de design',
                          'Banheira de hidromassagem',
                          'Jacuzzi aquecida no deck',
                          'Wi-Fi Starlink de alta velocidade',
                          'Piso aquecido no banheiro',
                          'Toalheiro térmico',
                          'Cafeteira Nespresso com cápsulas',
                          'Cozinha gourmet equipada',
                          'Adega climatizada de vinhos',
                          'Cama King Size com lençóis 600 fios',
                          'Churrasqueira / Parrilla privativa',
                          'Vista panorâmica para as montanhas',
                          'Fogueira externa de chão (Fire Pit)',
                          'Permitido animais (Pet Friendly)',
                          'Sauna privativa',
                        ].map((suggestion) => {
                          const alreadyAdded = (editingChalet.amenities || []).includes(suggestion);
                          return (
                            <button
                              key={suggestion}
                              type="button"
                              onClick={() => handleAddAmenity(suggestion)}
                              disabled={alreadyAdded}
                              className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1 ${
                                alreadyAdded
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 opacity-60 cursor-default'
                                  : 'bg-[#FAF9F5] hover:bg-white text-[#44403c] border-[#d6cdbd] hover:border-[#222c1f] cursor-pointer'
                              }`}
                            >
                              <span>{alreadyAdded ? '✓' : '+'}</span>
                              <span>{suggestion}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Lista de Itens Cadastrados (com Inserir / Editar / Apagar) */}
                  <div className="pt-2">
                    <label className="block text-xs font-semibold text-[#44403c] mb-2">
                      Itens configurados no chalé (clique em Editar ou Apagar):
                    </label>

                    {(editingChalet.amenities || []).length === 0 ? (
                      <div className="p-4 rounded-xl bg-[#FAF9F5] border border-dashed border-[#d6cdbd] text-center text-xs text-[#78716c]">
                        Nenhum item configurado ainda. Digite acima ou clique em uma das sugestões rápidas para adicionar.
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {(editingChalet.amenities || []).map((amenity, idx) => {
                          const isEditing = editingAmenityIndex === idx;

                          if (isEditing) {
                            return (
                              <div
                                key={idx}
                                className="p-2 rounded-xl bg-amber-50 border border-amber-300 flex items-center gap-2"
                              >
                                <input
                                  type="text"
                                  value={editingAmenityValue}
                                  onChange={(e) => setEditingAmenityValue(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      handleSaveEditAmenity(idx);
                                    } else if (e.key === 'Escape') {
                                      setEditingAmenityIndex(null);
                                    }
                                  }}
                                  autoFocus
                                  className="flex-1 px-2.5 py-1 bg-white border border-amber-300 rounded-lg text-xs text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-amber-500"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleSaveEditAmenity(idx)}
                                  className="p-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white transition-colors cursor-pointer"
                                  title="Salvar alteração"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingAmenityIndex(null)}
                                  className="p-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 text-[#44403c] transition-colors cursor-pointer"
                                  title="Cancelar edição"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            );
                          }

                          return (
                            <div
                              key={idx}
                              className="p-2.5 rounded-xl bg-[#FAF9F5] border border-[#e5decb] hover:border-[#cfc6b4] flex items-center justify-between gap-2 group transition-all"
                            >
                              <div className="flex items-center gap-2 overflow-hidden">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#2d3a29] shrink-0" />
                                <span className="text-xs text-[#1c1917] font-medium truncate">
                                  {amenity}
                                </span>
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                {/* Botão Editar */}
                                <button
                                  type="button"
                                  onClick={() => handleStartEditAmenity(idx)}
                                  className="p-1 rounded-md text-[#78716c] hover:text-[#1c1917] hover:bg-white border border-transparent hover:border-[#d6cdbd] transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                                  title="Editar este item"
                                >
                                  <Edit2 className="w-3 h-3 text-[#2d3a29]" />
                                  <span className="hidden sm:inline">Editar</span>
                                </button>
                                {/* Botão Apagar */}
                                <button
                                  type="button"
                                  onClick={() => handleDeleteAmenity(idx)}
                                  className="p-1 rounded-md text-red-500 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                                  title="Apagar este item"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span className="hidden sm:inline">Apagar</span>
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>

                {/* O QUE LEVAR NA MALA (Checklist Personalizada por Chalé) */}
                <div className="bg-white p-5 rounded-2xl border border-[#ded7c4] shadow-xs space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#f2ede4] pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <Briefcase className="w-4 h-4 text-[#2d3a29]" />
                        <h4 className="font-semibold text-sm text-[#1c1917]">
                          O que levar na mala (Checklist do Hóspede)
                        </h4>
                      </div>
                      <p className="text-[11px] text-[#78716c] mt-0.5">
                        Orientações essenciais sobre vestuário, calçados e itens recomendados para este chalé e altitude.
                      </p>
                    </div>
                    <span className="text-xs font-mono font-semibold bg-[#FAF9F5] text-[#2d3a29] px-2.5 py-1 rounded-full border border-[#ded7c4] w-fit">
                      {(editingChalet.whatToBring || []).length} itens
                    </span>
                  </div>

                  {/* Campo para Inserir Novo Item de Mala */}
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-[#44403c]">
                      + Inserir novo item de mala:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newWhatToBringInput}
                        onChange={(e) => setNewWhatToBringInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddWhatToBring(newWhatToBringInput);
                          }
                        }}
                        placeholder="Ex: Agasalhos térmicos para noites frias de montanha, Roupas de banho para o ofurô..."
                        className="flex-1 px-3.5 py-2 rounded-xl border border-[#d6cdbd] text-xs focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                      <button
                        type="button"
                        onClick={() => handleAddWhatToBring(newWhatToBringInput)}
                        disabled={!newWhatToBringInput.trim()}
                        className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs ${
                          newWhatToBringInput.trim()
                            ? 'bg-[#222c1f] hover:bg-[#2d3a29] text-white cursor-pointer'
                            : 'bg-[#ded7c4] text-white cursor-not-allowed'
                        }`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Inserir</span>
                      </button>
                    </div>

                    {/* Sugestões Rápidas de O Que Levar */}
                    <div className="pt-1">
                      <span className="text-[10px] uppercase font-bold text-[#78716c] tracking-wider block mb-1.5">
                        Sugestões rápidas para adicionar:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          'Casacos pesados e agasalhos térmicos para a noite',
                          'Roupas de banho para desfrutar do ofurô e hidromassagem',
                          'Calçados fechados ou botas confortáveis para trilhas',
                          'Garrafa de vinho ou espumante especial para a lareira',
                          'Câmera fotográfica ou smartphone com bateria extra',
                          'Hidratante labial e corporal (ar de montanha é seco)',
                          'Óculos de sol e protetor solar para caminhadas',
                          'Livro favorito para momentos de leitura à beira da lareira',
                        ].map((suggestion) => {
                          const alreadyAdded = (editingChalet.whatToBring || []).includes(suggestion);
                          return (
                            <button
                              key={suggestion}
                              type="button"
                              onClick={() => handleAddWhatToBring(suggestion)}
                              disabled={alreadyAdded}
                              className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1 ${
                                alreadyAdded
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 opacity-60 cursor-default'
                                  : 'bg-[#FAF9F5] hover:bg-white text-[#44403c] border-[#d6cdbd] hover:border-[#222c1f] cursor-pointer'
                              }`}
                            >
                              <span>{alreadyAdded ? '✓' : '+'}</span>
                              <span>{suggestion}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Lista de Itens de Mala */}
                  <div className="pt-2">
                    <label className="block text-xs font-semibold text-[#44403c] mb-2">
                      Itens de mala configurados:
                    </label>

                    {(editingChalet.whatToBring || []).length === 0 ? (
                      <div className="p-4 rounded-xl bg-[#FAF9F5] border border-dashed border-[#d6cdbd] text-center text-xs text-[#78716c]">
                        Nenhum item configurado ainda. Digite acima ou use uma das sugestões rápidas.
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {(editingChalet.whatToBring || []).map((item, idx) => {
                          const isEditing = editingWhatToBringIndex === idx;

                          if (isEditing) {
                            return (
                              <div
                                key={idx}
                                className="p-2 rounded-xl bg-amber-50 border border-amber-300 flex items-center gap-2"
                              >
                                <input
                                  type="text"
                                  value={editingWhatToBringValue}
                                  onChange={(e) => setEditingWhatToBringValue(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      handleSaveEditWhatToBring(idx);
                                    } else if (e.key === 'Escape') {
                                      setEditingWhatToBringIndex(null);
                                    }
                                  }}
                                  autoFocus
                                  className="flex-1 px-2.5 py-1 bg-white border border-amber-300 rounded-lg text-xs text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-amber-500"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleSaveEditWhatToBring(idx)}
                                  className="p-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white transition-colors cursor-pointer"
                                  title="Salvar alteração"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingWhatToBringIndex(null)}
                                  className="p-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 text-[#44403c] transition-colors cursor-pointer"
                                  title="Cancelar edição"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            );
                          }

                          return (
                            <div
                              key={idx}
                              className="p-2.5 rounded-xl bg-[#FAF9F5] border border-[#e5decb] hover:border-[#cfc6b4] flex items-center justify-between gap-2 transition-all"
                            >
                              <div className="flex items-center gap-2 overflow-hidden">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#2d3a29] shrink-0" />
                                <span className="text-xs text-[#1c1917] font-medium">
                                  {item}
                                </span>
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleStartEditWhatToBring(idx)}
                                  className="p-1 rounded-md text-[#78716c] hover:text-[#1c1917] hover:bg-white border border-transparent hover:border-[#d6cdbd] transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                                  title="Editar este item"
                                >
                                  <Edit2 className="w-3 h-3 text-[#2d3a29]" />
                                  <span className="hidden sm:inline">Editar</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteWhatToBring(idx)}
                                  className="p-1 rounded-md text-red-500 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                                  title="Apagar este item"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span className="hidden sm:inline">Apagar</span>
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>

                {/* DICAS DA REGIÃO & SEGREDOS DO ANFITRIÃO */}
                <div className="bg-white p-5 rounded-2xl border border-[#ded7c4] shadow-xs space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#f2ede4] pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <Lightbulb className="w-4 h-4 text-amber-600" />
                        <h4 className="font-semibold text-sm text-[#1c1917]">
                          Dicas da região & segredos locais
                        </h4>
                      </div>
                      <p className="text-[11px] text-[#78716c] mt-0.5">
                        Dicas gastronômicas, estradas de acesso, queijarias, mirantes e segredos que só o anfitrião conhece.
                      </p>
                    </div>
                    <span className="text-xs font-mono font-semibold bg-[#FAF9F5] text-amber-900 px-2.5 py-1 rounded-full border border-amber-300 w-fit">
                      {(editingChalet.regionalTips || []).length} dicas
                    </span>
                  </div>

                  {/* Campo para Inserir Nova Dica Regional */}
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-[#44403c]">
                      + Inserir nova dica da região:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newRegionalTipInput}
                        onChange={(e) => setNewRegionalTipInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddRegionalTip(newRegionalTipInput);
                          }
                        }}
                        placeholder="Ex: Abasteça o carro antes de subir a serra; Visite a queijaria artesanal do Km 8..."
                        className="flex-1 px-3.5 py-2 rounded-xl border border-[#d6cdbd] text-xs focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
                      />
                      <button
                        type="button"
                        onClick={() => handleAddRegionalTip(newRegionalTipInput)}
                        disabled={!newRegionalTipInput.trim()}
                        className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs ${
                          newRegionalTipInput.trim()
                            ? 'bg-[#222c1f] hover:bg-[#2d3a29] text-white cursor-pointer'
                            : 'bg-[#ded7c4] text-white cursor-not-allowed'
                        }`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Inserir</span>
                      </button>
                    </div>

                    {/* Sugestões Rápidas de Dicas */}
                    <div className="pt-1">
                      <span className="text-[10px] uppercase font-bold text-[#78716c] tracking-wider block mb-1.5">
                        Sugestões rápidas para inspirar:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          'Abasteça o veículo no centro da cidade antes de subir para a montanha',
                          'Visite as queijarias artesanais locais pela manhã para provar queijos premiados',
                          'O pôr do sol acima das nuvens acontece entre 17h30 e 18h15',
                          'O sinal celular pode oscilar; utilize o Wi-Fi Starlink de alta velocidade do chalé',
                          'Para jantares nos bistrôs da vila, recomendamos reservar com antecedência',
                          'A estrada rural possui trechos de terra batida bem conservados',
                        ].map((suggestion) => {
                          const alreadyAdded = (editingChalet.regionalTips || []).includes(suggestion);
                          return (
                            <button
                              key={suggestion}
                              type="button"
                              onClick={() => handleAddRegionalTip(suggestion)}
                              disabled={alreadyAdded}
                              className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1 ${
                                alreadyAdded
                                  ? 'bg-amber-100 text-amber-900 border-amber-300 opacity-60 cursor-default'
                                  : 'bg-[#FAF9F5] hover:bg-white text-[#44403c] border-[#d6cdbd] hover:border-[#222c1f] cursor-pointer'
                              }`}
                            >
                              <span>{alreadyAdded ? '✓' : '+'}</span>
                              <span>{suggestion}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Lista de Dicas da Região */}
                  <div className="pt-2">
                    <label className="block text-xs font-semibold text-[#44403c] mb-2">
                      Dicas configuradas:
                    </label>

                    {(editingChalet.regionalTips || []).length === 0 ? (
                      <div className="p-4 rounded-xl bg-[#FAF9F5] border border-dashed border-[#d6cdbd] text-center text-xs text-[#78716c]">
                        Nenhuma dica configurada ainda. Digite acima ou use as sugestões rápidas.
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {(editingChalet.regionalTips || []).map((tip, idx) => {
                          const isEditing = editingRegionalTipIndex === idx;

                          if (isEditing) {
                            return (
                              <div
                                key={idx}
                                className="p-2 rounded-xl bg-amber-50 border border-amber-300 flex items-center gap-2"
                              >
                                <input
                                  type="text"
                                  value={editingRegionalTipValue}
                                  onChange={(e) => setEditingRegionalTipValue(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      handleSaveEditRegionalTip(idx);
                                    } else if (e.key === 'Escape') {
                                      setEditingRegionalTipIndex(null);
                                    }
                                  }}
                                  autoFocus
                                  className="flex-1 px-2.5 py-1 bg-white border border-amber-300 rounded-lg text-xs text-[#1c1917] focus:outline-none focus:ring-1 focus:ring-amber-500"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleSaveEditRegionalTip(idx)}
                                  className="p-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white transition-colors cursor-pointer"
                                  title="Salvar alteração"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingRegionalTipIndex(null)}
                                  className="p-1.5 rounded-lg bg-stone-200 hover:bg-stone-300 text-[#44403c] transition-colors cursor-pointer"
                                  title="Cancelar edição"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            );
                          }

                          return (
                            <div
                              key={idx}
                              className="p-2.5 rounded-xl bg-[#FAF9F5] border border-[#e5decb] hover:border-[#cfc6b4] flex items-center justify-between gap-2 transition-all"
                            >
                              <div className="flex items-start gap-2.5 overflow-hidden">
                                <span className="text-[10px] font-mono font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded mt-0.5 shrink-0">
                                  0{idx + 1}
                                </span>
                                <span className="text-xs text-[#1c1917] leading-relaxed">
                                  {tip}
                                </span>
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleStartEditRegionalTip(idx)}
                                  className="p-1 rounded-md text-[#78716c] hover:text-[#1c1917] hover:bg-white border border-transparent hover:border-[#d6cdbd] transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                                  title="Editar esta dica"
                                >
                                  <Edit2 className="w-3 h-3 text-[#2d3a29]" />
                                  <span className="hidden sm:inline">Editar</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteRegionalTip(idx)}
                                  className="p-1 rounded-md text-red-500 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-200 transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                                  title="Apagar esta dica"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span className="hidden sm:inline">Apagar</span>
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#e5decb] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsChaletModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-[#d6cdbd] text-[#57534e] hover:bg-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#222c1f] hover:bg-[#2d3a29] text-white font-semibold flex items-center gap-1.5 shadow-xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Salvar Chalé</span>
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* MODAL: CONFIRM DELETE CHALET */}
      {deletingChalet && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-center p-4">
          <div className="bg-[#FAF9F5] text-[#1c1917] rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-[#ded7c4] p-6 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto shadow-xs">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="font-serif-luxury text-xl font-bold text-[#1c1917]">
                Excluir Chalé?
              </h3>
              <p className="text-xs text-[#78716c] leading-relaxed">
                Tem certeza que deseja excluir o chalé <strong>"{deletingChalet.name}"</strong> localizado em <strong>{deletingChalet.city}, {deletingChalet.state}</strong>?
              </p>
              <p className="text-[11px] text-red-600 font-medium">
                Esta ação removerá o chalé definitivamente do catálogo e do site.
              </p>
            </div>

            <div className="pt-4 border-t border-[#ede6d8] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeletingChalet(null)}
                className="px-4 py-2 rounded-xl border border-[#d6cdbd] text-xs font-semibold text-[#57534e] hover:bg-white transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteChalet(deletingChalet.id);
                  setDeletingChalet(null);
                }}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Sim, Excluir Chalé</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
