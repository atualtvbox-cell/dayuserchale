import React, { useState } from 'react';
import { X, Send, Sparkles, Clock, ShieldCheck, ChevronRight } from 'lucide-react';
import { CompanySettings } from '../types';

interface FloatingWhatsAppButtonProps {
  companySettings: CompanySettings;
}

export const FloatingWhatsAppButton: React.FC<FloatingWhatsAppButtonProps> = ({
  companySettings,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [userCustomMessage, setUserCustomMessage] = useState('');

  // Clean phone number for WhatsApp link
  const rawPhone = companySettings.phone || '(11) 98765-4321';
  const cleanDigits = rawPhone.replace(/\D/g, '');
  const whatsappNumber = cleanDigits.startsWith('55') 
    ? cleanDigits 
    : cleanDigits.length >= 10 
      ? `55${cleanDigits}` 
      : '5511987654321';

  const quickQuestions = [
    {
      label: 'Consultar Disponibilidade',
      msg: 'Olá! Gostaria de consultar a disponibilidade dos chalés para as próximas semanas.',
    },
    {
      label: 'Dúvidas sobre Valores & Pix (-5%)',
      msg: 'Olá! Gostaria de entender mais sobre os valores das diárias e o desconto de 5% no Pix.',
    },
    {
      label: 'Experiências & Café da Manhã',
      msg: 'Olá! Gostaria de saber como funciona o café colonial artesanal e as experiências no chalé.',
    },
    {
      label: 'Chalés Pet Friendly',
      msg: 'Olá! Gostaria de saber quais chalés aceitam animais de estimação (Pet Friendly).',
    },
  ];

  const handleOpenWhatsApp = (messageText: string) => {
    const encoded = encodeURIComponent(messageText.trim() || 'Olá! Gostaria de mais informações sobre os chalés.');
    const url = `https://wa.me/${whatsappNumber}?text=${encoded}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    setIsOpen(false);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userCustomMessage.trim()) return;
    handleOpenWhatsApp(userCustomMessage);
    setUserCustomMessage('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      
      {/* Floating Popup Card (when opened) */}
      {isOpen && (
        <div className="mb-4 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-[#ded7c4] overflow-hidden animate-fadeIn flex flex-col text-left">
          
          {/* Header */}
          <div className="bg-[#222c1f] p-4 text-white relative">
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="absolute top-3.5 right-3.5 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title="Fechar"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-11 h-11 rounded-full bg-[#3c4d38] border-2 border-white/30 flex items-center justify-center text-white font-serif-luxury font-bold text-lg shadow-inner">
                  M
                </div>
                <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#222c1f]" />
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="font-serif-luxury text-base font-bold text-white">
                    {companySettings.name || 'Mantiqueira & Co.'}
                  </h4>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-stone-300">
                  <Clock className="w-3 h-3 text-emerald-400" />
                  <span>Atendimento das 08h às 22h</span>
                </div>
              </div>
            </div>
          </div>

          {/* Body Content */}
          <div className="p-4 space-y-3.5 max-h-[380px] overflow-y-auto bg-[#FAF9F5]">
            
            {/* Concierge Intro Message Bubble */}
            <div className="bg-white p-3.5 rounded-2xl border border-[#e5decb] shadow-xs text-xs text-[#44403c] space-y-1.5 leading-relaxed">
              <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-[#78716c]">
                <Sparkles className="w-3 h-3 text-[#2d3a29]" />
                <span>Atendimento Personalizado</span>
              </div>
              <p>
                Olá! Seja muito bem-vindo. Como podemos ajudar a planejar a sua estadia perfeita nos chalés de montanha?
              </p>
              <div className="text-[10px] text-[#a8a29e] text-right font-mono">
                WhatsApp Oficial: {rawPhone}
              </div>
            </div>

            {/* Quick Suggestions */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#78716c] block">
                Dúvidas frequentes (clique para enviar):
              </span>
              <div className="space-y-1.5">
                {quickQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleOpenWhatsApp(q.msg)}
                    className="w-full text-left p-2.5 rounded-xl bg-white hover:bg-[#ede6d8] border border-[#e5decb] text-xs text-[#222c1f] font-medium transition-all flex items-center justify-between group shadow-xs cursor-pointer"
                  >
                    <span className="truncate pr-2">{q.label}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-[#78716c] group-hover:translate-x-0.5 transition-transform shrink-0" />
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Footer Input for Custom Question */}
          <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-[#e5decb] flex items-center gap-2">
            <input
              type="text"
              value={userCustomMessage}
              onChange={(e) => setUserCustomMessage(e.target.value)}
              placeholder="Digite sua mensagem para o WhatsApp..."
              className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-[#d6cdbd] focus:outline-none focus:ring-1 focus:ring-[#222c1f] bg-[#FAF9F5]"
            />
            <button
              type="submit"
              disabled={!userCustomMessage.trim()}
              className={`p-2.5 rounded-xl text-white transition-all shadow-xs shrink-0 cursor-pointer ${
                userCustomMessage.trim()
                  ? 'bg-[#25D366] hover:bg-[#20ba59]'
                  : 'bg-stone-300 cursor-not-allowed'
              }`}
              title="Enviar mensagem via WhatsApp"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>
      )}

      {/* Main Floating Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="relative group flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white shadow-xl hover:shadow-2xl transition-all duration-300 active:scale-95 cursor-pointer border border-white/20"
        aria-label="Abrir WhatsApp para informações"
      >
        {/* Pulsing ring animation */}
        <span className="absolute -inset-1 rounded-full bg-[#25D366]/40 animate-ping pointer-events-none opacity-75" />

        {/* WhatsApp Icon (SVG for authenticity) */}
        <div className="relative">
          <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
          </svg>
        </div>

        <span className="font-semibold text-xs tracking-wide">
          WhatsApp Concierge
        </span>

        {/* Small live badge */}
        <span className="w-2 h-2 rounded-full bg-white shadow-xs" />
      </button>

    </div>
  );
};
