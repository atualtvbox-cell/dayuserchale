import React from 'react';
import { MapPin, ArrowUpRight } from 'lucide-react';
import { DESTINATIONS_HIGHLIGHTS } from '../data/chalets';

interface DestinationsGridProps {
  onSelectDestination: (city: string) => void;
}

export const DestinationsGrid: React.FC<DestinationsGridProps> = ({ onSelectDestination }) => {
  return (
    <section id="destinos" className="py-20 bg-[#f4f0e7] border-t border-[#e9e3d5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="flex items-center gap-3 text-xs tracking-widest uppercase text-[#78716c] mb-2">
              <span className="w-6 h-[1px] bg-[#c7baa4]" />
              <span>Serras Brasileiras</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-[#1c1917] leading-tight">
              Os refúgios mais cobiçados por região.
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#78716c] max-w-md mt-4 md:mt-0 leading-relaxed font-light">
            De invernos rigorosos com geada no Sul aos mares de morros e pores do sol da Mantiqueira, descubra o seu próximo santuário de descanso.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {DESTINATIONS_HIGHLIGHTS.map((dest) => (
            <div
              key={dest.name}
              onClick={() => onSelectDestination(dest.name.split(' · ')[0])}
              className="group cursor-pointer bg-white rounded-2xl overflow-hidden border border-[#e5decb] hover:border-[#222c1f] transition-all hover:shadow-md flex flex-col justify-between"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-[#222c1f]">
                <img
                  src={dest.image}
                  alt={dest.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-3.5 left-3.5 right-3.5 flex items-baseline justify-between text-white">
                  <div>
                    <span className="text-[11px] text-white/80 uppercase tracking-wider">{dest.region}</span>
                    <h3 className="font-serif-luxury text-xl font-semibold">{dest.name}</h3>
                  </div>
                  <span className="text-xs font-mono tabular-nums bg-white/20 backdrop-blur-md px-2 py-0.5 rounded">
                    {dest.altitude}
                  </span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <p className="text-xs text-[#57534e] line-clamp-2 leading-relaxed">
                  {dest.description}
                </p>
                <div className="mt-3 pt-3 border-t border-[#ede6d8] flex items-center justify-between text-xs text-[#222c1f] font-semibold">
                  <span>{dest.chaletCount} chalés curados</span>
                  <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
