import React, { useState } from 'react';
import { Bookmark, Star, Users, MapPin, Sparkles, ChevronRight, ChevronLeft, Calendar, Share2, Check, Clock, Camera } from 'lucide-react';
import { Chalet, Reservation } from '../types';

interface ChaletCardProps {
  chalet: Chalet;
  isFavorite: boolean;
  reservations?: Reservation[];
  animationDelay?: number;
  onToggleFavorite: (chaletId: string) => void;
  onSelectChalet: (chalet: Chalet) => void;
  onOpenGallery?: (chalet: Chalet, initialIndex?: number) => void;
  onShare?: (chalet: Chalet) => void;
}

export const ChaletCard: React.FC<ChaletCardProps> = ({
  chalet,
  isFavorite,
  reservations = [],
  animationDelay = 0,
  onToggleFavorite,
  onSelectChalet,
  onOpenGallery,
  onShare,
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageError, setImageError] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  // Find upcoming active reservations for this chalet (confirmed or pending within 60 minutes)
  const now = Date.now();
  const activeBookings = reservations.filter((r) => {
    if (r.chaletId !== chalet.id) return false;
    if (r.status === 'confirmada') return true;
    if (r.status === 'pendente') {
      return !r.expiresAt || r.expiresAt > now;
    }
    return false;
  });
  const nextBooking = activeBookings[0];

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const shareUrl = `${window.location.origin}/#chale-${chalet.id}`;
    const shareData = {
      title: `${chalet.name} · ${chalet.city}`,
      text: `Conheça este chalé exclusivo na serra brasileira: ${chalet.name} (${chalet.city}, ${chalet.state}).`,
      url: shareUrl,
    };

    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
        if (onShare) onShare(chalet);
        return;
      } catch (err) {
        // User cancelled or share dismissed
      }
    }

    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2500);
      if (onShare) onShare(chalet);
    } catch {
      // Fallback
    }
  };

  const handlePhotoClick = () => {
    if (onOpenGallery) {
      onOpenGallery(chalet, currentImageIndex);
    } else {
      onSelectChalet(chalet);
    }
  };

  return (
    <article 
      className="group bg-[#FAF9F5] border border-[#e8e2d5] hover:border-[#cfc6b4] rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-lg flex flex-col h-full animate-fade-in-up"
      style={{ animationDelay: `${animationDelay}ms` }}
    >
      {/* Visual Asset Container (Click opens photo gallery) */}
      <div 
        onClick={handlePhotoClick}
        className="relative aspect-[4/3] w-full overflow-hidden bg-[#e9e3d5] cursor-pointer"
        title="Clique para abrir a galeria de fotos deste chalé"
      >
        {!imageError ? (
          <img
            src={chalet.images[currentImageIndex] || chalet.coverImage}
            alt={chalet.name}
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-[#2d3a29] text-[#FAF9F5] p-6 text-center">
            <Sparkles className="w-8 h-8 text-[#d6cdbd] mb-2 opacity-80" />
            <span className="font-serif-luxury text-xl">{chalet.name}</span>
            <span className="text-xs text-[#d6cdbd]/70 mt-1">{chalet.city} · {chalet.state}</span>
          </div>
        )}

        {/* Gallery Badge on Hover */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none z-10">
          <div className="bg-black/75 backdrop-blur-md text-white text-xs font-semibold px-3.5 py-1.5 rounded-full flex items-center gap-2 shadow-xl border border-white/20 transform scale-95 group-hover:scale-100 transition-transform">
            <Camera className="w-3.5 h-3.5 text-amber-300" />
            <span>Abrir Galeria ({chalet.images.length} fotos)</span>
          </div>
        </div>

        {/* Action Buttons: Favorite and Share */}
        <div className="absolute top-3.5 right-3.5 flex items-center gap-1.5 z-20">
          {/* Share Action Button */}
          <button
            type="button"
            onClick={handleShare}
            className={`p-2 rounded-full backdrop-blur-md transition-all ${
              copiedShare
                ? 'bg-emerald-700 text-white shadow-md'
                : 'bg-white/80 text-[#292524] hover:bg-white hover:text-black shadow-sm'
            }`}
            title={copiedShare ? 'Link copiado!' : 'Compartilhar este chalé'}
            aria-label="Compartilhar este chalé"
          >
            {copiedShare ? (
              <Check className="w-4 h-4 text-white" />
            ) : (
              <Share2 className="w-4 h-4" />
            )}
          </button>

          {/* Favorite Action Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(chalet.id);
            }}
            className={`p-2 rounded-full backdrop-blur-md transition-all ${
              isFavorite
                ? 'bg-[#222c1f] text-white shadow-md'
                : 'bg-white/80 text-[#292524] hover:bg-white hover:text-black shadow-sm'
            }`}
            aria-label={isFavorite ? 'Remover dos favoritos' : 'Salvar nos favoritos'}
            title={isFavorite ? 'Remover dos favoritos' : 'Salvar nos favoritos'}
          >
            <Bookmark className={`w-4 h-4 ${isFavorite ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* Tarja de Reservado / Ocupado / Datas Livres */}
        {nextBooking ? (
          <div className="absolute top-3.5 left-3.5 z-20">
            {nextBooking.status === 'confirmada' ? (
              <div className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 bg-red-700/90 text-white backdrop-blur-md rounded shadow-sm flex items-center gap-1.5 border border-red-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-red-300 animate-pulse" />
                <span>Reservado ({nextBooking.checkIn.split('-').reverse().slice(0, 2).join('/')} a {nextBooking.checkOut.split('-').reverse().slice(0, 2).join('/')})</span>
              </div>
            ) : (
              <div className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 bg-amber-600/95 text-white backdrop-blur-md rounded shadow-sm flex items-center gap-1.5 border border-amber-400/40">
                <Clock className="w-3 h-3 text-amber-200 animate-pulse" />
                <span>Reservado · Aguardando Pagto ({Math.max(1, Math.ceil(((nextBooking.expiresAt || (now + 3600000)) - now) / 60000))}m)</span>
              </div>
            )}
          </div>
        ) : (
          <div className="absolute top-3.5 left-3.5 z-20">
            <div className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 bg-[#222c1f]/85 text-[#e6ded1] backdrop-blur-md rounded shadow-sm flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>Datas Livres</span>
            </div>
          </div>
        )}

        {/* Feedback Badge when Copied */}
        {copiedShare && (
          <div className="absolute bottom-3 inset-x-0 mx-auto w-fit z-20 animate-fade-in-up">
            <div className="bg-emerald-800 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-lg flex items-center gap-1.5 border border-white/20">
              <Check className="w-3.5 h-3.5 text-emerald-300" />
              <span>Link copiado para a área de transferência!</span>
            </div>
          </div>
        )}

        {/* Next / Previous arrows on hover */}
        {chalet.images.length > 1 && (
          <>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setCurrentImageIndex((prev) => (prev === 0 ? chalet.images.length - 1 : prev - 1));
              }}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/40 text-white hover:bg-black/70 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity z-20"
              aria-label="Foto anterior"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setCurrentImageIndex((prev) => (prev === chalet.images.length - 1 ? 0 : prev + 1));
              }}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/40 text-white hover:bg-black/70 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity z-20"
              aria-label="Próxima foto"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </>
        )}

        {/* Multi-image indicators for all 5+ photos */}
        {chalet.images.length > 1 && (
          <div className="absolute bottom-3 left-0 right-0 flex justify-center items-center gap-1.5 z-20 opacity-0 group-hover:opacity-100 transition-opacity">
            {chalet.images.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setCurrentImageIndex(idx);
                }}
                className={`h-1.5 rounded-full transition-all ${
                  currentImageIndex === idx ? 'w-5 bg-white shadow-sm' : 'w-1.5 bg-white/60 hover:bg-white'
                }`}
                aria-label={`Ver foto ${idx + 1}`}
              />
            ))}
          </div>
        )}

        {/* Subtle style label */}
        <div className="absolute bottom-3.5 left-3.5 z-20">
          <span className="text-[10px] font-medium tracking-wide uppercase px-2 py-0.5 bg-black/60 text-white backdrop-blur-md rounded">
            {chalet.style}
          </span>
        </div>
      </div>

      {/* Card Content & Metadata */}
      <div className="p-5 flex flex-col flex-1 justify-between">
        <div>
          {/* Location & Altitude - Clean unboxed text with typographic separators */}
          <div className="flex items-center gap-2 text-xs text-[#78716c] mb-1.5">
            <span className="font-medium text-[#44403c]">{chalet.city}, {chalet.state}</span>
            <span aria-hidden="true">·</span>
            <span>{chalet.region}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{chalet.altitudeMeters}m de altitude</span>
          </div>

          {/* Chalet Title */}
          <h3
            onClick={() => onSelectChalet(chalet)}
            className="font-serif-luxury text-2xl font-semibold text-[#1c1917] group-hover:text-[#2d3a29] transition-colors cursor-pointer leading-snug mb-2 line-clamp-1"
          >
            {chalet.name}
          </h3>

          {/* Tagline */}
          <p className="text-xs text-[#57534e] line-clamp-2 leading-relaxed mb-4">
            {chalet.tagline}
          </p>

          {/* Capacity and key feature */}
          <div className="flex items-center gap-3 text-xs text-[#78716c] pb-4 mb-4 border-b border-[#ece6d9]">
            <span className="flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-[#57534e]" />
              Até {chalet.maxGuests} hóspedes
            </span>
            <span aria-hidden="true">·</span>
            <span>{chalet.bedrooms} {chalet.bedrooms === 1 ? 'suíte' : 'suítes'}</span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{chalet.amenities[0]}</span>
          </div>
        </div>

        {/* Price & Primary Action */}
        <div className="flex items-center justify-between pt-1">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-xs text-[#78716c] font-normal">A partir de</span>
              <span className="font-semibold text-xl text-[#1c1917] tabular-nums font-mono">
                R$ {chalet.pricePerNight.toLocaleString('pt-BR')}
              </span>
              <span className="text-xs text-[#78716c]">/ noite</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#78716c] mt-0.5">
              <div className="flex items-center text-[#2d3a29] font-medium">
                <Star className="w-3.5 h-3.5 fill-[#2d3a29] text-[#2d3a29] mr-0.5" />
                <span className="tabular-nums">{chalet.rating.toFixed(2)}</span>
              </div>
              <span>({chalet.reviewCount} avaliações)</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onSelectChalet(chalet)}
            className="px-4 py-2.5 rounded-lg text-xs font-semibold tracking-wide bg-[#222c1f] hover:bg-[#2e3b2a] text-white transition-all flex items-center gap-1 shadow-sm whitespace-nowrap active:scale-95"
          >
            <span>Ver Grade & Reservar</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </article>
  );
};
