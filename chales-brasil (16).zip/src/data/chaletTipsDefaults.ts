import { Chalet } from '../types';

export const getDefaultWhatToBring = (chalet?: Partial<Chalet>): string[] => {
  const altitude = chalet?.altitudeMeters || 1400;
  const isColdPeak = altitude >= 1500;
  const cityName = chalet?.city || 'Serra';

  return [
    isColdPeak
      ? `Agasalhos pesados, gorro e luvas térmicas (a ${altitude}m de altitude as noites chegam a 2°C a 8°C)`
      : `Casaco aconchegante para as noites frescas de montanha (${altitude}m de altitude)`,
    'Roupas de banho para aproveitar o ofurô aquecido e a banheira de imersão panorâmica',
    'Calçados fechados ou botas confortáveis para caminhadas nas trilhas de mata nativa',
    'Vinho ou espumante de sua preferência para harmonizar com a lareira (o chalé possui taças e abridor)',
    'Itens pessoais de higiene e hidratante corporal (o ar de montanha é puro e seco)',
    'Câmera fotográfica ou smartphone com bateria carregada para registrar o mar de nuvens e o pôr do sol',
  ];
};

export const getDefaultRegionalTips = (chalet?: Partial<Chalet>): string[] => {
  const city = chalet?.city || 'região';
  const state = chalet?.state || 'MG';

  const citySpecificTips: Record<string, string[]> = {
    'Gonçalves': [
      'Visite a Queijaria do Trevo no Km 8 para degustar queijos artesanais de massa crua premiados internacionalmente.',
      'O pôr do sol na Pedra de São Domingos (a 2.050m) é um dos espetáculos mais grandiosos da Mantiqueira.',
      'Abasteça o veículo no centro de Gonçalves antes de subir os acessos de serra; os últimos 3 km são de estrada cênica.',
      'Prove os pães artesanais de fermentação natural e cafés especiais nas padarias artesanais da vila.',
      'O sinal de operadora móvel é irregular na montanha; configure chamadas via Wi-Fi Starlink antes de chegar.',
    ],
    'Urubici': [
      'A subida ao Morro da Igreja e Pedra Furada exige agendamento prévio com o ICMBio (recomendamos agendar 1 semana antes).',
      'Nas noites de inverno com previsão de geada ou sincelo, saia cedo para fotografar a vegetação congelada nos campos.',
      'Conheça a Cascata do Avencal e os cafés coloniais tradicionais da Serra Catarinense.',
      'Experimente a truta fresca grelhada com pinhão nos bistrôs rurais da cidade.',
      'Dirija com cautela nas curvas da serra em dias de neblina espessa; use faróis de neblina.',
    ],
    'Campos do Jordão': [
      'Para evitar o trânsito do Capivari nos fins de semana, faça os passeios gastronômicos e mirantes pela manhã.',
      'Visite o Museu Felícia Leirner e o Auditório Claudio Santoro ao entardecer para unir arte e pôr do sol.',
      'Aproveite a rota das cervejarias artesanais e das fábricas de chocolate belga artesanal.',
      'O acesso ao chalé pelo Alto da Boa Vista possui trecho sinuoso e totalmente asfaltado.',
      'Recomendamos reservar restaurantes conceituados com antecedência nas noites de sexta e sábado.',
    ],
    'São Bento do Sapucaí': [
      'A trilha da Pedra do Baú (Bauzinho) é de fácil acesso e oferece uma vista de 360 graus inesquecível de toda a serra.',
      'Faça uma visita guiada aos olivais locais com degustação de azeites extravirgens premiados da Mantiqueira.',
      'Experimente as cervejarias locais e o clássico fondue serrano na praça central da cidade.',
      'O chalé conta com vista frontal para a face norte das pedras; o nascer da lua por trás do maciço é mágico.',
      'Traga agasalho corta-vento caso pretenda subir ao cume das montanhas.',
    ],
    'Gramado': [
      'Aproveite o chalé para descansar após os passeios nas vinícolas boutique do Vale dos Vinhedos e Linha Bella.',
      'Os melhores cafés coloniais e fábricas de chocolate artesanal ficam na rota romântica entre Gramado e Canela.',
      'Não deixe de visitar os mirantes do Vale do Quilombo nas primeiras horas da manhã com névoa.',
      'Recomendamos comprar ingressos para atrações e espetáculos com antecedência na alta temporada de inverno.',
      'A estrada de acesso ao chalé é privativa e arborizada com hortênsias e plátanos centenários.',
    ],
    'Monte Verde': [
      'A trilha do Pico do Selado e Pedra Redonda são imperdíveis para ver a divisa de SP e MG do alto da cordilheira.',
      'Na avenida principal, deguste strudels de maçã alemães quentinhos acompanhados de chocolate quente cremoso.',
      'As noites em Monte Verde são tipicamente as mais frias do sul de Minas; aproveite a lareira e a banheira aquecida.',
      'Abasteça seu carro antes da serra em Camanducaia; o trânsito é tranquilo e o ar é puro.',
    ],
    'Visconde de Mauá': [
      'Conheça as cachoeiras do Alcantilado e o Poço das Antas com águas cristalinas de nascente.',
      'A vila de Maringá (lado Minas e lado Rio) concentra bistrôs estrelados especializados em trutas e pinhão.',
      'Veículos altos ou com tração são bem-vindos para as trilhas de cachoeira mais isoladas.',
      'Desconecte-se: o som das águas e o estalar da lareira são a melhor trilha sonora da região.',
    ],
  };

  if (citySpecificTips[city]) {
    return citySpecificTips[city];
  }

  return [
    `Abasteça o veículo no centro de ${city} (${state}) antes de subir para o refúgio na montanha.`,
    'A região é famosa pelos produtores locais de queijos artesanais, mel silvestre e doces caseiros da serra.',
    'O melhor horário para apreciar a vista sem neblina costuma ser entre as 9h e as 14h, ou no pôr do sol.',
    'As estradas de montanha exigem direção atenta e tranquila; aproveite a paisagem ao redor.',
    'O chalé possui internet Wi-Fi de alta velocidade, mas o sinal de operadoras convencionais pode ser reduzido na mata.',
    'Recomendamos planejar as compras de alimentos e bebidas com antecedência para desfrutar plenamente do chalé.',
  ];
};
