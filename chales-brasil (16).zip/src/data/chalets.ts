import { Chalet } from '../types';

export const CHALETS: Chalet[] = [
  {
    id: 'chale-mirante-araucarias',
    name: 'Chalé Mirante das Araucárias',
    tagline: 'Arquitetura A-Frame envidraçada suspensa nas nuvens da Mantiqueira',
    region: 'Serra da Mantiqueira',
    state: 'MG',
    city: 'Gonçalves',
    altitudeMeters: 1650,
    coordinates: { lat: -22.6586, lng: -45.8561 },
    pricePerNight: 1280,
    cleaningFee: 180,
    rating: 4.98,
    reviewCount: 142,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    style: 'A-Frame',
    coverImage: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1506974210756-8e1b8985d348?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: true,
    architecturalNote: 'Estrutura A-Frame em madeira maciça de peroba de demolição com empena de vidro duplo insulado e isolamento térmico nórdico.',
    description: 'Imerso em um bosque particular de araucárias centenárias a mais de 1.600 metros de altitude, o Mirante das Araucárias é o refúgio definitivo para casais. Com pé-direito de 7 metros e uma fachada inteiramente envidraçada voltada para o mar de morros mineiro, oferece uma atmosfera de isolamento poético com o mais alto padrão de conforto hoteleiro.',
    amenities: [
      'Ofurô externo aquecido a lenha no deck suspenso',
      'Lareira suspensa a lenha com tiragem perfeita',
      'Cesta de café da manhã colonial com queijos artesanais de Gonçalves',
      'Cama King Size com lençóis de algodão egípcio 600 fios',
      'Chuveiro duplo com teto solar panorâmico',
      'Piso aquecido no banheiro e toalheiro térmico',
      'Adega privativa com seleção de vinhos de altitude',
      'Internet via satélite Starlink 220 Mbps',
      'Cozinha gourmet equipada com cafeteira espresso e moedor de grãos',
      'Fogueira externa de chão (Fire Pit) com lenha inclusa'
    ],
    experiences: [
      {
        id: 'exp-1',
        title: 'Fondue Suíço com Vinho da Mantiqueira',
        description: 'Jantar completo servido no chalé com queijos artesanais fundidos, pães de fermentação lenta e garrafa de Syrah local.',
        price: 340,
        duration: 'Ao anoitecer',
        iconName: 'Flame'
      },
      {
        id: 'exp-2',
        title: 'Massagem Relaxante a Dois no Deck',
        description: '90 minutos de terapia corporal com óleos essenciais de lavanda colhidos na região serrana.',
        price: 520,
        duration: '1h30',
        iconName: 'Sparkles'
      },
      {
        id: 'exp-3',
        title: 'Observação Astronômica Guiada com Telescópio',
        description: 'Sessão noturna conduzida com mapa celeste do céu límpido das serras de altitude.',
        price: 210,
        duration: '1h',
        iconName: 'Moon'
      }
    ],
    host: {
      name: 'Helena & Bernardo',
      role: 'Superhosts Mantiqueira · Arquitetos e Anfitriões',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em menos de 15 minutos',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-1',
        author: 'Mariana Drummond',
        location: 'São Paulo, SP',
        date: 'Outubro de 2026',
        rating: 5,
        comment: 'Experiência indescritível. Acordar com a neblina descendo suavemente sobre as araucárias enquanto a lareira ainda estalava foi um dos momentos mais marcantes da nossa vida a dois. O café em cesta é uma obra de arte.',
        stayType: 'Lua de mel (3 noites)'
      },
      {
        id: 'rev-2',
        author: 'Rodrigo Vasconcellos',
        location: 'Belo Horizonte, MG',
        date: 'Setembro de 2026',
        rating: 5,
        comment: 'Impecável em cada detalhe. Da qualidade dos lençóis ao aquecimento do chão do banheiro. A privacidade é absoluta. Voltaremos todo inverno.',
        stayType: 'Viagem a dois (4 noites)'
      }
    ]
  },
  {
    id: 'cabana-glass-mist-urubici',
    name: 'Cabana Glass & Mist',
    tagline: 'Vidro panorâmico de 360° no topo dos cânions mais frios do país',
    region: 'Serra Catarinense',
    state: 'SC',
    city: 'Urubici',
    altitudeMeters: 1720,
    coordinates: { lat: -28.0150, lng: -49.5925 },
    pricePerNight: 1450,
    cleaningFee: 200,
    rating: 4.99,
    reviewCount: 98,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    style: 'Cabana de Vidro',
    coverImage: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: true,
    architecturalNote: 'Projeto minimalista em balanço estrutural sobre a escarpa rochosa, com fechamento em vidros alemães de controle solar e tripla camada.',
    description: 'Projetada para que o horizonte da Serra do Rio do Rastro seja a sua única parede. A Cabana Glass & Mist eleva o conceito de cabana de vidro a um patamar escandinavo, com banheira de imersão de pedra vulcânica e lareira central giratória.',
    amenities: [
      'Banheira de imersão esculpida em pedra vulcânica',
      'Lareira central Focus giratória a lenha',
      'Jacuzzi aquecida no deck com borda infinita para o cânion',
      'Cesta de café colonial serrano com pinhão cozido e geleias orgânicas',
      'Calefação central em todos os ambientes',
      'Cama Super King com edredom de pluma de ganso alpina',
      'Sauna seca privativa com visor panorâmico',
      'Sistema de som Hi-Fi integrado Bang & Olufsen',
      'Taças de cristal e adega de espumantes de altitude catarinenses'
    ],
    experiences: [
      {
        id: 'exp-g1',
        title: 'Degustação Guiada de Vinhos de Altitude SC',
        description: 'Seleção de 4 rótulos premiados de São Joaquim com sommelier que visita o chalé.',
        price: 420,
        duration: '2h',
        iconName: 'Wine'
      },
      {
        id: 'exp-g2',
        title: 'Cesta Gourmet de Fogueira & Pinhão Assado',
        description: 'Kit completo para noite de luar no deck: marshmallow artesanal, pinhão da serra e chocolate quente suíço.',
        price: 190,
        duration: 'Noite',
        iconName: 'Flame'
      }
    ],
    host: {
      name: 'Gabriel Becker',
      role: 'Superhost Serra Catarinense',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em menos de 10 minutos',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-3',
        author: 'Camila & Fernando Peixoto',
        location: 'Curitiba, PR',
        date: 'Julho de 2026',
        rating: 5,
        comment: 'Pegamos 2°C com geada pela manhã. Ver o gelo derretendo no vidro enquanto tomávamos café na cama aquecida é algo que não se esquece. Nível de hotelaria 6 estrelas.',
        stayType: 'Aniversário de casamento (3 noites)'
      }
    ]
  },
  {
    id: 'refugio-pedra-do-bau',
    name: 'Refúgio Pedra do Baú',
    tagline: 'Vista frontal para o monólito mais imponente do estado de São Paulo',
    region: 'Serra da Mantiqueira',
    state: 'SP',
    city: 'São Bento do Sapucaí',
    altitudeMeters: 1580,
    coordinates: { lat: -22.6883, lng: -45.7339 },
    pricePerNight: 1190,
    cleaningFee: 170,
    rating: 4.97,
    reviewCount: 164,
    maxGuests: 4,
    bedrooms: 2,
    bathrooms: 2,
    style: 'Alpino Contemporâneo',
    coverImage: 'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1506974210756-8e1b8985d348?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: true,
    architecturalNote: 'Assinatura modernista em concreto aparente, aço corten e pedras colhidas no próprio terreno, integrando a construção à montanha.',
    description: 'Localizado no ponto mais nobre de São Bento do Sapucaí, o Refúgio Pedra do Baú tem orientação solar pensada para que o pôr do sol doure diretamente a sala de estar e os quartos. Deck estendido com hidromassagem e ducha natural de nascente.',
    amenities: [
      'Piscina de pedra aquecida com hidromassagem',
      'Lareira dupla face com visão para o quarto e living',
      'Varanda com vista desimpedida para a Pedra do Baú',
      'Churrasqueira gourmet estilo parrilla uruguaia',
      'Café da manhã entregue em cesta às 8h30',
      'Permitido animais de estimação (Pet Friendly)',
      'Wi-Fi ultrarrápido ideal para trabalho criativo',
      'Trilha privada para mirante da propriedade'
    ],
    experiences: [
      {
        id: 'exp-b1',
        title: 'Trilha Guiada ao Pôr do Sol na Pedra do Baú',
        description: 'Ascensão segura com guia credenciado pelos caminhos ecológicos da serra.',
        price: 280,
        duration: '3h30',
        iconName: 'Compass'
      },
      {
        id: 'exp-b2',
        title: 'Cesta de Piquenique nas Alturas',
        description: 'Pães artesanais, queijo da Mantiqueira premiado, frutas da época e vinho frisante.',
        price: 230,
        duration: 'Tarde livre',
        iconName: 'ShoppingBag'
      }
    ],
    host: {
      name: 'Patrícia Alvarenga',
      role: 'Superhost Mantiqueira · Paisagista',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em 20 minutos',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-4',
        author: 'Lucas Prado',
        location: 'Campinas, SP',
        date: 'Agosto de 2026',
        rating: 5,
        comment: 'A vista da Pedra do Baú da hidromassagem é um espetáculo cinematográfico. Nossa cadela Border Collie foi tratada como rainha com caminha e mimos.',
        stayType: 'Final de semana em família'
      }
    ]
  },
  {
    id: 'chateau-das-hortensias-gramado',
    name: 'Château das Hortênsias',
    tagline: 'Elegância alpina e charme europeu entre os vales de Gramado e Canela',
    region: 'Serra Gaúcha',
    state: 'RS',
    city: 'Gramado',
    altitudeMeters: 850,
    coordinates: { lat: -29.3746, lng: -50.8764 },
    pricePerNight: 1390,
    cleaningFee: 220,
    rating: 4.96,
    reviewCount: 188,
    maxGuests: 4,
    bedrooms: 2,
    bathrooms: 2,
    style: 'Alpino Contemporâneo',
    coverImage: 'https://images.unsplash.com/photo-1587061949409-02df41d5e562?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1587061949409-02df41d5e562?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1506974210756-8e1b8985d348?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: false,
    architecturalNote: 'Inspiração nos refúgios dos Alpes Suíços com telhados inclinados em ardósia nobre e esquadrias de pinho nobre restaurado.',
    description: 'Localizado no silencioso Vale dos Pinheiros, a apenas 10 minutos do centro gastronômico de Gramado. O Château combina a sofisticação da tradição do vinho gaúcho com lareira tradicional a lenha, mezanino de leitura e jardim privativo de hortênsias.',
    amenities: [
      'Banheira vitoriana de imersão com sais aromáticos',
      'Lareira tradicional de tijolos refratários',
      'Café colonial completo servido com cucas e geleias da serra',
      'Adega subterrânea particular',
      'Bicicletas elétricas de cortesia para passeios pelos vales',
      'Churrasqueira estilo parrilla fechada com exaustor',
      'Ar-condicionado quente/frio tipo inverter em todos os cômodos'
    ],
    experiences: [
      {
        id: 'exp-c1',
        title: 'Tour Exclusivo pelas Vinícolas Boutique',
        description: 'Motorista privativo e degustação sensorial com enólogos em vinhedos históricos.',
        price: 580,
        duration: '4h',
        iconName: 'Wine'
      }
    ],
    host: {
      name: 'Eduardo & Christine Weber',
      role: 'Superhosts Serra Gaúcha',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em menos de 1 hora',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-5',
        author: 'Juliana Medeiros',
        location: 'Rio de Janeiro, RJ',
        date: 'Julho de 2026',
        rating: 5,
        comment: 'Gramado com a paz do campo. O café colonial servido no chalé supera os melhores hotéis da cidade. As hortênsias dão um charme de conto de fadas.',
        stayType: 'Férias de inverno (5 noites)'
      }
    ]
  },
  {
    id: 'eco-lodge-neblina-dourada-monte-verde',
    name: 'Eco-Lodge Neblina Dourada',
    tagline: 'Refúgio bioclimático sustentável na floresta nativa de Monte Verde',
    region: 'Serra da Mantiqueira',
    state: 'MG',
    city: 'Monte Verde',
    altitudeMeters: 1680,
    coordinates: { lat: -22.8631, lng: -46.0378 },
    pricePerNight: 1120,
    cleaningFee: 160,
    rating: 4.95,
    reviewCount: 112,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    style: 'Eco-Lodge',
    coverImage: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1596178065887-1198b6148b2b?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1506974210756-8e1b8985d348?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: false,
    architecturalNote: 'Construção carbono neutro com captação solar térmica, tratamento de efluentes por fitorremediação e madeiras certificadas FSC.',
    description: 'Um verdadeiro santuário da natureza onde esquilos e tucanos são seus vizinhos cotidianos. Com pé na mata e vista para o pôr do sol na Pedra Redonda, este chalé une sustentabilidade rigorosa ao conforto térmico com calefação ecológica.',
    amenities: [
      'Deck panorâmico com rede suspensa e vista para o vale',
      'Lareira ecológica e lareira a lenha tradicional',
      'Banheira dupla de hidromassagem com cromoterapia',
      'Café da manhã orgânico da horta local',
      'Chás colhidos na propriedade e biscoitos artesanais',
      'Trilha privada para a cachoeira do terreno',
      'Pet friendly com jardim cercado'
    ],
    experiences: [
      {
        id: 'exp-e1',
        title: 'Workshop de Cerveja Artesanal das Montanhas',
        description: 'Visita à microcervejaria artesanal do vale com harmonização de queijos mineiros.',
        price: 260,
        duration: '2h',
        iconName: 'Beer'
      }
    ],
    host: {
      name: 'Marcelo Pires',
      role: 'Superhost Mantiqueira · Biólogo & Guia',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em 30 minutos',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-6',
        author: 'Beatriz Fonseca',
        location: 'Santos, SP',
        date: 'Setembro de 2026',
        rating: 5,
        comment: 'A rede suspensa no deck vendo o pôr do sol em Monte Verde foi um divisor de águas. O chalé cheira a madeira limpa e lavanda.',
        stayType: 'Retiro individual (3 noites)'
      }
    ]
  },
  {
    id: 'santuario-da-serra-maua',
    name: 'Santuário da Serra Mauá',
    tagline: 'Imersão no berço das águas cristalinas e cachoeiras de Visconde de Mauá',
    region: 'Serra dos Órgãos / Mantiqueira',
    state: 'RJ',
    city: 'Visconde de Mauá',
    altitudeMeters: 1300,
    coordinates: { lat: -22.3308, lng: -44.5422 },
    pricePerNight: 1050,
    cleaningFee: 150,
    rating: 4.97,
    reviewCount: 130,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    style: 'A-Frame',
    coverImage: 'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: false,
    architecturalNote: 'Cabana em madeira de eucalipto tratado e pedras de rio da região de Maringá e Maromba, com iluminação cênica noturna.',
    description: 'Ao lado do som suave das corredeiras do Rio Preto, na fronteira entre RJ e MG. Este chalé proporciona desconexão com sofisticação: banho de floresta, banheira de imersão de frente para a mata atlântica preservada e gastronomia local sofisticada.',
    amenities: [
      'Banheira de hidromassagem com vista para a mata nativa',
      'Sauna a vapor úmida envidraçada integrada ao deck',
      'Lareira a lenha com poltronas de leitura',
      'Acesso direto à piscina natural do rio privativo',
      'Café da manhã entregue em cesta de vime com trutas defumadas locais',
      'Adega de vinhos naturais e orgânicos'
    ],
    experiences: [
      {
        id: 'exp-s1',
        title: 'Truta Fresca & Pinhão: Experiência Gastronômica no Chalé',
        description: 'Chef local prepara jantar privativo de 3 tempos harmonizado na varanda do chalé.',
        price: 490,
        duration: 'Noite',
        iconName: 'Utensils'
      }
    ],
    host: {
      name: 'Clara & Thiago',
      role: 'Superhosts Visconde de Mauá',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em menos de 20 minutos',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-7',
        author: 'Daniela Amorim',
        location: 'Niterói, RJ',
        date: 'Agosto de 2026',
        rating: 5,
        comment: 'O barulho do rio à noite junto com a lareira acesa traz uma paz que não dá para explicar em palavras. Cuidado excepcional dos anfitriões.',
        stayType: 'Fim de semana romântico'
      }
    ]
  },
  {
    id: 'vila-dos-pinhais-campos-jordao',
    name: 'Vila dos Pinhais A-Frame',
    tagline: 'O ápice do requinte na montanha mais alta e famosa do Brasil',
    region: 'Serra da Mantiqueira',
    state: 'SP',
    city: 'Campos do Jordão',
    altitudeMeters: 1750,
    coordinates: { lat: -22.7394, lng: -45.5914 },
    pricePerNight: 1580,
    cleaningFee: 240,
    rating: 4.99,
    reviewCount: 215,
    maxGuests: 4,
    bedrooms: 2,
    bathrooms: 2,
    style: 'A-Frame',
    coverImage: 'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1506974210756-8e1b8985d348?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: true,
    architecturalNote: 'A-Frame contemporâneo de 120m² em pé de serra com lareira suspensa Gyrofocus e vidros duplos térmicos com controle acústico total.',
    description: 'Localizado no nobre bairro do Alto do Capivari, isolado em reserva florestal privada de araucárias. O Vila dos Pinhais oferece serviço de mordomo opcional, enxoval Trousseau, piso térmico e uma adega climatizada selecionada por sommeliers paulistas.',
    amenities: [
      'Jacuzzi aquecida no deck para 4 pessoas com cromoterapia',
      'Lareira central Focus importada',
      'Piso aquecido em todos os cômodos e calefação central',
      'Enxoval de cama Trousseau 800 fios',
      'Café da manhã colonial com pães de fermentação natural de Campos',
      'Máquina Nespresso com cápsulas de blends especiais de cortesia',
      'Adega de vinhos climatizada privativa'
    ],
    experiences: [
      {
        id: 'exp-v1',
        title: 'Jantar Romântico com Chef Privado',
        description: 'Menu degustação 4 passos preparado na cozinha do chalé com harmonização de vinhos de inverno.',
        price: 650,
        duration: '3h',
        iconName: 'Utensils'
      }
    ],
    host: {
      name: 'Roberta Siqueira',
      role: 'Superhost Campos do Jordão · Concierge de Luxo',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em 5 minutos',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-8',
        author: 'Guilherme Brandão',
        location: 'São Paulo, SP',
        date: 'Setembro de 2026',
        rating: 5,
        comment: 'Experiência impecável. Melhor até que os hotéis de luxo tradicionais de Campos do Jordão porque a privacidade e a vista para a serra são exclusivas.',
        stayType: 'Comemoração especial (2 noites)'
      }
    ]
  },
  {
    id: 'chale-vista-canion-aparados',
    name: 'Chalé Vista do Cânion',
    tagline: 'Entre as fendas milenares e a névoa dos Aparados da Serra',
    region: 'Serra Catarinense / RS',
    state: 'SC',
    city: 'Praia Grande (Cânions)',
    altitudeMeters: 1100,
    coordinates: { lat: -29.1978, lng: -50.1103 },
    pricePerNight: 1240,
    cleaningFee: 190,
    rating: 4.96,
    reviewCount: 89,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    style: 'Cabana de Vidro',
    coverImage: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1200&q=85',
    images: [
      'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1506974210756-8e1b8985d348?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=85',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=85',
    ],
    featured: false,
    architecturalNote: 'Cabana suspensa sobre pilotis metálicos em balanço frontal ao cânion Itaimbezinho.',
    description: 'Construída na borda superior dos cânions que dividem Santa Catarina e Rio Grande do Sul. Este refúgio coloca você em primeira fila para o espetáculo dos balões de ar quente subindo ao amanhecer sobre os abismos de pedra.',
    amenities: [
      'Banheira de hidromassagem suspensa com vista direta para o cânion',
      'Deck em madeira teca com fogueira ecológica',
      'Café da manhã entregue em cesta às 6h para contemplar os balões',
      'Lareira nórdica a lenha',
      'Binóculos náuticos para observação de aves de rapina e cânions'
    ],
    experiences: [
      {
        id: 'exp-b3',
        title: 'Voo Privado de Balão de Ar Quente ao Nascer do Sol',
        description: 'Voo inesquecível de 50 minutos sobrevoando os paredões dos cânions com brinde de espumante.',
        price: 1350,
        duration: 'Ao amanhecer',
        iconName: 'Compass'
      }
    ],
    host: {
      name: 'Leonardo Schramm',
      role: 'Superhost Cânions do Sul · Piloto e Montanhista',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=250&q=80',
      responseTime: 'Responde em 15 minutos',
      isSuperhost: true
    },
    reviews: [
      {
        id: 'rev-9',
        author: 'Lorena Silveira',
        location: 'Porto Alegre, RS',
        date: 'Agosto de 2026',
        rating: 5,
        comment: 'Ver os balões subindo ao amanhecer de dentro da jacuzzi quentinha foi o ponto alto do ano. Recomendo de olhos fechados.',
        stayType: 'Lua de mel (3 noites)'
      }
    ]
  }
];

export const REGIONS = [
  'Todas as Regiões',
  'Serra da Mantiqueira (SP/MG/RJ)',
  'Serra Catarinense (SC)',
  'Serra Gaúcha (RS)',
  'Aparados da Serra (SC/RS)'
];

export const DESTINATIONS_HIGHLIGHTS = [
  {
    name: 'Gonçalves · MG',
    region: 'Serra da Mantiqueira',
    description: 'O recanto das araucárias, gastronomia da roça e chalés nas alturas.',
    altitude: '1.650m',
    image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80',
    chaletCount: 14
  },
  {
    name: 'Urubici · SC',
    region: 'Serra Catarinense',
    description: 'O ponto mais gelado do país, cachoeiras congeladas e cabanas de vidro.',
    altitude: '1.720m',
    image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=800&q=80',
    chaletCount: 9
  },
  {
    name: 'São Bento do Sapucaí · SP',
    region: 'Serra da Mantiqueira',
    description: 'Aos pés da majestosa Pedra do Baú com vinhedos e refúgios modernos.',
    altitude: '1.580m',
    image: 'https://images.unsplash.com/photo-1449158743715-0a90ebb6d2d8?auto=format&fit=crop&w=800&q=80',
    chaletCount: 11
  },
  {
    name: 'Gramado & Canela · RS',
    region: 'Serra Gaúcha',
    description: 'Hospitalidade alpina, tradição vinícola e chalés com banheiras de imersão.',
    altitude: '850m',
    image: 'https://images.unsplash.com/photo-1587061949409-02df41d5e562?auto=format&fit=crop&w=800&q=80',
    chaletCount: 18
  }
];
