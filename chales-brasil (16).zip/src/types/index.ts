export interface Host {
  name: string;
  role: string;
  avatar: string;
  responseTime: string;
  isSuperhost: boolean;
}

export interface Experience {
  id: string;
  title: string;
  description: string;
  price: number;
  duration: string;
  iconName: string;
}

export interface Review {
  id: string;
  author: string;
  location: string;
  date: string;
  rating: number;
  comment: string;
  stayType: string;
  chaletName?: string;
  chaletId?: string;
  avatar?: string;
  status?: 'aprovada' | 'pendente' | 'rejeitada'; // 'aprovada' = desbloqueada no site
  isApproved?: boolean; // true = desbloqueada no site, false = bloqueada
  createdAt?: string;
}

export interface Chalet {
  id: string;
  name: string;
  tagline: string;
  region: string;
  state: 'SP' | 'MG' | 'SC' | 'RS' | 'RJ';
  city: string;
  altitudeMeters: number;
  coordinates: {
    lat: number;
    lng: number;
  };
  pricePerNight: number;
  cleaningFee: number;
  rating: number;
  reviewCount: number;
  maxGuests: number;
  bedrooms: number;
  bathrooms: number;
  style: 'A-Frame' | 'Cabana de Vidro' | 'Alpino Contemporâneo' | 'Eco-Lodge';
  images: string[];
  coverImage: string;
  description: string;
  architecturalNote: string;
  amenities: string[];
  experiences: Experience[];
  host: Host;
  reviews: Review[];
  featured?: boolean;
  whatToBring?: string[];
  regionalTips?: string[];
}

export interface Reservation {
  id: string;
  chaletId: string;
  chaletName: string;
  chaletCity: string;
  chaletState: string;
  chaletImage: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  guests: number;
  selectedExperiences: string[];
  totalPrice: number;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  specialRequests?: string;
  paymentMethod: 'pix' | 'cartao';
  status: 'confirmada' | 'pendente' | 'expirada' | 'cancelada';
  expiresAt?: number; // timestamp in ms (1 hour limit if pending)
  createdAt: string;
}

export interface ToastNotification {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
  duration?: number;
}

export interface CompanySettings {
  name: string;
  tagline: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  email: string;
  cnpj?: string;
  openingHours?: string;
}

export const DEFAULT_COMPANY_SETTINGS: CompanySettings = {
  name: 'Mantiqueira & Co.',
  tagline: 'Chalés Exclusivos do Brasil',
  address: 'Estrada Real das Araucárias, Km 12',
  city: 'Gonçalves',
  state: 'MG',
  zipCode: '37660-000',
  phone: '(11) 98765-4321',
  email: 'concierge@mantiqueiraco.com.br',
  cnpj: '38.452.910/0001-44',
  openingHours: 'Segunda a Domingo, das 08h às 22h',
};

export interface HeroBadge {
  id: string;
  title: string;
  subtitle: string;
}

export interface HeroSettings {
  kicker: string;
  title: string;
  description: string;
  badges: HeroBadge[];
}

export const DEFAULT_HERO_SETTINGS: HeroSettings = {
  kicker: 'Curadoria de Hospedagem Poética no Brasil',
  title: 'Onde o silêncio da serra encontra a arquitetura do refúgio.',
  description: 'Seleção rigorosa dos chalés A-frame, cabanas de vidro e retiros de montanha mais extraordinários da Mantiqueira, Serra Gaúcha e Serra Catarinense.',
  badges: [
    { id: '1', title: '100% Privativos', subtitle: 'Sem áreas comuns ou vizinhos próximos' },
    { id: '2', title: 'Cesta na Porta', subtitle: 'Café colonial artesanal todas as manhãs' },
    { id: '3', title: 'Lareira & Lenha', subtitle: 'Lenha de reflorestamento inclusa' },
    { id: '4', title: 'Concierge 24h', subtitle: 'Suporte direto via WhatsApp para tudo' },
  ],
};

export interface SearchFilters {
  destination: string;
  style: string;
  minPrice: number;
  maxPrice: number;
  guests: number;
  hasJacuzzi: boolean;
  hasFireplace: boolean;
  petFriendly: boolean;
  hasBreakfast: boolean;
  hasView: boolean;
  checkInDate?: string;
  checkOutDate?: string;
}
