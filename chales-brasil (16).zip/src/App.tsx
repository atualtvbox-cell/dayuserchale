import React, { useState, useEffect, useMemo } from 'react';
import { 
  SlidersHorizontal, Check, Star, Sparkles, Filter, Compass 
} from 'lucide-react';
import { CHALETS } from './data/chalets';
import { INITIAL_REVIEWS } from './data/reviews';
import { 
  Chalet, Reservation, SearchFilters, CompanySettings, DEFAULT_COMPANY_SETTINGS, 
  Review, ToastNotification, HeroSettings, DEFAULT_HERO_SETTINGS 
} from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ChaletCard } from './components/ChaletCard';
import { ChaletDetailModal } from './components/ChaletDetailModal';
import { CuratedExperiencesSection } from './components/CuratedExperiencesSection';
import { DestinationsGrid } from './components/DestinationsGrid';
import { FavoritesDrawer } from './components/FavoritesDrawer';
import { ReservationsModal } from './components/ReservationsModal';
import { ConciergeModal } from './components/ConciergeModal';
import { AdminDashboard } from './components/AdminDashboard';
import { ChaletMapView } from './components/ChaletMapView';
import { ChaletGalleryModal } from './components/ChaletGalleryModal';
import { ToastContainer } from './components/ToastContainer';
import { ReviewsSection } from './components/ReviewsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsAppButton } from './components/FloatingWhatsAppButton';

const INITIAL_FILTERS: SearchFilters = {
  destination: 'Todos',
  style: 'Todos',
  minPrice: 0,
  maxPrice: 3000,
  guests: 2,
  hasJacuzzi: false,
  hasFireplace: false,
  petFriendly: false,
  hasBreakfast: false,
  hasView: false,
};

export default function App() {
  // Chalets list state (persisted in localStorage to retain admin edits)
  const [chaletsList, setChaletsList] = useState<Chalet[]>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_chalets_v4');
      if (saved) return JSON.parse(saved);
    } catch {}
    return CHALETS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('mantiqueira_chalets_v4', JSON.stringify(chaletsList));
    } catch (e) {
      console.error(e);
    }
  }, [chaletsList]);

  // Company settings state (persisted in localStorage)
  const [companySettings, setCompanySettings] = useState<CompanySettings>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_company');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_COMPANY_SETTINGS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('mantiqueira_company', JSON.stringify(companySettings));
    } catch (e) {
      console.error(e);
    }
  }, [companySettings]);

  const handleUpdateCompanySettings = (updated: CompanySettings) => {
    setCompanySettings(updated);
    addToast({
      type: 'success',
      title: 'Dados da Empresa Atualizados!',
      message: 'Nome e endereço institucional foram salvos com sucesso.',
    });
  };

  // Hero settings state (persisted in localStorage)
  const [heroSettings, setHeroSettings] = useState<HeroSettings>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_hero_settings');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_HERO_SETTINGS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('mantiqueira_hero_settings', JSON.stringify(heroSettings));
    } catch (e) {
      console.error(e);
    }
  }, [heroSettings]);

  const handleUpdateHeroSettings = (updated: HeroSettings) => {
    setHeroSettings(updated);
    addToast({
      type: 'success',
      title: 'Textos da Capa Atualizados!',
      message: 'Os textos da imagem hero foram salvos e já estão visíveis no site.',
    });
  };

  // Reviews state (persisted in localStorage)
  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_reviews_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_REVIEWS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('mantiqueira_reviews_v2', JSON.stringify(reviews));
    } catch (e) {
      console.error(e);
    }
  }, [reviews]);

  const handleApproveReview = (reviewId: string) => {
    setReviews((prev) =>
      prev.map((r) =>
        r.id === reviewId ? { ...r, status: 'aprovada' as const, isApproved: true } : r
      )
    );
    addToast({
      type: 'success',
      title: 'Avaliação Desbloqueada!',
      message: 'A avaliação agora está visível publicamente no site para todos os visitantes.',
    });
  };

  const handleBlockReview = (reviewId: string) => {
    setReviews((prev) =>
      prev.map((r) =>
        r.id === reviewId ? { ...r, status: 'pendente' as const, isApproved: false } : r
      )
    );
    addToast({
      type: 'info',
      title: 'Avaliação Bloqueada',
      message: 'A avaliação foi ocultada do site e retornou para moderação.',
    });
  };

  const handleDeleteReview = (reviewId: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== reviewId));
    addToast({
      type: 'info',
      title: 'Avaliação Excluída',
      message: 'A avaliação foi removida com sucesso.',
    });
  };

  const handleAddReview = (newReview: Review) => {
    setReviews((prev) => [newReview, ...prev]);
  };

  // Admin view toggle
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Filters state
  const [filters, setFilters] = useState<SearchFilters>(INITIAL_FILTERS);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [activeRegionTab, setActiveRegionTab] = useState<string>('Todas');
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');

  // Favorites state (persisted in localStorage)
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_favorites');
      return saved ? JSON.parse(saved) : ['chale-mirante-araucarias'];
    } catch {
      return ['chale-mirante-araucarias'];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('mantiqueira_favorites', JSON.stringify(favoriteIds));
    } catch (e) {
      console.error(e);
    }
  }, [favoriteIds]);

  // Reservations state (persisted in localStorage with demo reservations)
  const [reservations, setReservations] = useState<Reservation[]>(() => {
    try {
      const saved = localStorage.getItem('mantiqueira_reservations');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'REF-782941',
        chaletId: 'chale-mirante-araucarias',
        chaletName: 'Chalé Mirante das Araucárias',
        chaletCity: 'Gonçalves',
        chaletState: 'MG',
        chaletImage: '/src/assets/images/hero_brazilian_luxury_chalet_1790997520247.jpg',
        checkIn: '2026-10-18',
        checkOut: '2026-10-21',
        nights: 3,
        guests: 2,
        selectedExperiences: ['exp-1'],
        totalPrice: 4360,
        guestName: 'Carlos Eduardo Mendes',
        guestEmail: 'carlos.mendes@exemplo.com.br',
        guestPhone: '(11) 99123-4567',
        specialRequests: 'Lua de mel; gostaríamos de acendimento da lareira antes da chegada.',
        paymentMethod: 'pix',
        status: 'confirmada',
        createdAt: '02/10/2026',
      },
      {
        id: 'REF-529103',
        chaletId: 'cabana-glass-mist-urubici',
        chaletName: 'Cabana Glass & Mist',
        chaletCity: 'Urubici',
        chaletState: 'SC',
        chaletImage: '/src/assets/images/chalet_jacuzzi_deck_view_1790997529472.jpg',
        checkIn: '2026-10-10',
        checkOut: '2026-10-13',
        nights: 3,
        guests: 2,
        selectedExperiences: ['exp-g1'],
        totalPrice: 4970,
        guestName: 'Mariana Drummond',
        guestEmail: 'mariana.drummond@exemplo.com.br',
        guestPhone: '(48) 99876-1122',
        specialRequests: 'Degustação de vinhos agendada para sábado.',
        paymentMethod: 'cartao',
        status: 'confirmada',
        createdAt: '01/10/2026',
      },
      {
        id: 'REF-314892',
        chaletId: 'vila-dos-pinhais-campos-jordao',
        chaletName: 'Vila dos Pinhais A-Frame',
        chaletCity: 'Campos do Jordão',
        chaletState: 'SP',
        chaletImage: '/src/assets/images/hero_brazilian_luxury_chalet_1790997520247.jpg',
        checkIn: '2026-10-23',
        checkOut: '2026-10-26',
        nights: 3,
        guests: 4,
        selectedExperiences: ['exp-v1'],
        totalPrice: 5630,
        guestName: 'Renato Siqueira Filho',
        guestEmail: 'renato.sf@exemplo.com.br',
        guestPhone: '(11) 98111-9988',
        specialRequests: 'Jantar romântico com chef no sábado à noite.',
        paymentMethod: 'pix',
        status: 'confirmada',
        createdAt: '02/10/2026',
      }
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem('mantiqueira_reservations', JSON.stringify(reservations));
    } catch (e) {
      console.error(e);
    }
  }, [reservations]);

  // Auto-expire pending reservations past 60 minutes to unlock dates
  useEffect(() => {
    const checkExpiration = () => {
      const now = Date.now();
      setReservations((prev) => {
        let changed = false;
        const updated = prev.map((r) => {
          if (r.status === 'pendente' && r.expiresAt && r.expiresAt <= now) {
            changed = true;
            return { ...r, status: 'expirada' as const };
          }
          return r;
        });

        if (changed) {
          addToast({
            type: 'info',
            title: 'Prazo de 60 Minutos Expirado',
            message: 'O prazo de pagamento de uma pré-reserva expirou e as datas foram liberadas na grade.',
            duration: 6000,
          });
          return updated;
        }
        return prev;
      });
    };

    checkExpiration();
    const interval = setInterval(checkExpiration, 10000);
    return () => clearInterval(interval);
  }, []);

  // Toast notification state
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, toast.duration || 5000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // 1-Hour automated expiration watcher for pending reservations
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      const expiredList = reservations.filter(
        (r) => r.status === 'pendente' && r.expiresAt && r.expiresAt <= now
      );

      if (expiredList.length > 0) {
        expiredList.forEach((exp) => {
          addToast({
            type: 'error',
            title: 'Prazo de 1 Hora Expirado',
            message: `A pré-reserva ${exp.id} do "${exp.chaletName}" expirou sem confirmação de pagamento. As datas foram liberadas na grade.`,
            duration: 8000,
          });
        });
        setReservations((prev) =>
          prev.filter((r) => !(r.status === 'pendente' && r.expiresAt && r.expiresAt <= now))
        );
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [reservations]);

  // Modals state
  const [selectedChalet, setSelectedChalet] = useState<Chalet | null>(null);
  const [galleryChalet, setGalleryChalet] = useState<Chalet | null>(null);
  const [galleryInitialIndex, setGalleryInitialIndex] = useState(0);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isReservationsOpen, setIsReservationsOpen] = useState(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState(false);

  // Toggle favorite
  const handleToggleFavorite = (chaletId: string) => {
    setFavoriteIds((prev) => {
      const isFav = prev.includes(chaletId);
      const chalet = chaletsList.find((c) => c.id === chaletId);
      if (isFav) {
        addToast({
          type: 'info',
          title: 'Removido dos Salvos',
          message: chalet ? `"${chalet.name}" foi removido da sua lista.` : 'Refúgio removido.',
          duration: 3500,
        });
        return prev.filter((id) => id !== chaletId);
      } else {
        addToast({
          type: 'success',
          title: 'Refúgio Salvo!',
          message: chalet ? `"${chalet.name}" foi adicionado aos seus favoritos.` : 'Refúgio salvo.',
          duration: 3500,
        });
        return [...prev, chaletId];
      }
    });
  };

  // Add or update reservation
  const handleAddReservation = (newReservation: Reservation) => {
    setReservations((prev) => {
      const idx = prev.findIndex((r) => r.id === newReservation.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = newReservation;
        return copy;
      }
      return [newReservation, ...prev];
    });

    if (newReservation.status === 'pendente') {
      addToast({
        type: 'warning',
        title: 'Pré-Reserva Ativa · Tarja de Reservado',
        message: `O chalé "${newReservation.chaletName}" agora exibe a tarja de reservado. As datas permanecem bloqueadas por até 60 minutos ou até a realização do pagamento!`,
        duration: 8000,
      });
    } else {
      addToast({
        type: 'success',
        title: 'Reserva Confirmada com Sucesso!',
        message: `Sua estadia no chalé "${newReservation.chaletName}" está garantida! Código: ${newReservation.id}`,
        duration: 6000,
      });
    }
  };

  // Cancel / delete reservation
  const handleCancelReservation = (id: string) => {
    const res = reservations.find((r) => r.id === id);
    setReservations((prev) => prev.filter((r) => r.id !== id));
    addToast({
      type: 'info',
      title: 'Reserva Cancelada com Sucesso',
      message: res ? `A reserva ${res.id} foi cancelada e as datas do "${res.chaletName}" foram liberadas na grade.` : 'Reserva cancelada.',
      duration: 5000,
    });
  };

  // Confirm payment manually
  const handleConfirmPayment = (id: string) => {
    setReservations((prev) =>
      prev.map((r) =>
        r.id === id ? { ...r, status: 'confirmada', expiresAt: undefined } : r
      )
    );
    const res = reservations.find((r) => r.id === id);
    addToast({
      type: 'success',
      title: 'Pagamento PIX Confirmado!',
      message: res ? `O pagamento do chalé "${res.chaletName}" foi confirmado com sucesso!` : 'Pagamento confirmado com sucesso!',
      duration: 5000,
    });
  };

  // Update reservation status in Admin
  const handleUpdateReservationStatus = (reservationId: string, status: 'confirmada' | 'pendente') => {
    setReservations((prev) =>
      prev.map((r) => (r.id === reservationId ? { ...r, status } : r))
    );
    addToast({
      type: 'info',
      title: 'Status da Reserva Atualizado',
      message: `A reserva foi alterada para "${status.toUpperCase()}".`,
      duration: 4000,
    });
  };

  // Chalet CRUD in Admin
  const handleAddChalet = (newChalet: Chalet) => {
    setChaletsList((prev) => [newChalet, ...prev]);
  };

  const handleUpdateChalet = (updatedChalet: Chalet) => {
    setChaletsList((prev) =>
      prev.map((c) => (c.id === updatedChalet.id ? updatedChalet : c))
    );
  };

  const handleDeleteChalet = (chaletId: string) => {
    setChaletsList((prev) => prev.filter((c) => c.id !== chaletId));
  };

  // Filtered and sorted chalets
  const filteredChalets = useMemo(() => {
    return chaletsList.filter((c) => {
      // Region tab
      if (activeRegionTab !== 'Todas') {
        if (!c.region.toLowerCase().includes(activeRegionTab.toLowerCase())) {
          return false;
        }
      }

      // Destination select
      if (filters.destination !== 'Todos') {
        const query = filters.destination.toLowerCase();
        if (!c.city.toLowerCase().includes(query) && !c.region.toLowerCase().includes(query)) {
          return false;
        }
      }

      // Style
      if (filters.style !== 'Todos') {
        if (c.style !== filters.style) return false;
      }

      // Guests
      if (c.maxGuests < filters.guests) return false;

      // Jacuzzi / Ofuro
      if (filters.hasJacuzzi) {
        const hasJac = c.amenities.some((a) =>
          /hidromassagem|ofurô|jacuzzi|imersão/i.test(a)
        );
        if (!hasJac) return false;
      }

      // Fireplace
      if (filters.hasFireplace) {
        const hasFire = c.amenities.some((a) => /lareira/i.test(a));
        if (!hasFire) return false;
      }

      // Pet Friendly
      if (filters.petFriendly) {
        const isPet = c.amenities.some((a) => /pet friendly|animais/i.test(a));
        if (!isPet) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.pricePerNight - b.pricePerNight;
      if (sortBy === 'price-desc') return b.pricePerNight - a.pricePerNight;
      if (sortBy === 'rating') return b.rating - a.rating;
      // Default: featured first
      if (a.featured && !b.featured) return -1;
      if (!a.featured && b.featured) return 1;
      return b.reviewCount - a.reviewCount;
    });
  }, [chaletsList, filters, sortBy, activeRegionTab]);

  // Scroll to section helper
  const scrollToSection = (sectionId: string) => {
    if (sectionId === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const favoriteChaletsList = useMemo(() => {
    return chaletsList.filter((c) => favoriteIds.includes(c.id));
  }, [chaletsList, favoriteIds]);

  // If in Admin mode, render Admin Dashboard
  if (isAdminOpen) {
    return (
      <AdminDashboard
        chalets={chaletsList}
        reservations={reservations}
        companySettings={companySettings}
        heroSettings={heroSettings}
        reviews={reviews}
        onUpdateChalet={handleUpdateChalet}
        onAddChalet={handleAddChalet}
        onDeleteChalet={handleDeleteChalet}
        onUpdateCompanySettings={handleUpdateCompanySettings}
        onUpdateHeroSettings={handleUpdateHeroSettings}
        onUpdateReservationStatus={handleUpdateReservationStatus}
        onDeleteReservation={handleCancelReservation}
        onApproveReview={handleApproveReview}
        onBlockReview={handleBlockReview}
        onDeleteReview={handleDeleteReview}
        onAddReview={handleAddReview}
        onCloseAdmin={() => setIsAdminOpen(false)}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F5] text-[#1c1917]">
      
      {/* 3-Zone Strict Header */}
      <Navbar
        companyName={companySettings.name}
        favoriteCount={favoriteIds.length}
        reservationCount={reservations.length}
        onOpenFavorites={() => setIsFavoritesOpen(true)}
        onOpenReservations={() => setIsReservationsOpen(true)}
        onOpenConcierge={() => setIsConciergeOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onNavigateSection={scrollToSection}
      />

      {/* Main Hero & Search Engine */}
      <Hero
        filters={filters}
        onFilterChange={setFilters}
        onSearchSubmit={() => scrollToSection('colecao')}
        totalChaletsCount={chaletsList.length}
        heroSettings={heroSettings}
      />

      {/* Main Interactive Catalog Section */}
      <main id="colecao" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 w-full">
        {/* Dynamic Display: Interactive Map OR Cards Grid */}
        {viewMode === 'map' ? (
          <ChaletMapView
            chalets={filteredChalets}
            reservations={reservations}
            onSelectChalet={(c) => setSelectedChalet(c)}
            onOpenGallery={(c) => {
              setGalleryChalet(c);
              setGalleryInitialIndex(0);
            }}
          />
        ) : filteredChalets.length === 0 ? (
          <div className="bg-white rounded-3xl p-16 text-center border border-[#e5decb] space-y-4 max-w-lg mx-auto my-12">
            <Compass className="w-12 h-12 mx-auto text-[#c7baa4]" />
            <h3 className="font-serif-luxury text-2xl font-semibold text-[#1c1917]">
              Nenhum chalé com estes filtros específicos
            </h3>
            <p className="text-xs text-[#78716c] leading-relaxed">
              Tente redefinir o estilo arquitetônico ou a região para visualizar outros refúgios extraordinários.
            </p>
            <button
              onClick={() => {
                setFilters(INITIAL_FILTERS);
                setActiveRegionTab('Todas');
              }}
              className="px-6 py-2.5 rounded-xl bg-[#222c1f] text-white text-xs font-semibold hover:bg-[#2e3b2a] transition-colors"
            >
              Ver Toda a Coleção
            </button>
          </div>
        ) : (
          <div 
            key={`${activeRegionTab}-${filters.destination}-${filters.style}-${filters.minPrice}-${filters.maxPrice}-${sortBy}`}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredChalets.map((chalet, index) => (
              <ChaletCard
                key={chalet.id}
                chalet={chalet}
                animationDelay={index * 50}
                reservations={reservations}
                isFavorite={favoriteIds.includes(chalet.id)}
                onToggleFavorite={handleToggleFavorite}
                onSelectChalet={(c) => setSelectedChalet(c)}
                onOpenGallery={(c, initialIndex) => {
                  setGalleryChalet(c);
                  setGalleryInitialIndex(initialIndex || 0);
                }}
                onShare={(c) => {
                  addToast({
                    type: 'info',
                    title: 'Compartilhar Chalé',
                    message: `Link de "${c.name}" pronto para enviar aos amigos ou parceiro(a)!`,
                  });
                }}
              />
            ))}
          </div>
        )}

      </main>

      {/* Destinations Highlights Grid */}
      <DestinationsGrid
        onSelectDestination={(city) => {
          setFilters({ ...filters, destination: city });
          scrollToSection('colecao');
        }}
      />

      {/* Curated Experiences & Rituals Section */}
      <CuratedExperiencesSection />

      {/* Guest Reviews & Testimonials Section */}
      <ReviewsSection
        reviews={reviews}
        onAddReview={handleAddReview}
        onAddToast={addToast}
      />

      {/* Contact & Concierge Support Section */}
      <ContactSection companySettings={companySettings} onAddToast={addToast} />

      {/* Footer */}
      <Footer companySettings={companySettings} onNavigateSection={scrollToSection} />

      {/* Chalet Detail & Booking Modal */}
      {selectedChalet && (
        <ChaletDetailModal
          chalet={chaletsList.find((c) => c.id === selectedChalet.id) || selectedChalet}
          reservations={reservations}
          companySettings={companySettings}
          onClose={() => setSelectedChalet(null)}
          onConfirmReservation={handleAddReservation}
          isFavorite={favoriteIds.includes(selectedChalet.id)}
          onToggleFavorite={handleToggleFavorite}
        />
      )}

      {/* Fullscreen Chalet Photo Gallery Modal */}
      <ChaletGalleryModal
        chalet={galleryChalet}
        initialIndex={galleryInitialIndex}
        isOpen={galleryChalet !== null}
        onClose={() => setGalleryChalet(null)}
        onBookChalet={(c) => {
          setGalleryChalet(null);
          setSelectedChalet(c);
        }}
      />

      {/* Favorites Drawer */}
      <FavoritesDrawer
        isOpen={isFavoritesOpen}
        onClose={() => setIsFavoritesOpen(false)}
        favoriteChalets={favoriteChaletsList}
        onRemoveFavorite={handleToggleFavorite}
        onSelectChalet={(c) => setSelectedChalet(c)}
        onOpenGallery={(c) => {
          setGalleryChalet(c);
          setGalleryInitialIndex(0);
        }}
      />

      {/* Reservations Modal */}
      <ReservationsModal
        isOpen={isReservationsOpen}
        onClose={() => setIsReservationsOpen(false)}
        reservations={reservations}
        onCancelReservation={handleCancelReservation}
        onConfirmPayment={handleConfirmPayment}
      />

      {/* Concierge Modal */}
      <ConciergeModal
        isOpen={isConciergeOpen}
        onClose={() => setIsConciergeOpen(false)}
        onSelectChalet={(c) => setSelectedChalet(c)}
      />

      {/* Real-time Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Floating WhatsApp Concierge Button for general info */}
      <FloatingWhatsAppButton companySettings={companySettings} />

    </div>
  );
}

